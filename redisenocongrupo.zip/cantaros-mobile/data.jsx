/* ─── Cántaros Mobile — datos de ejemplo ────────────────────────────────
 * Modelo de un cántaro (jar):
 *   id, name, color, active
 *   mode:  'percent' | 'fixed'      → % del ingreso esperado o monto fijo
 *   carry: 'reset'   | 'accum'      → al cerrar el periodo: reinicia o acumula
 *   percent / fixed                 → valor según mode
 *   source                          → categoría de ingreso que lo apalanca
 *   categories[]                    → categorías de gasto que consumen el cántaro
 *   spent                           → gastado en el periodo actual
 *   carriedIn                       → remanente arrastrado del periodo anterior (accum)
 *
 * Fuente única (2026-07-20, ver DECISIONS.md D-003 / TASKS.md §4.0): los
 * cántaros (id/name/color/icon) y las categorías (id/name/icon/jarId/kind/
 * color/description) YA NO se inventan acá — vienen de `tx-catalog.js`
 * (`window.OWF_JARS` / `window.OWF_CATEGORIES`), la misma fuente que usa
 * el kit desktop. Este archivo solo agrega los campos que son específicos
 * de esta demo mobile (active/mode/carry/fixed/spent/carriedIn) encima de
 * esa base compartida.
 * ──────────────────────────────────────────────────────────────────────── */
/* global window */

const CM_EXPECTED_INCOME = 1200; // ingreso mensual esperado (US$)

/* Runtime extra por cántaro, encima de OWF_JARS (que solo trae id/name/percent/icon/color). */
const CM_JAR_RUNTIME = {
  j1: { carry: 'reset', spent: 486.20, carriedIn: 0,      source: 20 },
  j2: { carry: 'reset', spent: 74.10,  carriedIn: 0,      source: 20 },
  j3: { carry: 'accum', spent: 0,      carriedIn: 540.00, source: 21 },
  j4: { carry: 'reset', spent: 60.00,  carriedIn: 0,      source: 21 },
  j5: { carry: 'accum', spent: 0,      carriedIn: 210.00, source: 20 },
};

const CM_JARS = (window.OWF_JARS || []).map(j => ({
  ...j, active: true, mode: 'percent', fixed: 0,
  categories: (window.OWF_CATEGORIES || []).filter(c => c.jarId === j.id).map(c => c.id),
  ...(CM_JAR_RUNTIME[j.id] || { carry: 'reset', spent: 0, carriedIn: 0, source: null }),
}));

/* Árbol de categorías para el selector — agrupa las categorías REALES de
 * OWF_CATEGORIES (no una taxonomía inventada) usando OWF_CATEGORY_GROUPS
 * (mismo agrupador que usa el CategorySelector de desktop) como "carpetas". */
const CM_CATEGORY_TREE = (() => {
  const groups = window.OWF_CATEGORY_GROUPS || [];
  const cats = window.OWF_CATEGORIES || [];
  const byKind = (kind) => groups
    .filter(g => (cats.find(c => c.jarId === g.jarId) || {}).kind === kind || (kind === 'income' && g.jarId === null))
    .map(g => ({
      id: 'grp-' + (g.jarId || 'none'), name: g.label, folder: true,
      children: cats.filter(c => c.jarId === g.jarId && c.kind === kind).map(c => ({ id: c.id, name: c.name, icon: c.icon })),
    }))
    .filter(g => g.children.length);

  return [
    { id: 'ingresos', name: 'Ingresos', kind: 'income', icon: 'arrow_downward', children: cats.filter(c => c.kind === 'income').map(c => ({ id: c.id, name: c.name, icon: c.icon })) },
    { id: 'gastos', name: 'Gastos', kind: 'expense', icon: 'arrow_upward', children: byKind('expense') },
  ];
})();

/* Mapa plano id → { name, icon, kind, jarId } para resolver chips rápido — ahora deriva de OWF_CATEGORIES. */
const CM_CAT_INDEX = (() => {
  const idx = {};
  (window.OWF_CATEGORIES || []).forEach(c => { idx[c.id] = { id: c.id, name: c.name, icon: c.icon, kind: c.kind, jarId: c.jarId }; });
  return idx;
})();

const CM_PERIODS = ['Todo', 'Anual', 'Semestral', 'Trimestral', 'Mensual', 'Quincenal', 'Semanal', 'Diario'];

/* Plantillas (reusa las del kit si existen; si no, fallback local — este
 * archivo no depende de scripts de otro kit, mismo criterio que el resto
 * de data.jsx). Reutiliza los colores/nombres de OWF_JARS como base. */
const CM_TEMPLATE_FALLBACK = [
  { slug: 'basico-50-30-20', name: 'Básico 50/30/20', segments: [{ name: 'Necesidades', percent: 50, color: '#1E3A8A' }, { name: 'Estilo de vida', percent: 30, color: '#F59E0B' }, { name: 'Ahorro', percent: 20, color: '#10B981' }] },
  { slug: 'bases-y-suenos', name: 'Bases + Sueños', segments: [{ name: 'Necesidades básicas', percent: 45, color: '#1E3A8A' }, { name: 'Ocio', percent: 15, color: '#F59E0B' }, { name: 'Ahorro', percent: 20, color: '#10B981' }, { name: 'Sueños', percent: 20, color: '#8B5CF6' }] },
  { slug: 'minimalista', name: 'Minimalista', segments: [{ name: 'Gastos', percent: 70, color: '#64748B' }, { name: 'Ahorro', percent: 30, color: '#10B981' }] },
];
const CM_TEMPLATES = (window.JAR_TEMPLATES && window.JAR_TEMPLATES.length ? window.JAR_TEMPLATES : CM_TEMPLATE_FALLBACK).slice(0, 5);

Object.assign(window, { CM_EXPECTED_INCOME, CM_JARS, CM_CATEGORY_TREE, CM_CAT_INDEX, CM_PERIODS, CM_TEMPLATES });
