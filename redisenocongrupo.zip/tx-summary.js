/* ─── OW Finance · Resumen de transacción en lenguaje natural ───────────
 * Genera el texto del Transaction Preview Card (pieza 2.6) y la validación
 * de campos (pieza 2.5) a partir del payload que ya construyen los forms.
 * Compartido por ambos kits. Sin dependencias de React.
 * ──────────────────────────────────────────────────────────────────────── */
(function () {
  function money(n, sym) {
    sym = sym || '$';
    var v = Math.abs(Number(n) || 0);
    return sym + ' ' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function acctName(id) {
    var a = (window.SAMPLE_ACCOUNTS || []).find(function (x) { return x.id === id; });
    return a ? a.name : null;
  }
  function catName(id) {
    var c = window.owfCategory ? window.owfCategory(id) : null;
    return c ? c.name : null;
  }

  /* Resumen legible. Recibe un objeto "vista" normalizado desde el form:
   * { type, amount, currencySym, account, toAccount, category, jar,
   *   itemsCount, splitCount, commission, targetBalance, balanceDelta } */
  function owfTxSummary(v) {
    v = v || {};
    var sym = v.currencySym || '$';
    var amt = money(v.amount, sym);
    var t = v.type;

    if (t === 'transfer') {
      var s = 'Transfieres ' + amt;
      if (v.account) s += ' desde ' + v.account;
      if (v.toAccount) s += ' a ' + v.toAccount;
      if (v.crossArrives != null) s += ', llegan ' + money(v.crossArrives, v.toCurrencySym || 'Bs.');
      if (v.commission) s += ' (comisión ' + money(v.commission, sym) + ')';
      return s + '.';
    }
    if (t === 'ajuste') {
      var dir = (v.balanceDelta || 0) >= 0 ? 'sube' : 'baja';
      var d = money(v.balanceDelta, sym);
      var acctPhrase = v.isLite ? 'tu saldo' : (v.account || 'la cuenta');
      var base = 'Ajustas ' + acctPhrase + ' a ' + money(v.targetBalance, sym);
      return base + ' — el saldo ' + dir + ' ' + d + '.';
    }

    // expense / income
    var verb = t === 'income' ? 'Registras un ingreso de' : 'Registras un gasto de';
    var str = verb + ' ' + amt;
    if (v.itemsCount > 1) str += ' (' + v.itemsCount + ' ítems)';
    if (v.shareCount > 1) str += ', dividido equitativamente en ' + v.shareCount + ' categorías';
    if (v.category) str += ' en ' + v.category;
    if (v.splitCount > 1) str += ', repartido en ' + v.splitCount + ' cuentas';
    else if (v.account && !v.isLite && !(v.shareCount > 1)) str += ' desde ' + v.account;
    if (v.jar) str += '. Aporta al cántaro ' + v.jar;
    else str += '.';
    if (v.commission) str += ' Comisión ' + money(v.commission, sym) + '.';
    return str;
  }

  /* ¿La operación es "compleja"? (para el flujo de confirmación 2.4:
   * complejas → preview card antes de guardar; simples → toast deshacer). */
  function owfTxIsComplex(v) {
    v = v || {};
    return !!(v.splitCount > 1 || v.itemsCount > 1 || v.shareCount > 1 || v.commission || v.type === 'transfer' || v.type === 'ajuste');
  }

  /* Validación de campos. Devuelve { ok, errors:[{field,msg}], reasons:[msg] }.
   * reasons = motivos legibles por los que Guardar está deshabilitado. */
  function owfValidateTx(v) {
    v = v || {};
    var errors = [];
    var t = v.type;
    var amt = Number(v.amount) || 0;

    if (t === 'ajuste') {
      if (!v.account) errors.push({ field: 'account', msg: 'Elige la cuenta a ajustar' });
      if (v.targetBalance === '' || v.targetBalance == null) errors.push({ field: 'targetBalance', msg: 'Indica el nuevo saldo' });
    } else {
      if (!(amt > 0) && !(v.itemsCount > 1)) errors.push({ field: 'amount', msg: 'Ingresa un monto mayor a 0' });
      if (t === 'transfer') {
        if (!v.account) errors.push({ field: 'account', msg: 'Elige la cuenta de origen' });
        if (!v.toAccount) errors.push({ field: 'toAccount', msg: 'Elige la cuenta de destino' });
        if (v.account && v.toAccount && v.sameAccount) errors.push({ field: 'toAccount', msg: 'Origen y destino no pueden ser la misma cuenta' });
      } else if (t === 'expense') {
        if (v.category == null && !(v.shareCount > 1)) errors.push({ field: 'category', msg: 'Elige una categoría' });
        if (v.shareCount > 1 && v.shareIncomplete) errors.push({ field: 'share', msg: 'Elige categoría para cada parte del gasto compartido' });
      }
      if (v.splitCount > 1 && v.splitBalanced === false) errors.push({ field: 'split', msg: 'La suma de los pagos no coincide con el monto' });
    }
    return { ok: errors.length === 0, errors: errors, reasons: errors.map(function (e) { return e.msg; }) };
  }

  /* ¿Este gasto deja el cántaro en negativo, con presupuesto estricto activado?
   * Devuelve null cuando no aplica — y "no aplica" incluye el caso de que el
   * toggle esté apagado: sin él, el aviso no es una decisión del usuario sino
   * una opinión de la app sobre en qué gasta.
   *
   * Solo gastos: un ingreso no puede dejar un cántaro corto, y una
   * transferencia mueve plata entre cuentas, no entre cántaros.
   *
   * El saldo sale de `SAMPLE_JARS` — los cántaros de la contabilidad ACTIVA,
   * con su `amount`. `owfJarForCategory` resuelve contra la tabla estática
   * `OWF_JARS`, que no tiene saldo (`amount` salía `NaN` y la función abortaba
   * en toda llamada) y además es siempre la personal: en contexto empresa
   * devolvía "Necesidades básicas" para una empresa cuyos cántaros son Nómina,
   * Impuestos, Reserva… Sirve para el mapeo categoría→cántaro; el saldo hay
   * que buscarlo en los datos vivos. */
  function owfJarOverspend(v) {
    v = v || {};
    if (v.type !== 'expense') return null;
    if (!(typeof window !== 'undefined' && window.owfStrictBudget)) return null;

    var catName = null;
    if (v.category != null && typeof window !== 'undefined') {
      var cats = window.SAMPLE_CATEGORIES || [];
      var c = cats.filter(function (x) { return x.id === v.category || x.name === v.category; })[0];
      catName = c ? c.name : v.category;
    }
    var mapped = (typeof window !== 'undefined' && window.owfJarForCategory) ? window.owfJarForCategory(catName) : null;
    if (!mapped) return null;

    /* Del cántaro mapeado solo se usa el NOMBRE, para encontrar el vivo. Si la
     * contabilidad activa no tiene un cántaro con ese nombre, no hay saldo que
     * vigilar y no se avisa nada — mejor callarse que inventar un límite. */
    var live = (window.SAMPLE_JARS || []).filter(function (j) {
      return j.name === mapped.name || j.id === mapped.id;
    })[0];
    if (!live) return null;

    var available = Number(live.amount);
    if (!isFinite(available)) return null;
    var amount = Number(v.amount) || 0;
    if (!(amount > available)) return null;

    return {
      jarName: live.name, available: available, amount: amount,
      excess: Math.round((amount - available) * 100) / 100,
    };
  }

  var api = { owfTxSummary: owfTxSummary, owfTxIsComplex: owfTxIsComplex, owfValidateTx: owfValidateTx, owfJarOverspend: owfJarOverspend, owfMoney: money };
  if (typeof window !== 'undefined') Object.assign(window, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
