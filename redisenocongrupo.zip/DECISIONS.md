# DECISIONS — ledger de divergencias diseño ↔ Vue

> Memoria externa de las decisiones de negocio del flujo Claude Design ↔ Vue.
> Este archivo vive en el espejo y se sube también al proyecto de Claude Design,
> para que ambos lados trabajen contra las mismas adjudicaciones.

## La regla (no negociable)

Cuando el ciclo de sincronización detecta que algo del diseño **ya existe en Vue por
otra vía** (misma feature, distinto comportamiento), está PROHIBIDO excluirlo del port
en silencio. Toda colisión exige una **disposición explícita** registrada acá, con uno
de estos cuatro valores:

| Disposición | Significado |
|---|---|
| `design-gana` | El Vue se corrige para adoptar el comportamiento del diseño |
| `vue-gana` | El diseño se corrige para reflejar lo ya implementado |
| `fusionar` | Se define un comportamiento nuevo que toma de ambos; los DOS lados se actualizan |
| `intencionalmente-distintos` | Coexisten a propósito (documentar por qué) |

Mientras una divergencia no tenga asiento acá, su vista queda con estado
`divergent-pending-decision` en `views-registry.json` y **no se porta**.

---

## D-001 — Gasto compartido: reparto equitativo vs manual

- **Fecha**: 2026-07-12 · **Estado**: ADJUDICADO · **Disposición**: `fusionar`
- **Divergencia**: el diseño (`ui_kits/lite-desktop/organisms/TransactionForm.jsx`,
  "Gasto compartido ('vaca')") reparte el monto **equitativamente** entre categorías de
  forma automática. El Vue real (`src/components/SmartTransactionModal.vue`, panel
  `shared`/`sharedCats`) usa montos **manuales por fila** validando que la suma cuadre
  con el total. Misma feature, mecánicas incompatibles, ambas conviviendo sin dueño.
- **Decisión** (Jose, 2026-07-12): comportamiento canónico **híbrido** — al agregar
  categorías el monto se reparte equitativamente por defecto (como el diseño), pero
  cada fila sigue siendo editable a mano (como el Vue). Editar una fila re-reparte el
  resto solo entre las filas no tocadas.
- **Acciones pendientes**:
  - [ ] Vue: `SmartTransactionModal.vue` — reparto equitativo por defecto al agregar
    fila / activar el panel, preservando edición manual (tarea aparte, no este PR).
  - [ ] Diseño: `TransactionForm.jsx` — permitir edición manual por fila sobre el
    reparto automático.
- **Mecánica canónica registrada en**: `BEHAVIOR.md` §4.

## D-002 — Adjunto de foto/soporte: port UI-first sin backend

- **Fecha**: 2026-07-12 · **Estado**: ADJUDICADO · **Disposición**: `intencionalmente-distintos` (temporal)
- **Contexto**: el campo de adjunto se portó fiel al diseño como UI-only
  (`URL.createObjectURL`, sin persistencia) con el wiring real diferido a **OWF-283**.
- **Decisión**: el patrón UI-first es válido **solo** bajo esta regla:
  > Se bloquea el port hasta definir backend si la decisión pendiente puede cambiar lo
  > que la UI muestra o cómo se interactúa (la mecánica determina la estructura).
  > No se bloquea si el backend solo cambia dónde se persiste o de dónde se lee.
  El adjunto pasa la regla (la UI es "archivo + preview + quitar" sea cual sea el
  storage). El gasto compartido (D-001) la falla — por eso exigió adjudicación.
- **Guardas**: toda deuda UI-only se registra acá con su tarea; máximo **3** features
  UI-only sin cablear simultáneas en producción.

---

<!-- Plantilla para asientos nuevos:

## D-00X — <concepto>

- **Fecha**: YYYY-MM-DD · **Estado**: PENDIENTE|ADJUDICADO · **Disposición**: <valor>
- **Divergencia**: <qué hace el diseño vs qué hace el Vue, con paths>
- **Decisión** (<quién>, <fecha>): <comportamiento canónico>
- **Acciones pendientes**: <checklist con archivos de ambos lados>
-->

## D-003 — Unificación de fuente de categorías/cántaros + campos nuevos (color, descripción)

- **Fecha**: 2026-07-20 · **Estado**: ADJUDICADO (sesión de diseño) · **Disposición**: `fusionar`
- **Divergencia**: 3 fuentes paralelas de categorías (`OwCategoryStore` con overrides propios, `OWF_CATEGORIES`/`owfJarForCategory` de `tx-catalog.js`, fallback local en `finance-data.jsx`), más una taxonomía inventada en `cantaros-mobile/data.jsx` (ids tipo `'supermercado'`). El panel de Categorías (`AccountsPanel.jsx`) mostraba `color`/`description` por categoría, ausentes en `CatalogCategory` del contrato Vue.
- **Decisión**: `tx-catalog.js` (`OWF_CATEGORIES`/`OWF_JARS`) es la única fuente compartida. Se agregan `color` (hereda del cántaro si null) y `description` (señal IA) al esquema. `OwCategoryStore` muta `OWF_CATEGORIES` directo, sin overrides paralelos. `cantaros-mobile/data.jsx` deriva sus datos de la misma fuente.
- **Acciones pendientes**:
  - [ ] Vue: confirmar si `CatalogCategory` real debe extenderse con `color`/`description`.
  - [ ] Resolver tipo de id de cántaro entre fixtures (`number` en `data/sample-data.contract.js` vs `'j1'..'j5'` en el kit).
- **Mecánica canónica en**: `tx-catalog.js` (cabecera) + `TASKS.md` §4.0.

## D-007 — El PIN no se guarda "optimista y silencioso"

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `divergir`
- **Divergencia**: `PROMPT_REDISENO_ASESOR_CONFIG_NOTIFICACIONES_ONBOARDING.md` §2.5 documenta que las
  preferencias de Config se guardan de forma optimista y **silenciosa en error**
  (`catch {/* silent */}`, sin feedback visual si falla).
- **Decisión**: para notificaciones e idioma se acepta — el costo de que falle es bajo. Para el
  **PIN no**: un ajuste de seguridad que falla sin decirlo deja al usuario creyendo que está
  protegido cuando no lo está. El diálogo confirma explícitamente, y en error dice que sigue sin
  protección y que reintente antes de cerrar (estado `server` de `PinDialog`).
- **Acciones pendientes**:
  - [ ] Vue: el `catch` silencioso tiene que propagar el error en el endpoint de PIN.

## D-008 — "Cuentas vinculadas" no va en Config Lite

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `alinear al canónico`
- **Divergencia**: `ConfigRoute.jsx` tenía una fila "Cuentas vinculadas · 3 tarjetas · 2 bancos".
  El canónico §2.2 la excluye explícitamente (*"Lite: single generic account — no account
  management needed"*), y §2.3 la lista como diferencia Pro/Lite.
- **Decisión**: quitada de Lite. Prometer gestión de cuentas en un modo que tiene una sola cuenta
  genérica es una fila que no lleva a ninguna parte.
- **Consecuencia**: si alguna vez Lite gana multi-cuenta, esto se reabre — no es una decisión
  estética sino un reflejo del alcance de Lite.

## D-004 — Deuda con contraparte interna (miembro del grupo familiar)

- **Fecha**: 2026-08-21 · **Estado**: ADJUDICADO (arquitectura) · **Disposición**: `fusionar`
- **Divergencia**: hoy una deuda es siempre contra un tercero externo, con el acreedor/deudor como
  texto libre (provider/merchant). El documento de arquitectura
  (`ARQUITECTURA_GRUPO_FAMILIAR_EMPRESAS.md` §01) agrega `counterparty_user_id` opcional en `debts`:
  cuando la contraparte es otro usuario del grupo familiar, la deuda queda vinculada de verdad.
- **Decisión**: los dos casos coexisten en la misma tabla y en la misma vista. Con
  `counterparty_user_id` lleno: la deuda la ven ambos miembros y saldarla puede generar la
  transacción correspondiente en las dos cuentas. Con el campo vacío: comportamiento actual, texto
  libre, sin espejo.
- **Acciones pendientes**:
  - [x] Diseño (módulo 5): `InternalDebtCard` — la deuda interna se distingue de la externa por
    la fila de contraparte con avatar ("Mariangela te debe") y por el estado de confirmación.
    La externa no tiene ninguna de las dos cosas.
  - [x] **La contraparte no edita, solo confirma o disputa.** Un solo registro con dos vistas: el
    monto lo escribe quien la registra; el otro confirma, o la marca en disputa y se habla afuera
    de la app. Que ambos editaran el mismo monto sería una guerra de ediciones sin dueño de la
    verdad. Mientras está `pending` no cuenta en el total de ninguno de los dos.
  - [ ] Definir qué pasa si el miembro sale del grupo familiar con una deuda interna abierta.
    El estado `disputed` también queda sin salida definida: hoy la UI dice "háblenlo afuera",
    no hay resolución en producto.
  - [ ] Vue: `debts` + `counterparty_user_id` + `confirmation` + `registered_by_user_id`
    (`confirmation` y `registered_by_user_id` son campos de diseño nuevos, no están en el
    documento de arquitectura — proponerlos o simplificar el flujo).

## D-005 — Contabilidad empresarial: `business_id` transversal, no módulo separado

- **Fecha**: 2026-08-21 · **Estado**: ADJUDICADO (arquitectura) · **Disposición**: `fusionar`
- **Divergencia**: la lectura intuitiva de "contabilidad empresarial" es un módulo aparte con sus
  propias tablas de cuentas, categorías, transacciones y reportes. Eso duplicaría el motor actual
  (cántaros, multi-moneda, reportes, IA) y obligaría a mantenerlo dos veces.
- **Decisión**: una empresa es un contenedor (`businesses`) y las tablas existentes
  (`accounts`, `categories`, `transactions`) ganan una columna opcional `business_id`. Vacía =
  contabilidad personal, sin ningún cambio de comportamiento. Con valor = pertenece a esa empresa.
  Mismo motor, misma UI, la única diferencia es el filtro. El acceso va por `business_users`
  (owner/accountant/viewer), **independiente del grupo familiar**.
- **Consecuencia de diseño**: aparece un **segundo selector de contexto global**
  (Personal / Empresa A / Empresa B) que convive con el selector Lite/Pro existente.
- **Acciones pendientes**:
  - [ ] Diseño: resolver la convivencia de los dos selectores globales en el header antes de
    diseñar cualquier pantalla de Fase 2 (`TASKS.md` §10.0).
  - [ ] Diseño (módulo 4): `/user/accounts` nace contemplando cuenta compartida + cuenta de
    empresa, no personal-only.
  - [ ] Definir si `transactions.business_id` se muestra en algún lado o es puramente derivado
    del `account_id` (el documento dice que el usuario no lo elige a mano).

## D-019 — Salud financiera: días de libertad / runway

- **Fecha**: 2026-08-28 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Cierra el punto 1 del traspaso** (dos totales que se contradecían en pantalla): el patrimonio
  neto y el disponible ya no discrepan — los dos convierten con la tasa del usuario.
- **Decisiones** (Jose):
  - **Divisor**: los cántaros de **gasto** completos. Los de meta no cuentan: dejar de ahorrar no es
    un gasto que haya que seguir pagando. Los gastos fijos declarados serían mejores, pero son
    Fase 3 y no existen — esto es la aproximación hasta entonces.
  - **Numerador**: todo lo líquido, incluido lo apartado para sueños. Es tu plata.
  - **Moneda**: la tasa la **fija el usuario a mano**. Sin alarma ni fecha cuando queda vieja, por
    decisión explícita — pero el monto convertido **dice con qué tasa** ("a 40,50"): dato, no aviso.
  - **Patrimonio**: resta las deudas **completas**, y muestra aparte lo que **vence este mes**.
  - **Nombre**: "Días de libertad" en lo personal, **"Runway"** en una empresa. El mismo cálculo mide
    otra cosa: cuánto aguanta operando sin facturar.
  - **Unidad**: el número grande en **meses**, los días exactos en chico debajo.
  - **Tono**: cuando es bajo (&lt;3 meses) va en rojo **con la palanca**. El rojo ya significa "gasto"
    en el resto de la app, así que acá nunca va solo.
  - **Ubicación**: tarjeta propia en Inicio, arriba de los cántaros, en los dos modos.
  - **Estado vacío**: se muestra con el hueco visible y botón a lo que falta.
- **Decidido por mí** (el usuario pidió criterio en la última ronda):
  - La palanca nombra la **categoría**, no el cántaro. Nadie puede cancelar "Necesidades";
    "Vivienda" sí es algo sobre lo que se puede actuar. (El usuario había pedido "el gasto fijo más
    grande", pero con el divisor por cántaros la app solo conoce hasta la categoría.)
  - El botón del estado vacío lleva a **Cántaros** si falta el reparto y a **Movimientos** si falta
    plata que promediar. "Completar gastos fijos" no tiene a dónde llevar: no existe esa pantalla.
  - **Un cántaro es de meta si `mode: 'accumulate'`** — la distinción que ya existe en Cántaros Pro,
    no una bandera nueva en paralelo.
  - La **cuota de deuda del mes entra al gasto mensual**: hay que seguir pagándola aunque dejes de
    ingresar, y sin ella el número exagera.
- **Acciones pendientes**:
  - [ ] Control de la tasa en Configuración (hoy `owfSetUserRate` existe y no tiene UI).
  - [ ] Al existir Fase 3, cambiar el divisor a los gastos fijos declarados.
  - [ ] **Unificar el nombre de la cuota del mes en el contrato de datos**: los fixtures personales
    la llaman `nextDueAmount` y los de empresa `next`. Hoy `owfDebtDue` normaliza los dos, pero la
    divergencia ya costó un defecto — la deuda personal salía en $0 mientras la tarjeta afirmaba
    "cuota incluida", y nada en pantalla revelaba el hueco.
- **Patrón que esto dejó claro** (tres rondas de verificación seguidas, el mismo defecto):
  cada vista tenía **su propia definición** del mismo hecho. Primero el ingreso, después las
  categorías, después si se convierte la moneda, después si el patrimonio resta la deuda. Arreglar
  una vista a la vez no converge: hay que mover la definición a un solo lugar y hacer que las
  vistas la lean. `owfHomeTotals`, `owfFinancialHealth` y `owfUserRate` son ese lugar.
- **Variante del mismo patrón, en presentación**: el tono del chip de los KPI de Pro se elegía por
  **índice** (`i < 3 ? … : verde`), no por valor. Era correcto por accidente mientras la tasa de
  ahorro era el literal `'42%'`; al derivarla, un 9% se anunciaba en verde de éxito al lado de
  "Meta: 40%". Cada KPI lleva ahora su propio `tone` calculado de su valor. Y quedar debajo de una
  meta de ahorro propia es **neutro, no rojo**: el rojo diría que perdiste plata, cuando lo que
  pasó es que ahorraste menos.

## D-006 — Cántaros por empresa: SÍ

- **Fecha**: 2026-08-21 · **Resuelta**: 2026-08-24 · **Estado**: ADJUDICADO · **Disposición**: `fusionar`
- **Decisión**: una empresa también presupuesta por cántaros. `JarRef` gana `business_id`, y la
  barra de distribución y el `% utilizado` existen **por contabilidad**, no una sola vez.
- **Consecuencia**: el módulo 1 no se puede cerrar como "personal-only". Cada vista de Cántaros
  se escopa al contexto activo.
- **Acciones pendientes**:
  - [ ] `JarRef` + `business_id` en el contrato de datos.
  - [ ] Revisar `JarsProEditor` / `JarsLiteConfig`: el reparto es del contexto, no del usuario.

## D-009 — Selector único de contexto y barra teñida colapsable

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Problema**: la Fase 2 agrega un segundo selector global (Personal / Empresa A / Empresa B) que
  competía por el mismo espacio que el selector Lite/Pro existente.
- **Decisión**: **no hay dos selectores.** El modo (Lite/Pro) deja de ser global y pasa a ser una
  preferencia **de cada contabilidad** — entrar a una empresa entra a su entorno, con su modo
  guardado. Un único selector de contexto, con menú, muestra Personal y las empresas con su modo
  como subtítulo.
- **Marca visual** (elegida sobre 3 candidatos construidos, `candidatos/contexto-*.html`): barra de
  contexto **teñida con el color de la contabilidad**, que **se suma** por encima del header actual
  y **colapsa con el scroll** hasta quedar una línea de color. Tocar la línea la expande de vuelta:
  el color es también el botón. Colapsa con el primer scroll que se mueva, sin distinguir panel.
- **Alcance del color**: header más acentos — botones, gráficos y cántaros toman el color del
  contexto. Los **semánticos no se tocan nunca** (verde ingreso, rojo gasto, ámbar alerta): la
  paleta de contexto es **cerrada**, 6–8 colores elegidos para no chocar con ninguno de los tres.
- **Color por contabilidad**: se **asigna automáticamente** el siguiente libre al crear, y se puede
  cambiar después. Personal también lleva color propio, en Lite y en Pro — el color significa *en
  qué contabilidad estás*, no *esto es una empresa*.
- **Default de Personal (decidido por mí, sin respuesta del usuario)**: arranca con el azul de marca
  y se puede cambiar. Asignarle un color nuevo haría que los usuarios actuales vean la app cambiar
  sin haber pedido nada; el azul es el estado que ya conocen.
- **Contenido de la barra**: nombre, selector, modo y atajo a la Config de esa contabilidad.
- **Acciones pendientes**:
  - [ ] Definir los 6–8 colores de la paleta cerrada y verificar contraste sobre texto blanco.
  - [ ] `layout_mode` deja de ser una preferencia del usuario y pasa a ser del contexto — esto
    contradice `PROMPT_REDISENO_CENTRAL.md` ("`layout_mode` del usuario"). Confirmar con backend.

## D-010 — Cada empresa tiene su Configuración completa

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Decisión**: modo, moneda, notificaciones, cántaros y categorías son **de cada empresa**, no del
  usuario. Config se escopa al contexto activo.
- **Riesgo resuelto** (2026-08-28, Jose): la Config de una empresa es **heredada, no una copia**.
  Componente aparte de la personal: lo que es del **dispositivo o de la persona** (contraseña, PIN,
  idioma, tema, bloqueo de privacidad) no se duplica por empresa y se muestra como heredado, con
  el lugar donde se cambia. Lo que es **de la contabilidad** (modo, moneda, notificaciones,
  cántaros, categorías, temporadas) es propio y editable ahí.
- **Acciones pendientes**:
  - [ ] `BusinessConfigRoute` — componente propio, no un `ConfigRoute` con banderas.
  - [ ] Decidir explícitamente qué queda fuera del escopado (propuesta: cuenta, contraseña, PIN,
    idioma, tema y bloqueo de privacidad siguen siendo del usuario).

## D-011 — La empresa pasa por su propio onboarding

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Decisión**: una empresa nueva nace vacía y pasa por su **propio wizard**, con recomendación de
  cántaros por IA, igual que una persona. Pero **no las mismas preguntas**: el wizard personal
  pregunta por convivencia, fondo de emergencia y una palabra emocional, y nada de eso aplica.
  El wizard de empresa pregunta **rubro, facturación mensual esperada, cuánta gente emplea,
  estacionalidad y meta del año**.
- **Nómina es Fase 4 y no existe**: la pregunta de empleados **siembra un cántaro de Nómina y lo
  dice explícitamente** ("la gestión de empleados y pagos llega pronto"). No se promete una función
  que no está.

## D-012 — Temporadas: reparto de cántaros por temporada (solo empresas)

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Decisión**: una empresa define **temporadas con nombre** ("temporada escolar", "diciembre") y
  les asigna meses, cada una con su propio reparto de porcentajes. Al entrar un mes de otra
  temporada la app **propone el reparto y pide confirmar** — no lo cambia sola: mover los
  porcentajes de alguien sin avisar es mover su presupuesto sin permiso.
- **Alcance**: solo empresas. La contabilidad personal no tiene temporadas.
- **Consecuencia fuerte**: la barra de distribución deja de ser una sola. En contexto empresa hay
  una por temporada, más la noción de "temporada activa".
- **Acciones pendientes**:
  - [ ] Qué pasa con un mes que no está en ninguna temporada.
  - [ ] Qué pasa si dos temporadas reclaman el mismo mes.

## D-013 — Deuda en disputa: contrapropuesta con historial

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Refina D-004**: la contraparte no edita el monto, pero **sí puede contraproponer**. Ida y vuelta
  libre hasta que alguien acepte. Cada propuesta lleva **monto obligatorio y motivo opcional**, y
  el historial completo es **visible como conversación**: quién propuso cuánto y cuándo.
- **Riesgo aceptado** (2026-08-28, Jose): **sin tope de rondas, a propósito.** Una deuda entre dos
  personas se cierra hablando, no por un límite de la app. Cortar la negociación en la ronda N
  dejaría un registro trabado que ninguno de los dos puede mover. El historial visible ya es la
  presión social suficiente.
- **Acciones pendientes**: ninguna. Cerrada.
  - [ ] Decidir si hace falta un corte (ej: después de N rondas, o "retirar la deuda").

## D-014 — Varios grupos familiares, y una cuenta en más de uno

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Decisión**: un usuario puede pertenecer a **varios** grupos familiares (pareja, padres), y una
  misma cuenta se puede compartir **en más de un grupo**.
- **Consecuencia de diseño**: `AccountShareDialog` ya no lista "los miembros del grupo" sino los
  miembros **agrupados por grupo**, y "Compartidas conmigo" tiene que decir por qué grupo llega.
- **Acciones pendientes**:
  - [ ] Rediseñar `AccountShareDialog` para N grupos (hoy asume uno).
  - [ ] `family_group_members` es muchos-a-muchos del lado del usuario.

## D-015 — Salir del grupo con una deuda interna abierta

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Decisión**: la deuda **se congela** y queda visible para los dos en solo lectura. No se borra
  (borrar plata que alguien debe es inaceptable) ni bloquea la salida (nadie queda preso de un
  grupo por una deuda).
- **Acciones pendientes**:
  - [ ] Diseñar el estado "congelada": qué se puede hacer, y si se puede saldar estando fuera.

## D-016 — `manage`: la transacción lleva marca "operado por"

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Cierra la pregunta abierta de D-005**: quien opera una cuenta ajena con permiso `manage` queda
  registrado. "Operado por José" es visible **en la tabla de Transacciones y en el detalle** —
  trazabilidad completa, no una nota escondida.
- **Acciones pendientes**:
  - [ ] Módulo 2: la tabla de Transacciones gana esa marca. Hoy no está diseñada.

## D-017 — "Presupuesto estricto" avisa fuerte, no bloquea

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `nuevo`
- **Decisión**: el toggle no impide guardar. Pide **confirmación explícita** antes de registrar un
  gasto que deja el cántaro en negativo. Bloquear de verdad haría que la app le diga a alguien que
  no puede registrar un gasto que ya ocurrió.
- **Acciones pendientes**:
  - [ ] Diseñar esa confirmación en el formulario de transacción (módulo 2).

## D-018 — Lite canónica de Cántaros y panel de categorías

- **Fecha**: 2026-08-24 · **Estado**: ADJUDICADO (diseño) · **Disposición**: `divergir del prompt`
- **Decisión**: la Lite canónica de Cántaros es **`cantaros-mobile/`** (modo, acumulativo,
  categorías, color), no la hoja de 2 campos que describe `PROMPT_REDISENO_CANTAROS.md` §2. Y el
  panel de categorías dentro de Cántaros queda **editable**, no el árbol de solo lectura del §1.7.
- **Consecuencia**: dos divergencias explícitas contra el prompt de Cántaros. El prompt documenta
  producción actual; esto es la intención de rediseño.

## D-006 — ¿Cántaros por empresa? (resuelta, ver arriba)
