# TASKS — tablero de estado del rediseño

> Tracker ligero de pendientes. Reglas de fondo en `PROMPT_REDISENO_CENTRAL.md` + `DESIGN_CONTRACT.md`/`BEHAVIOR.md`/`DECISIONS.md`. No repetir esas reglas acá — solo tareas.

## Tablero de módulos

| # | Módulo | Prioridad | Estado registry | Estado diseño |
|---|---|---|---|---|
| 1 | **Cántaros** | 🔴 Ahora | `jars-view`: unreviewed | En progreso — ver checklist abajo |
| 2 | Transacciones | ⏸ Pendiente | mixto (ver `views-registry.json`) | — |
| 3 | Home | ⏸ Pendiente | unreviewed | — |
| 4 | Cuentas/Categorías/Impuestos | ⏸ Pendiente | sin entrada | — |
| 5 | Deudas/Sueños/Perfil | ⏸ Pendiente | sin entrada | — |
| 6 | Análisis + Tasas | ⏸ Pendiente | sin entrada | — |
| 7 | Asesor IA/Config/Notif./Onboarding | ⏸ Pendiente | onboarding: unreviewed | Onboarding en progreso — ver hito 7a |
| 8 | Admin | ⏸ Pendiente, baja prioridad | sin entrada | — |
| 9 | Auth/Público | ⏸ Pendiente, baja prioridad | landing: unreviewed | — |
| 10 | **Grupo Familiar + Contabilidad Empresarial** | 🟡 Siguiente (Fase 1) | sin entrada | Arquitectura cerrada, sin pantallas — ver §10 |

---

## 1. Cántaros — análisis de contrato (hecho hoy)

Auditoría de `JarsProConfig.jsx` / `JarsProEditor.jsx` / `AccountsPanel.jsx` / `cantaros-mobile/*` contra `DESIGN_CONTRACT.md` + `data/sample-data.contract.js`. Hallazgos — **campos inventados que violan §1 del contrato** (prohibido inventar nombres de campo):

| Campo usado en diseño | Dónde | Problema |
|---|---|---|
| `cat.jarId` / `getJarId()` | `OwCategoryStore` (Pro desktop) | El campo real en `CatalogCategory` es `assigned_jar_id`, no `jarId`. |
| `cat.color` | `OwCategoryStore`, chips de categoría | `CatalogCategory` real **no tiene `color`** — el color de categoría no existe en el contrato (solo `JarRef.color`). |
| `cat.description` | popover editar categoría, store, IA | `CatalogCategory` real **no tiene `description`** — campo enteramente nuevo, sin contraparte Vue. |
| `jar.mode`, `jar.unit`, `jar.fixedAmount`, `jar.leverageJarId`, `jar.linkedAccountId`, `jar.active`, `jar.carriedIn`, `jar.ajuste` | `JarsProEditor.jsx` | `JarRef` real solo tiene `id/name/color/icon/percent` — todo lo demás (modo fijo/%, apalancamiento, cuenta vinculada, activo/inactivo, carry-in, ajuste manual) es funcionalidad nueva sin backend. |
| `jar.carry`, `jar.mode` (fixed/percent), `jar.source`, `jar.categories[]` | `cantaros-mobile/data.jsx` | Mismos campos nuevos, versión mobile — y **usa ids de cántaro string (`'j1'`)** mientras el contrato real usa `number`. |

**Conclusión**: ninguno de estos es un error de tipeo — son features de producto reales (cántaro fijo vs %, apalancamiento, acumulativo vs reset, descripción para IA, color de categoría) que **no existen todavía en `JarRef`/`CatalogCategory` del lado Vue**. Según el proceso del contrato, esto no se resuelve en silencio:

- [ ] Decidir para cada campo: ¿se propone extender el contrato real (`JarRef`/`CatalogCategory` en Vue) para soportarlo, o es exploración de diseño que no se porta todavía?
- [ ] Registrar como pendiente en `DECISIONS.md` cualquier campo que el diseño ya está mostrando como si existiera (`color` y `description` de categoría son los más urgentes — ya están en la UI que se construyó esta sesión).
- [ ] Unificar el modelo de "cántaro" entre Pro desktop y mobile antes de proponer el contrato — hoy son dos shapes distintas e incompatibles entre sí, no solo con Vue.
- [ ] Confirmar tipo de id de cántaro (`number` en contrato vs `string` en mobile) antes de proponer cambios de contrato.

---

## 1b. Cántaros — checklist funcional (prioridad actual)

Archivos activos: `ui_kits/lite-desktop/organisms/{AccountsPanel,JarsProConfig,JarsProEditor}.jsx`, `ui_kits/lite-desktop/templates/JarsRoute.jsx`, `cantaros-mobile/{screen,categories,data,atoms,detail}.jsx`.

### Pro Desktop
- [ ] Validar que `OwCategoryStore` persiste `description` correctamente al recargar (hoy vive solo en memoria de `window` — confirmar si debe persistir a backend o si es aceptable como estado de sesión de diseño).
- [ ] Testear drag-and-drop de categorías: desde panel Categorías (`AccountsPanel.jsx`) hacia filas de `JarsFullEditorRow` (`JarsProEditor.jsx`) — reasignación en tiempo real en ambos paneles.
- [ ] Confirmar que el popover de edición de categoría (Nombre/Color/Cántaro/Descripción) no expone `Descripción` en ningún punto de la UI estándar (solo señal semántica IA).
- [ ] Revisar consistencia visual: color de categoría en chip de `JarsFullEditorRow` vs chip en panel Categorías — mismo tinte/tono.
- [ ] `JarsGlobalConfig`: validar que "Cántaro de apalancamiento" y "Habilitar apalancamiento automático" tengan mecánica documentada en `BEHAVIOR.md` (hoy no está — evaluar si necesita asiento en `DECISIONS.md` antes de portar).
- [ ] `JarsFullEditorRow` → "Vincular a una cuenta": confirmar contrato de campo (`linkedAccountId`) contra `DESIGN_CONTRACT.md`.
- [ ] Botones "Ajustar" / "Registrar uso" en la fila expandida no tienen handler — decidir si quedan como placeholder documentado o se cablean.

### Mobile (`cantaros-mobile/`)
- [ ] Confirmar cu\u00e1l de los 3 patrones de detalle (`inline` | `sheet` | `screen`) es el can\u00f3nico a portar, o si los 3 quedan como tweak de dise\u00f1o \u00fanicamente.
- [x] `CmCategorySheet`: el árbol de categorías mobile ya deriva de `OWF_CATEGORIES`/`OWF_CATEGORY_GROUPS` (`CM_CATEGORY_TREE` en `data.jsx`) — converge con la misma fuente de `OwCategoryStore`, no es standalone.
- [x] Mecánica de "Plantilla" en footer (`CmBtn variant="soft" icon="dashboard_customize"`) — wireada: sheet de selección + confirmación de reemplazo (`screen.jsx`, `applyTemplate`).
- [x] Divergencia "Ajustar"/"Registrar uso" en `detail.jsx`: no coincidían con §2.6/§3 del prompt canónico (Lite no tiene ajuste dedicado, debe abrir el modal genérico de transacción). Renombrados a "Agregar"/"Retirar", wireados a un quick-sheet monto+descripción documentado como placeholder del modal genérico real (no un formulario de ajuste tipo Pro).

### Preparación endpoint IA
- [ ] Definir shape del payload de descripciones de categoría hacia el asesor IA (no bloquea el diseño, pero documentar contrato esperado en `DESIGN_CONTRACT.md` cuando se defina).

### Bloqueo/decisión pendiente antes de dar por cerrado el módulo
- [ ] Elegir: ¿la vista canónica Pro de Cántaros es `JarsProConfig.jsx`+`JarsProEditor.jsx` (KPI bar + tabla + editor) tal como está, o falta reconciliar con `JarsRoute.jsx` (versión Lite simple con `JarsFullGrid`)? Confirmar que ambas coexisten como Lite/Pro separados, no fusionar.

---

## 4. Cuentas / Categorías / Impuestos — listado de elementos existentes

Escaneado: `ui_kits/lite-desktop/organisms/{AccountsPanel,AddAccountModal,AccountFilter,CategorySelector}.jsx`, `ui_kits/lite-desktop/data/finance-data.jsx`, `OW Finance - Admin.html`. **No existe todavía una vista propia `/user/accounts`, `/user/categories` ni `/user/taxes`** — todo lo relacionado vive repartido en componentes de otras pantallas o en Admin. Primer hallazgo: repartido ≠ inexistente, pero sí fragmentado en 3 fuentes de datos distintas para lo mismo (categorías) — ver hallazgo 4.0.

### 4.0 Hallazgo crítico — 3 fuentes de categorías en paralelo
- `OwCategoryStore` (creado esta sesión, en `JarsProConfig.jsx`) — usado por `AccountsPanel` pestaña Categorías + filas de cántaro Pro.
- `window.OWF_CATEGORIES` + `owfJarForCategory()` / `owfJar()` (globals usados por `CategorySelector.jsx`, selector de categoría del formulario de transacción).
- `SAMPLE_CATEGORIES` fallback local en `finance-data.jsx` (con `jarId`, no `assigned_jar_id` — mismo problema de nombre de campo que ya se detectó en Cántaros).
- [ ] Decidir una sola fuente de verdad de categorías antes de construir la vista `/user/categories` — hoy un cambio de color/nombre en un lado no se refleja en los otros dos.
- [ ] Alinear todos a `assigned_jar_id` (nombre real del contrato) en vez de `jarId`.

### 4.1 Cuentas — elementos existentes
- `AccountsPanel.jsx` (columna derecha Pro, pestaña Cuentas): patrimonio neto USD, lista de cuentas (avatar iniciales, nombre, subtítulo, saldo nativo + USD, badge "ajustado"), multi-selección (checkbox parcial/todo, seleccionar todo/deseleccionar, barra de acciones bulk: Ajustar saldo / Recalcular), menú kebab por fila (Ajustar saldo inline, Recalcular con spinner), toast de confirmación, botón "Agregar cuenta".
- `AccountFilter.jsx` (popover independiente, usado en otra parte — posiblemente header de Transacciones): agrupa cuentas por carpeta (Mis cuentas/Venezolanas/Tarjetas y deudas), segmentos inteligentes (Todas/Solo USD/Solo VES/Con deuda), buscador, mismo patrón de Ajustar/Recalcular saldo **duplicado independientemente de `AccountsPanel`**, footer con balance combinado.
  - [ ] **Revisar duplicación**: `AccountFilter` y `AccountsPanel` reimplementan la misma mecánica de ajustar/recalcular saldo con código separado — candidato a unificar en un solo componente antes de portar.
- `AddAccountModal.jsx`: paso 1 elegir tipo (Banco/Tarjeta/Efectivo/Cashea/Ahorro con interés · Préstamo/Deuda), paso 2 formulario condicional — nombre, moneda, color (cuentas) / monto adeudado, APR + capitalización (ahorro con interés) / APR + plazo + día de pago + cuota mensual calculada (deuda).

### 4.2 Deudas — elementos existentes
- Pestaña "Deudas" en `AccountsPanel.jsx`: total adeudado USD, `DebtRow` (icono por tipo, nombre, vencimiento, APR o cuota N/M, balance, status pill: pendiente/vence pronto/vencido/activo, próximo pago), botón "Registrar deuda" (abre `AddAccountModal` en modo deuda).
- [ ] Nota: el módulo 5 (`/user/debts`) es una ruta secundaria de primer nivel — confirmar si esta pestaña Pro-only del panel de cuentas es redundante con esa vista o son cosas distintas (resumen vs gestión completa).

### 4.3 Categorías — elementos existentes
- Pestaña "Categorías" en `AccountsPanel.jsx` (recién construida): buscador, chips agrupados por cántaro (o "Sin cántaro"), drag handle hacia filas de cántaro, popover editar (Nombre/Color/Cántaro/Descripción — Descripción no visible fuera del popover, señal IA), botón "Agregar categoría" con form inline (nombre + paleta de color + descripción).
- `CategorySelector.jsx` (selector dentro del formulario de transacción, NO la vista de gestión): buscador siempre visible, modo frío = grid agrupado y coloreado por cántaro, modo caliente (escribiendo) = lista plana con píldora de cántaro. El cántaro nunca se elige acá — está anclado a la categoría.
- Sin vista de gestión CRUD de categorías standalone (crear/editar/archivar todas las categorías del usuario en una pantalla) — hoy solo existe como panel lateral dentro de Cántaros.

### 4.4 Impuestos — elementos existentes
- **No hay vista de usuario para impuestos.** Lo único que existe:
  - `window.SAMPLE_TAXES` en `finance-data.jsx` (IVA 16% item, IGTF 3% payment, Comisión Pago Móvil 0.30% payment) — usado únicamente como picker por ítem dentro de `TransactionForm.jsx` (factura Pro).
  - CRUD genérico de Impuestos en `OW Finance - Admin.html` (Nombre/Tasa/Tratamiento) — es back-office, no vista de usuario.
- [ ] **`SAMPLE_TAXES` no está en `data/sample-data.contract.js` ni en `DESIGN_CONTRACT.md`** — no es uno de los 6 fixtures oficiales generados (`SAMPLE_TX/ACCOUNTS/JARS/CATEGORIES/TAGS/PROVIDERS`). Confirmar si existe una interfaz TS real (`Tax`) en el frontend Vue antes de construir nada nuevo sobre impuestos — hoy no hay contrato que lo respalde.
- [ ] Definir si `/user/taxes` es gestión de catálogo (crear impuestos propios) o solo consulta informativa de tasas del país (IGTF, Pago Móvil) — el insumo de Admin sugiere lo primero, pero no hay UI de usuario final para ninguna de las dos.

## 1c. Cántaros — brecha vs `PROMPT_REDISENO_CANTAROS.md` (fuente canónica, recién disponible)

Este prompt es la auditoría real de producción (`/app/user/jars`) — más completa que el JSX construido en esta sesión (`JarsProConfig`/`JarsProEditor`/`AccountsPanel`). Comparado contra él, falta:

- [x] **Modal de Ajuste dedicado** (§1.9): balance objetivo + split Usado/Restante sincronizado + descripción + preview con signo + confirmación si reduce balance + "Borrar ajustes del mes". Implementado en `JarsProEditor.jsx` (`JarAdjustModal`).
- [x] **Diálogo "Registrar uso"** (§1.10): monto + descripción + fecha. Implementado (`JarRegisterUseModal`).
- [x] **Aplicar plantilla** (§1.8): reutiliza `JarTemplateSelector`/`JAR_TEMPLATES` ya existentes (mini-barra + confirmación de reemplazo), botón agregado junto a "Añadir cántaro".
- [x] **Meta/objetivo ($) por cántaro** — agregado en opciones avanzadas de `JarsFullEditorRow`, con % de progreso.
- [x] **"Ver desglose completo"** — expandible en el panel de balance: saldo anterior, asignado, gastado, ajuste, transferencias/apalancamiento in-out (placeholder en 0, sin modelo de datos todavía), balance final.
- [x] **Opciones avanzadas por cántaro**: fecha propia + toggle "usar fecha global", ciclo/día propio, negativo/límite propio — agregado junto a "vincular cuenta".
- [x] **Confirmación de eliminar cántaro con categorías vinculadas** — banner inline antes de borrar.
- [x] **Barra de distribución** con segmento rayado/vacío si <100%, tooltip por segmento (`JarsDistributionBar` en `JarsProEditor.jsx`, extiende el patrón de `JarsConfig.jsx`), y botón "Guardar Cambios" gateado por validez (`disabled` si `totalPercent > 100`) — sin handler de persistencia real (no hay backend cableado; queda como los demás placeholders documentados de este módulo).
- [ ] **Fórmulas §6** (`% utilizado` sin cap en Pro, con cap 100% en Lite; `balance = inflows − outflows` incluyendo transferencias/apalancamiento reales) — el desglose ya lista los conceptos pero transferencias/apalancamiento quedan en 0 (no hay modelo de datos para eso todavía).

**Divergencia a decidir, no solo pendiente**: el prompt describe el panel de categorías como **árbol de solo lectura** del que se arrastra (§1.7, "las ya asignadas se ocultan del árbol"). Lo que se construyó en `AccountsPanel.jsx` esta sesión es un panel **editable** (crear/editar nombre/color/descripción inline). Son dos conceptos distintos — decidir si el editable reemplaza al árbol read-only o si conviven (p. ej. árbol read-only aquí + gestión completa en la futura vista `/user/categories` del módulo 4).

**Nota fuera de alcance ya registrada por el prompt** (§9): falta columna de saldo histórico de cuenta post-movimiento en la tabla de transacciones — es del módulo Transacciones, no de Cántaros; queda anotado ahí para cuando se trabaje esa vista.

**Vista Lite**: el prompt (§2) describe una Lite bottom-sheet muy distinta a `cantaros-mobile/` (que ya construimos con 3 patrones inline/sheet/screen). Confirmar cuál es la Lite canónica antes de seguir iterando mobile — el prompt solo documenta el patrón "sheet" con 2 campos en edición (Nombre + Porcentaje, sin tipo fijo/%, sin acumulativo, sin categorías) mientras `cantaros-mobile/detail.jsx` expone bastante más (mode, carry, categorías, color picker completo). Esto es una brecha Lite igual de real que la de Pro.

---

---

## 7a. Onboarding — hito: formulario validado + estados faltantes

Primer hito abierto del módulo 7. Alcance: solo el `OnboardingFlow` (formulario de perfil + recomendación de cántaros). El `OnboardingModal` (Lite vs Pro), Asesor IA, Config y Notificaciones quedan fuera.

### Validación de campos contra `PROMPT_REDISENO_DEUDAS_SUENOS_PERFIL.md` §3.2–3.4

- [x] Los 8 campos del perfil y todas sus opciones coinciden con el canónico (ocupación 6, ingresos 4, convivencia 4, deudas 5, fondo de emergencia 4, relación con el dinero 4, meta principal 5, palabra emocional 5).
- [x] `ui_kits/mobile/profile-data.jsx` y `ui_kits/lite-desktop/data/profile-data.jsx` son idénticas byte a byte — no hubo divergencia entre las dos copias.
- [x] **Corregido**: el textarea del sueño estaba en `maxLength 240` en `flow.jsx`, `flow-desktop.jsx` y `welcome-modal.jsx`; el canónico pide 500 con el contador en color de advertencia sobre 450. Alineado en los tres.
- [ ] **Divergencia a registrar en `DECISIONS.md`**: §3.6 pide chips single-select que deseleccionan con un segundo click. En el wizard, `selectChip` asigna el valor y avanza automáticamente a los 280 ms — no hay toggle a null. Es deliberado (en un wizard el avance ES la confirmación, y volver atrás permite cambiar), pero significa que el mismo chip se comporta distinto en el wizard que en el panel de Perfil Financiero. Decidir si se acepta como diferencia intencional o si el wizard debe permitir deseleccionar.

### Estados faltantes de `recommend` (hechos en este hito)

Antes solo existía el caso feliz con un `thinking` fijo de 1500 ms. Ahora `recommend` es una máquina de estados en mobile (`RecommendScreen`) y desktop (`DkRecommend`), con la misma lógica compartida en `onb-atoms.jsx` (`onbRecStatus`, `onbRecFallback`, `onbSegTotal`, `onbSegStep`):

- [x] **`thinking`** — sin cambios respecto al diseño previo.
- [x] **`error`** — la recomendación no se pudo generar. Icono neutro (`cloud_off`), no rojo: no es culpa del usuario y no perdió nada. El texto lo dice explícitamente ("Tus respuestas están guardadas"). Salidas: **Reintentar** (primaria) y **Elegir un esquema yo mismo** (escape que no depende de la IA).
- [x] **`insufficient`** — faltan datos esenciales (ocupación, ingresos, meta principal). **No se trata como error**: se muestra un plan prudente real (`conservador`) marcado con chip neutro "Genérico" en vez del chip "IA", el borde de la tarjeta pierde el acento de marca, y una tarjeta accionable arriba dice cuántos datos faltan y lleva de vuelta al wizard. Desktop además nombra los campos faltantes.
- [x] **Regla de diseño**: el chip "IA" solo aparece cuando la recomendación es realmente personalizada. Un plan genérico no se disfraza de recomendación.

### Estado de edición de `jars` (hecho en este hito)

- [x] Nueva vista **"Ajustar porcentajes"**, accesible desde `recommend` en ambos estados (`ok` e `insufficient`) — antes solo se podía aceptar o cambiar de plantilla completa, no editar la propuesta.
- [x] Steppers de ±5 puntos por segmento (targets de 44 px en mobile), tope 0–95, barra de distribución en vivo.
- [x] Píldora de total que pasa a color de advertencia cuando ≠ 100 %, con el faltante o el sobrante dicho en palabras ("Te faltan 15 puntos por repartir").
- [x] Continuar bloqueado hasta que el reparto sume 100 %; el botón dice qué falta en vez de solo estar apagado. Requirió agregar soporte de `disabled` a `PillButtonMobile` (`ui_kits/mobile/components/Atoms.jsx`).
- [x] **Restablecer el sugerido** siempre disponible: nunca se pierde el punto de partida de la IA.
- [x] Cambiar de plantilla descarta el ajuste manual (los porcentajes editados pertenecían a la plantilla anterior).

### Cómo revisar los estados

Los tres estados nuevos están en el mapa de rutas de `Onboarding Mobile.html` (grupo "Recomendación · estados") y `Onboarding Desktop.html` (grupo "Estados recomendación"). El override `window.ONB_REC_FORCE` (`'error' | 'insufficient' | 'edit'`) existe solo para eso; en producción el estado sale del perfil real.

### Salida por "saltar" (hecho en este hito)

Antes salir era silencioso: `onChoose('skip')` hacía `setRoute('panel')` sin decir nada, y a mitad del wizard **no había forma de salir** — solo retroceder paso por paso.

- [x] Botón de cerrar en el header del wizard (mobile y desktop). Antes el wizard era una trampa una vez dentro.
- [x] Nueva hoja `OnbExitSheet` (mobile, hoja inferior) y `DkExitDialog` (desktop, diálogo centrado) — mismo contrato y mismas palabras, dos presentaciones.
- [x] **Regla**: la hoja solo aparece si hay respuestas que perder. Saltar desde el intro con el perfil vacío sale directo, sin confirmación — no hay nada que confirmar y pedir permiso ahí sería fricción vacía.
- [x] La hoja no pide permiso ni culpa al usuario: dice cuántas respuestas quedan guardadas (`X de N`), dónde retomarlas (Inicio → tarjeta de perfil) y afirma que nada se borra. "Salir por ahora" siempre disponible; "Seguir donde iba" es la primaria.
- [x] Punto de retorno: ya existía — `OnbProgressCard` en el panel con su `onContinue` salta al primer campo sin responder. La hoja ahora **lo nombra** en vez de dejar al usuario adivinando.
- [x] Revisable desde el grupo "Salida" del mapa de rutas en ambos documentos (override `window.ONB_FORCE_EXIT`).

### Pendiente del hito

- [x] Reenganche desde **Configuración** (solo Lite): ya existía — fila "Repetir configuración inicial" en `ConfigRoute.jsx`, con `onStartOnboarding`. El pendiente estaba mal escrito: Config sí tiene diseño.
- [ ] Definir la **relación entre `Modal Bienvenida` y el flow**: cuál aparece primero y qué pasa si el usuario cierra uno de los dos.
- [ ] Decidir si `Onboarding Desktop.html` y `Onboarding Mobile.html` se unifican en un documento con breakpoints o siguen separados.
- [ ] Revisar `gamification.jsx` completo y decidir qué se porta: hoy propone más de lo que existe en producto (3 badges: 🌱 Semilla / 🌿 Brote / 🌳 Árbol).
- [ ] Comparar el JSX del flujo contra el Vue real y sacar `onboarding` de `unreviewed` en `views-registry.json`.
- [ ] Abrir entradas de registry para Asesor IA, Configuración y Notificaciones (el resto del módulo 7 no tiene ninguna).

---

## 7b. Configuración — brecha vs §2 del canónico (hito cerrado 2026-08-24)

Config **ya tenía diseño** en los dos modos. Comparado contra `PROMPT_REDISENO_ASESOR_CONFIG_NOTIFICACIONES_ONBOARDING.md` §2, faltaban piezas concretas. Documento de revisión: **`OW Finance - Configuración.html`** (7 estados de Seguridad/PIN). Las rutas completas siguen en `ui_kits/lite-desktop/index.html`.

- [x] **Bloque Seguridad** (`organisms/SecurityDialogs.jsx`): faltaba **por completo en Lite** (§2.2 lo pide) y en Pro era una fila muerta (`onActivate={() => {}}`). Ahora es real en los dos, con la diferencia §2.3 respetada: contraseña inline en Pro, redirige a `/user/profile` en Lite.
- [x] **Diálogo de PIN** (§2.4): crear / cambiar / eliminar, 4–6 dígitos con puntos de progreso que dicen cuántos faltan sin revelar el PIN, validación de formato y de coincidencia, y dos errores de servidor.
- [x] El PIN dice qué **no** hace: no cifra los datos ni reemplaza la contraseña. Es una barrera, no encriptación — prometer más sería mentir sobre seguridad.
- [x] Notificaciones en Pro: eran una fila muerta, ahora son los 2 toggles reales de §2.1.
- [x] "Cuentas vinculadas" **quitada de Lite** — el canónico la excluye explícitamente (D-008).
- [x] Filas **Categorías** e **Impuestos** agregadas a Lite (§2.2 las pide como paneles internos).
- [x] "Exportar datos" ahora dice "Exportación próximamente" en vez de fingir un flujo (§2.2 lo marca como placeholder no funcional).
- [x] Fila **Grupo familiar** en los dos modos → `FamilyRoute` (cierra el pendiente de §10.1).
- [x] Variantes mobile del bloque Seguridad y del diálogo de PIN: `ui_kits/mobile/components/SecuritySheet.jsx` — **keypad**, no campo de texto (un campo abre el teclado del sistema y tapa los puntos de progreso justo cuando hacen falta). Con largo variable 4–6 no hay auto-avance posible: el botón Continuar aparece a los 4 dígitos.
- [x] Card **Aplicación** completada en los dos modos (§2.1/§2.2): tema, ocultar saldos por defecto, presupuesto estricto, y las filas navegables "Divisa predeterminada" y "Pantalla de inicio". En Lite el grupo "Visualización" duplicaba tres de esos campos — eliminado, ahora hay una sola definición compartida.
- [ ] Las pestañas Categorías / Cuentas / Impuestos de Pro siguen siendo listas placeholder, no los árboles completos del módulo 4 — ya estaba anotado en la cabecera de `ProConfigRoute.jsx`, se mantiene.
- [ ] Diálogos §2.4 que faltan: crear/editar cuenta y editar categoría con selector de cántaro (viven en el módulo 4, no duplicar acá).
- [ ] "Presupuesto estricto" es un toggle sin comportamiento definido en ninguna vista de Cántaros — si bloquea de verdad, hay un estado de error al registrar gasto que no está diseñado.

---

Sin trabajo iniciado. Cuando se retome alguno, generar su prompt dedicado siguiendo el proceso §4 de `PROMPT_REDISENO_CENTRAL.md` y abrir su sección de checklist acá.

---

## 11. Fase 2 — Empresas y contabilidad segmentada (en curso)

Decisiones cerradas: `DECISIONS.md` **D-009** a **D-018**. Documento de revisión: **`OW Finance - Fase 2 Contexto.html`**.

### 11.0 Traspaso — qué queda abierto (leer esto primero)

§11.1–11.3 son el registro de lo hecho, con el por qué de cada decisión. Esta sección es solo lo que falta.

**Necesitan una decisión tuya — no las resuelvo adivinando:**

1. ~~Patrimonio neto convierte, Disponible excluye.~~ **RESUELTO** (D-019): los dos convierten con la tasa que el usuario fija a mano, y el monto dice con qué tasa convirtió.
2. ~~Config completa por empresa arrastra PIN, idioma y tema.~~ **RESUELTO** (D-010): Config **heredada**, componente aparte. Falta construir `BusinessConfigRoute`.
3. **`layout_mode` pasa de ser del usuario a ser del contexto** (D-009). Contradice `PROMPT_REDISENO_CENTRAL.md`. Lo que backend necesita saber, ya respondido por Jose: el modo de una empresa **lo ven igual todos** (el dueño define) → el dato vive en `businesses`, no en `business_users`; y **todo arranca en Lite**, sin heredar el modo guardado. Falta confirmarlo con backend y avisar al dueño qué pierde el equipo antes de bajar el modo.
4. ~~Contrapropuesta sin tope de rondas.~~ **RIESGO ACEPTADO** (D-013): a propósito. Una deuda entre dos personas se cierra hablando, no por un límite de la app.

**Construibles ya, sin preguntar nada:**

5. **`BusinessConfigRoute`** — Config heredada de empresa (D-010): lo del dispositivo y la persona (contraseña, PIN, idioma, tema, bloqueo de privacidad) se muestra como heredado con el lugar donde se cambia; lo de la contabilidad (modo, moneda, notificaciones, cántaros, categorías, temporadas) es propio y editable.
6. **Control de la tasa en Configuración** — `owfSetUserRate` existe y no tiene UI (D-019).
7. **Aviso al bajar el modo de una empresa** con gente dentro: qué pierde el equipo antes de confirmar.
8. **Pantalla de Deudas internas** en Pro/Lite — `InternalDebtCard` existe, se carga y **no la enruta nadie**.

1. **Patrimonio neto convierte, Disponible excluye.** El panel de Cuentas pasa los bolívares a dólares (19.723,61); el KPI del Inicio los deja fuera (15.120,65). Los dos son correctos y bien rotulados, pero conviven en la misma pantalla con 4.600 dólares de diferencia. ¿El disponible también convierte, o el patrimonio también excluye? Con qué tasa se convierte plata de otra moneda es contable, no de diseño.
### 11.1 Barra de contexto — hecho

`ui_kits/lite-desktop/organisms/ContextBar.jsx`. Elegida sobre 3 candidatos construidos (`candidatos/contexto-*.html`).

- [x] **Un solo selector.** El modo Lite/Pro deja de ser global y pasa a ser preferencia de cada contabilidad, así que aparece como subtítulo de cada opción — no como un segundo control peleando por el header.
- [x] Barra teñida con el color del contexto, sumada por encima del header actual.
- [x] **Colapsa con el primer scroll** hasta una línea de 6 px que queda **pegada arriba** (`sticky top:0`), y tocarla la expande *y abre el menú* — estando scrolleado, expandir para después buscar el selector serían dos gestos para una sola intención. Sin el sticky el colapso era inútil: la línea se iba de pantalla con el scroll y no había nada que tocar.
- [x] La barra va como hija directa del shell, **no envuelta en una caja de su alto**: un sticky solo viaja dentro de su bloque contenedor, así que envolverla la desprendía en cuanto el wrapper salía de pantalla. El precio es un reflow de 43 px una vez al cruzar el umbral — el mismo comportamiento de cualquier header que se encoge, y preferible a dejar un hueco vacío permanente.
- [x] Bucle resuelto con un flag `manual`: expandir estando scrolleado reflowea 43 px, el reflow dispara un scroll, y ese scroll la volvía a colapsar en el mismo instante — se tocaba la línea y no pasaba nada. Ahora queda abierta hasta que se elige una contabilidad o se vuelve arriba.
- [x] Escucha el scroll **en captura sobre el documento**, no en un scroller concreto: en Pro los paneles scrollean por separado y no existe "el" scroll de la página.
- [x] Paleta cerrada de 8 colores (`OWF_CONTEXT_COLORS`) — toda en azules y violetas más dos neutros desaturados. El primer intento incluía un petróleo (`#0D9488`, ~175°) y un terracota (`#B45309`, ~26°) que caían a 15° del verde de ingreso y a 12° del ámbar de alerta — exactamente la colisión que la paleta cerrada venía a evitar. Reemplazados.
- [x] Asignación automática del siguiente color libre (`owfNextContextColor`), editable después.
- [x] Personal arranca en el azul de marca: darle un color nuevo haría que los usuarios actuales vean la app cambiar sin haberlo pedido.

- [x] **Integrada en los dos shells** (`LiteShell` / `ProShell`) por encima del header real, y cargada en `index.html`. Costo de altura medido sobre el header de verdad: **49 px** en Lite, y **49 + 61 = 110 px** en Pro, donde el top bar es más alto. Eso es lo que el documento de revisión suelto no podía mostrar.
- [x] **Cambiar de contabilidad cambia de shell**: entrar a una empresa en Pro desde Personal en Lite monta `ProShell`. El modo sale de la contabilidad, no del usuario (D-009).
- [x] Bug encontrado al verificar esto: `AddAccountModal.jsx` **nunca estuvo en los `<script>` de `index.html`**, y `AccountsPanel` lo referencia — así que todo Pro tiraba `ReferenceError` y renderizaba en blanco. Preexistente, no de la barra. Agregado.
- [x] El acento del contexto ya alimenta el `MonthNavigator` de Lite.
- [x] `--z-sticky: 60` agregado a la escala de `colors_and_type.css` — antes la barra usaba ese nombre con fallback y el token no existía.

- [x] **Crear empresa** (`CreateBusinessModal.jsx`): nombre, RIF opcional, moneda y modo. Cuatro campos — todo lo que define cómo se maneja la empresa sale de su onboarding, y pedirlo acá lo preguntaría dos veces. El color no se pregunta: se asigna el siguiente libre y la cabecera del modal ya viene teñida.
- [x] **Estado vacío de una empresa nueva** (`BusinessEmptyState.jsx`): tres pasos en el orden en que se pueden hacer, el tercero apagado con el motivo escrito hasta que haya cuenta, y la nota de que nómina llega después.
- [x] **Onboarding de empresa** (`BusinessOnboardingFlow.jsx`, D-011): rubro, facturación esperada, empleados, estacionalidad y meta del año, más el reparto propuesto por rubro. **No** reusa el wizard personal. La estacionalidad solo pregunta si el negocio tiene temporadas; nombrarlas es el editor de D-012.
- [x] Las empresas creadas viven en `window.__owCtxExtra`, fuera del array de muestra: crear una empresa en Pro desde Lite cambia de shell y el harness reevalúa los scripts, así que un push al array se perdería en el remonte.

- [x] **Escopar las rutas por contabilidad** (`data/context-data.jsx`): cada contabilidad tiene su propio dataset — cuentas, movimientos, cántaros, deudas — y cambiar de contexto reasigna los globales que leen las rutas. Funciona sin tocar las 15 rutas porque cada archivo declara sus datos con `const` en su propio script y los publica en `window`: los consumidores, que viven en otros scripts, resuelven ese nombre contra `window` en cada render. En el backend real el escopado es un `business_id` en la consulta, no un swap de globales.
- [x] Las dos empresas de muestra (Distribuidora Otero, Consultora MG) tienen datos propios coherentes con su rubro, para poder ver el escopado funcionando sin crear una empresa a mano.
- [x] **El perfil del wizard se guarda** (`owfSaveBusinessProfile`) y el reparto se convierte en cántaros reales, en cero. Antes el reparto se mostraba y se tiraba. Los cántaros nacen sin monto: la empresa no facturó nada todavía y poner cifras de ejemplo haría que su Inicio mienta desde el primer día.
- [x] El estado de arranque ya no depende de una bandera: se muestra mientras la empresa **no tenga cuentas**. En cuanto agrega una, cae a las rutas normales — que ahora leen SUS datos, no los personales. Una empresa no tiene "sueños": esa ruta queda vacía a propósito.

### 11.2 Pendiente de Fase 2

- [x] **Inicio escopado** (`AN_HOME` en `context-analysis.jsx`). Los tres números grandes estaban escritos a mano en `HomeRoute.jsx`, `ProHomeRoute.jsx` y dentro de `HeroBalance.jsx`, así que una empresa mostraba el disponible y los ingresos personales con su color y su nombre arriba — y los Cántaros correctos justo debajo, contradiciéndose en la misma pantalla.
  - El disponible suma **solo las cuentas en la moneda base**: sumar bolívares con dólares da un número que no existe, y el rótulo dice "USD". Las cuentas en otra moneda se cuentan y la tarjeta avisa que no están incluidas.
  - Sin periodo anterior no hay con qué comparar: el chip de variación y el "Al —" **no se montan**, en vez de mostrar 0%.
- [x] El chip de variación del hero tenía el mismo defecto de nodos hermanos que Análisis ("+4.2 % vs. mes ant."): corregido en `HeroBalance.jsx` y en el `BalanceCard.jsx` de mobile.
- [ ] **Acentos por contexto en el resto de la app**: hoy la barra, el `MonthNavigator`, el modal de alta, el estado de arranque y el wizard de empresa. Botones, gráficos y cántaros de las vistas reales siguen con `--brand-primary` fijo.
- [x] **Temporadas** (D-012) — `data/context-seasons.jsx`, `organisms/SeasonsEditor.jsx`, `organisms/SeasonPrompt.jsx`. Editor montado en Cántaros **solo en contexto empresa** (Lite y Pro); el prompt vive en los dos shells.
  - Las dos preguntas que D-012 dejaba abiertas quedaron cerradas por diseño: existe un **reparto base** que no reclama meses y rige donde ninguna temporada aplica (así nadie tiene que cubrir los 12 meses ni quedan meses huérfanos); y **un mes pertenece a una sola temporada** — asignarlo lo saca de la otra y la UI lo dice con el nombre de la que lo perdió. Con solapamiento, "qué reparto rige en diciembre" no tendría respuesta.
  - El prompt muestra el cambio **de cuánto a cuánto** por cántaro: solo el número nuevo no diría si sube o baja. Y "seguir con el reparto actual" no vuelve a preguntar por esa temporada.
  - Al aplicar, los montos ya acumulados **se conservan**: cambia cuánto se aparta de acá en adelante. Borrar el saldo por un cambio de presupuesto sería perder plata real.
- [ ] Con temporadas, la **barra de distribución del módulo 1 ya no es una sola** en contexto empresa: hay un reparto por temporada. `JarsDistributionBar` sigue mostrando solo el vigente, sin decir de qué temporada es.
- [ ] **Config por contabilidad** (D-010): Config se escopa al contexto. Falta decidir qué queda fuera (propuesta: cuenta, contraseña, PIN, idioma, tema y bloqueo de privacidad siguen siendo del usuario — un PIN por empresa no tiene sentido).
- [x] **Acentos por contexto** (`owfContextVars` en `ContextBar.jsx`). No se pasa `accent` por cada vista: se **reescribe la familia `--brand-primary`** en la raíz del shell, así que todo lo que ya usaba el token — botones, chips activos, barras de cántaro, gráficos — sigue el color del contexto sin tocar 40 archivos. Los semánticos no están en esa familia, así que ingreso/gasto/alerta quedan intactos **por construcción**, no por disciplina.
  - Los derivados (hover, press, soft) salen de `color-mix`, no de valores a mano: la paleta es cerrada pero los 8 colores no comparten luminosidad, y un hover fijo quedaría invisible en unos y estridente en otros.
  - Se tiñe: empresa siempre (Lite y Pro); personal solo en Pro. Verificado — en la Distribuidora `--brand-primary` es `#0EA5E9` y `--income` sigue en `#10B981`.
- [x] **`AccountsPanel` escopado al contexto**. Tenía las cuentas y las deudas escritas a mano, así que en contexto empresa mostraba las personales y calculaba el patrimonio neto con ellas — a 15 cm del KPI "Disponible", que sí salía de la empresa. Verificado: ahora lista Banesco/BofA Operativa/Caja chica. Las deudas se traducen de la forma del módulo 5 (`provider`, `paid/total`, `nextDue`) a la del módulo 4; cambiar el fixture rompería la vista de Deudas, que ya lo consume.
- [x] El aviso de "cuentas en otra moneda, no incluidas" estaba solo en Lite (`HeroBalance`). Agregado al KPI Disponible de Pro: excluir una cuenta entera en silencio es el defecto, no el modo.
- [x] Los 4 KPI de Pro partían el monto en dos líneas (`$` arriba, número abajo) con el sidebar y el panel derecho abiertos: 139 px de tarjeta con 28 px de tipo. Ahora la grilla es `auto-fit minmax(190px, 1fr)` — baja a 2 columnas antes de partir — y el monto usa `clamp` + `nowrap`. Un total de plata cortado en dos líneas se lee como dos números.
- [x] `Money` acepta `style` y **arma una sola cadena** en vez de nodos hermanos, que era la raíz de este defecto y del chip de Análisis.
- [x] **Lo personal también deriva**, no con un fixture aparte. El número escrito a mano decía 12.480,50, que no era ningún total de sus cuentas — coincidía con el saldo de UNA de ellas. Ahora da 15.000,30 (3.420,50 + 12.480 + 340 − 1.240,20) y avisa de las **2 cuentas en bolívares** que descartaba en silencio. Una asimetría "personal es especial" no se sostenía: el mismo defecto que dije cerrar seguía vivo justo donde el usuario aterriza.
- [x] Copy: el aviso decía "1 cuenta … no inclui**das**". Pluralizado completo en los dos lugares.
- [ ] **Dos totales legítimos que se contradicen a la vista**: "Patrimonio neto · USD" del panel **convierte** los bolívares a dólares (19.723,61) y el KPI "Disponible" los **excluye** (15.120,65). Los dos son correctos y están bien rotulados, pero conviven en la misma pantalla con 4.600 dólares de diferencia. Decisión de producto, no de diseño: ¿el disponible también convierte, o el patrimonio también excluye? No lo resuelvo adivinando — con qué tasa se convierte plata de otra moneda es una decisión contable.
- [x] **`business_users`** — `organisms/BusinessAccessPanel.jsx`, con 6 estados en el mapa de rutas de `OW Finance - Grupo Familiar.html`. **No es el grupo familiar con otro nombre**, y eso mandó el diseño: el grupo familiar comparte **cuenta por cuenta** con un nivel por cuenta; una empresa da acceso a **toda** su contabilidad con un rol (un contador que ve 3 de 5 cuentas no puede cerrar un mes). El grupo familiar es recíproco, esto no: el dueño **quita**, el invitado **deja de acceder** — dos acciones, dos textos.
  - Cada rol dice **qué habilita** en su propia fila, no en un tooltip: "Contador" no dice si puede borrar una cuenta; "registra movimientos, no toca la estructura" sí.
  - No se puede quitar al último dueño, y la fila **dice por qué** no hay botón — un control ausente sin explicación se lee como un bug. **Corregido después de revisión**: la cadena de ramas dejaba a un dueño con co-dueño **sin ninguna acción** en su propia fila, así que el mensaje prometía un camino que desaparecía al seguirlo (pasabas el rol y la fila se quedaba muda). Ahora la fila propia siempre tiene salida salvo si sos el último dueño, y el aviso solo se renderiza en tu propia fila — antes un contador leía instrucciones en segunda persona sobre cómo el dueño administra su empresa.
  - Un dueño que se va y un invitado que se va no tienen la misma consecuencia, así que no comparten frase: al dueño se le nombra quién queda al frente.
  - El fixture de revisión trae **dos dueños** (la ruta se llama así); `biz-solo` baja a Marta a contadora para ver el caso del último dueño, que antes era indistinguible de la ruta principal.
  - Solo el dueño invita. Un contador que puede traer gente a la contabilidad de otro es un agujero, no una comodidad.
  - Al quitar acceso se dice **qué se conserva**: los movimientos que registró quedan con su marca de "operado por" (D-016). Sin esa frase, quitar a un contador parece borrar su trabajo del mes.
  - **Segunda ronda de revisión**: los bloques "Cambiar rol" y "Quitar" son frases sobre una persona, no formularios genéricos — no se montan sin una persona resuelta, y el forzado de estados del mapa siembra también a quién. Antes el título de una confirmación destructiva quedaba en "Quitar a ", sin el dato que la hace segura.
  - **Fuga de permisos cerrada**: la rama de invitación pendiente se evaluaba antes que el chequeo de rol, así que un contador veía "Reenviar / Cancelar" mientras la misma tarjeta decía que solo el dueño da o quita acceso. Cancelar una invitación **es** quitar acceso: si solo el dueño invita, solo el dueño cancela.
- [ ] Mobile: la barra de contexto en `ui_kits/mobile/` (hoy solo desktop).
- [x] **Análisis y perfil financiero escopados** (`data/context-analysis.jsx`). Para una empresa el análisis **se deriva** de sus propios movimientos y cántaros — donut, drill-down y KPIs salen de un solo recorrido de las transacciones, así que no pueden contradecirse. Lo personal se conserva tal cual: su drill-down tiene tasa de cambio y subcategoría por transacción, que no se puede inventar desde agregados.
- [x] `AN_NARRATIVE` nuevo: las dos rutas de Análisis tenían las cifras **dentro de la prosa** ("en junio hiciste 29 movimientos… Donaciones ya se pasó del límite"). Sin un lugar donde vivan, escoparlas obligaba a reescribir las frases por contabilidad.
- [x] `AnEmpty`: una contabilidad sin gastos llegaba a `Math.max()` sobre lista vacía y a un donut de nada. Eso no era un estado, era un error. Ahora la comparación con el mes anterior y el aviso de gasto sin cántaro **no se montan** si no hay con qué compararlos, en vez de mostrar 0%.

### 11.4 Mobile — barra de contexto (hecho)

`ui_kits/mobile/components/ContextBarMobile.jsx`, montada en `OW Finance - Fase 2 Contexto.html` (grupo "Mobile").

- [x] El menú es una **hoja**, no un popover: un desplegable de 300 px anclado a la izquierda no cabe en 390 px sin pegarse a los dos bordes, y la lista de contabilidades crece.
- [x] **La línea colapsada NO es el botón acá.** En desktop lo es; en un teléfono 4 px es un blanco imposible para un dedo, muy por debajo del mínimo de 44. Así que la línea queda como **identidad** y el control vive en un chip teñido del header que nunca desaparece y mide 44 exactos (verificado). Una sola forma de cambiar de contabilidad, disponible siempre.
- [x] El atajo a Config **nombra la contabilidad** ("Configuración de Distribuidora Otero") y va después de la lista: no es "Configuración" en abstracto, es la de esa contabilidad.
- [x] De paso: el botón de cerrar de `MobileBottomSheet` medía **26 px**. Ahora 44 — se toca con el pulgar en el borde superior, que es el peor ángulo. Afecta a todas las hojas del kit, no solo a esta.

### 11.5 Arrastres cerrados: "operado por" y presupuesto estricto

- [x] **"Operado por"** (D-016) en `RecentTransactions.jsx` (chip en la línea de meta) y en `TransactionDetailModal.jsx` (fila con nombre completo). Aparece **solo cuando no lo registró el dueño de la cuenta**: la mayoría de los movimientos son propios, así que una marca en todas las filas sería ruido — surge justo cuando cambia el sentido de la fila. Va en la línea de meta, no en una columna nueva: la tabla ya tiene cuatro y Lite tres. En el fixture de la Distribuidora, dos movimientos los registra Marta.
- [x] **Presupuesto estricto** (D-017) — `owfJarOverspend` en `tx-summary.js` + aviso en `TfReview`. **No** va como `valid.reasons` (eso apagaría el botón) ni como un segundo modal: vive en el bloque de revisión, que ya es la superficie de confirmar, con un paso explícito que hay que tocar. Dice el número exacto — cuánto queda, cuánto es el gasto, por cuánto se pasa: "te pasaste" sin cuánto no sirve para decidir.
  - Sin el toggle activado no hay aviso: si no, no es una decisión del usuario sino una opinión de la app sobre en qué gasta.
  - Solo gastos. Un ingreso no puede dejar un cántaro corto y una transferencia mueve plata entre cuentas, no entre cántaros.
  - **Copy corregido en Config**: el hint decía "Bloquea gastar de un cántaro sin saldo", que es exactamente lo que D-017 decidió NO hacer. Prometer un bloqueo que no existe es peor que no explicar nada.

### 11.6 Deudas, temporadas en la barra, y varios grupos

- [x] **Contrapropuesta con historial** (D-013) — `organisms/DebtNegotiation.jsx`. El historial se lee como conversación porque sin él "la deuda dice $180" no explica de dónde sale ese número, y en una negociación de plata el recorrido **es** el acuerdo.
  - Regla que evita la ambigüedad: **el turno es de quien NO propuso último.** Sin eso los dos podrían aceptar montos distintos a la vez y no habría un único número acordado.
  - Monto obligatorio, motivo opcional — y el "opcional" se dice: obligar a justificar cada monto convierte una corrección de $5 en una discusión.
  - Sin tope de rondas (sigue abierto, punto 4), la UI ofrece la salida que **sí** está decidida: quien registró puede **retirar la deuda**. No inventa un límite, pero no deja a los dos atrapados.
- [x] **Congelada** (D-015) — mismo componente en solo lectura: historial visible, cero acciones, y una frase que dice por qué. El chip usa **gris, no rojo**: no es un problema por resolver, es un registro cerrado.
- [x] El monto grande ya no dice "Pendiente" en negociación: dice **"Monto registrado"** (hay otra cifra sobre la mesa) y **"Quedó en"** si está congelada. "Pendiente" contradecía el hilo justo debajo.
- [x] **`JarsDistributionBar` rótula su temporada** cuando hay más de una, y dice cuántas otras tienen otro reparto. Una barra sin rótulo afirma "así reparte la empresa", y con temporadas eso es falso once meses al año. Sin temporadas se comporta igual que antes.
- [x] **`AccountShareDialog` con N grupos** (D-014): **una fila por PERSONA, no por membresía.** Listar a alguien dos veces —una por grupo— daría dos selectores de permiso para una sola pregunta, y dos respuestas a "¿qué ve Mariangela en esta cuenta?". El permiso es de la persona sobre la cuenta; el grupo es solo cómo se conectaron, y eso se dice en la fila ("en Familia Otero y Casa de mis padres").
- [x] **`PillButton` ignoraba `disabled`** — el atributo nunca llegó al `<button>` nativo, así que cada `<PillButton disabled>` era decorativo y el click seguía disparando. Por ahí se colaban una contrapropuesta de **$0** y una invitación **sin destinatario**: la validación estaba bien calculada y no llegaba al DOM. Corregido en `atoms/Buttons.jsx` — con eso se arreglan todos los call sites de una vez, no solo estos dos. `IconButton` tenía la misma falta.
  - Causa de fondo: `PillButtonMobile` **sí** lo soportaba, y esa asimetría hizo asumir paridad donde no la había.
- [x] La ruta "Varios grupos" no demostraba lo que existe para demostrar: todos los miembros estaban en ambos grupos, así que la línea "en \<grupo\>" salía idéntica en cada fila y parecía decoración. Ahora Mariangela está en los dos y Rosa solo en uno.
- [x] "Congelada" apareció dos veces en la misma tarjeta (chip + encabezado del bloque). El bloque ahora dice "Queda como registro": el chip nombra el estado, el bloque explica qué significa.
- [x] Verificado en fresco: **congelada** (rótulo "Quedó en", cero acciones, historial visible) y **el giro de perspectiva** — "Le debés a Carmen" para el viewer 1, "José te debe" para el 3. El fixture describía cada deuda desde el usuario 1 y ninguna vista lo corregía; `owfDebtView` resuelve quién es "el otro" y hacia dónde va la plata según quién mira.
- [x] **El ingreso de Cántaros Pro estaba en un literal** (`expected = 1200`, `realIncome = 0`), así que la Distribuidora —que recibió $6.960— mostraba la barra con $156 en Nómina junto a una tarjeta de $3.744 del mismo cántaro (24× de diferencia), "Ingreso Real $0,00" y una alerta roja de "faltan $1.200 para tu meta" sobre una premisa falsa. Ahora sale de `AN_HOME.income`, igual que Inicio y `AccountsPanel`. Misma familia de defecto que cerré dos veces esta sesión: **cada pantalla tenía su propia copia escrita a mano**.
- [x] **Crear una temporada no refrescaba la barra que está justo arriba**: el editor se actualizaba y la barra seguía sin rótulo, afirmando que describe todo el año — justo lo que la etiqueta existe para evitar. `ProJarsRoute` y `JarsRoute` ahora llevan el contador y lo bajan; además `key` por contexto, que faltaba.
- [x] `DebtNegotiation.jsx` no estaba en los `<script>` de `index.html` aunque `InternalDebtCard` lo referencia — exactamente la trampa de `AddAccountModal`. Sin crash solo porque la tarjeta hoy está huérfana en la app. Agregado antes de que algo la monte.
- [x] **Las categorías eran la última pieza global** — y por eso el aviso de presupuesto estricto seguía inerte en **toda** empresa: `SAMPLE_CATEGORIES`/`OWF_CATEGORIES` eran siempre la lista personal, así que una empresa veía un menú de "Vivienda / Supermercado / Restaurantes" mientras su propio libro mostraba "Insumos / Logística / Nómina", y `categoría→cántaro` nunca resolvía contra sus cántaros. Cerrado con un solo cambio de razón: `SAMPLE_CATEGORIES` entra a `OWF_SCOPED_KEYS`, y las de una empresa se **derivan de sus movimientos** (`owfCategoriesFromTx`) — cada fila ya trae el par `cat`→`jar`, así que la lista y el anclaje salen del mismo lugar y no pueden contradecirse. Una lista aparte se volvería a desincronizar, que es el defecto que esto cierra.
  - `owfCategory`, `owfJarForCategory`, `owfJar` y `owfCategoryOptions` en `tx-catalog.js` resuelven ahora contra el catálogo y los cántaros **vivos**, con la tabla canónica como respaldo. Esto arregla de una vez el anclaje del formulario, el selector de categoría y el aviso, en vez de parchear el aviso solo.
  - Con esto queda cerrada la familia completa de "cada pantalla tenía su propia copia": Inicio, `AccountsPanel`, Cántaros y categorías.
- [x] **Los grupos del selector también estaban clavados a los cántaros personales** (`j1`…`j5`), así que al escopar las categorías ningún grupo casaba con las de una empresa (`b1j*`) y el selector se quedaba **sin nada que explorar**: solo aparecían buscando por texto. Derivados del contexto en `owfApplyContextData` — un grupo por cántaro vivo, más Ingresos. Arreglado en la capa de datos, así que el selector de desktop y el de mobile quedan bien sin tocar ninguno de los dos.
- [ ] `InternalDebtCard` sigue **sin montarse en ninguna vista de la app**: existe, se carga y no la enruta nadie. Falta la pantalla de Deudas internas en Pro/Lite.
- [x] **La confirmación de presupuesto estricto era código muerto**: `owfJarOverspend` resolvía el cántaro con `owfJarForCategory`, que devuelve la tabla estática `OWF_JARS` — sin `amount`, así que `available` salía `NaN` y la función abortaba en **toda** llamada. Y esa tabla es siempre la personal: en contexto empresa devolvía "Necesidades básicas" para una empresa cuyos cántaros son Nómina, Impuestos, Reserva. Peor: el copy de Config que reescribí esta sesión **prometía** esa confirmación. Ahora el mapeo categoría→cántaro sigue saliendo de `OWF_JARS` (para eso sirve) pero el **saldo** sale de `SAMPLE_JARS`, los cántaros vivos del contexto.
- [x] **La etiqueta de temporada nombraba el mes equivocado**: la barra y el editor leían `new Date().getMonth()` (agosto) dentro de una vista de **Mayo 2026**, así que la etiqueta que existe para decir de qué temporada es este reparto nombraba otra. Ahora el mes baja desde la ruta vía `useAppMonth()`, y la línea dice "Mayo rige X" en vez de "Este mes" — con el periodo navegable, "este mes" era ambiguo. (`owfSeasonPending` sigue con el mes real: ahí sí se trata de un mes que empieza de verdad.)
- [ ] "Compartidas conmigo" todavía no dice por qué grupo llega cada cuenta (la otra mitad de D-014).

### 11.3 Arrastres a otros módulos

- [ ] Módulo 1 (Cántaros): `JarRef` gana `business_id`; el reparto es del contexto (D-006). Y con temporadas hay N barras de distribución, no una.
- [ ] Módulo 2 (Transacciones): marca "operado por" en la tabla y en el detalle (D-016). Y la confirmación de "presupuesto estricto" al dejar un cántaro en negativo (D-017).
- [ ] Módulo 5 (Deudas): contrapropuesta con historial visible tipo conversación (D-013), y el estado "congelada" al salir del grupo (D-015).
- [ ] Fase 1: `AccountShareDialog` asume **un** grupo familiar; con varios hay que agrupar los miembros por grupo, y "Compartidas conmigo" tiene que decir por qué grupo llega (D-014).
- [ ] `PROMPT_REDISENO_CENTRAL.md` dice "`layout_mode` del usuario". Con D-009 pasa a ser del contexto — confirmar con backend antes de portar.

---

## 10. Grupo Familiar y Contabilidad Empresarial — módulo nuevo (arquitectura recibida 2026-08-08)

Fuente: `ARQUITECTURA_GRUPO_FAMILIAR_EMPRESAS.md` (documento completo, 4 fases). Prompt de Fase 1 ya escrito: `PROMPT_REDISENO_GRUPO_FAMILIAR_CUENTAS_COMPARTIDAS.md`. **Fase 1 y D-004 diseñados** (§10.1, §10.5); Fases 2–4 sin diseño y sin prompt. Nada portado a Vue.

### 10.0 Por qué toca lo que ya existe

El esquema no es un módulo aislado: extiende tablas que los módulos 1–5 ya dan por cerradas. Cada punto de contacto es un pendiente real de rediseño, no solo de backend:

| Ya existe | Qué le agrega este esquema | Módulo afectado |
|---|---|---|
| `accounts` | `business_id` (null = personal) + `account_user.permission` con 4 niveles + `shared_by_user_id` | 4 (Cuentas) |
| `categories` | `business_id` — categorías propias por empresa ("Nómina", "Alquiler de oficina") | 1, 4 |
| `transactions` | `business_id`, derivado del `account_id` (no lo elige el usuario) | 2 (Transacciones) |
| `debts` | `counterparty_user_id` opcional: deuda vinculada entre miembros del grupo, visible por los dos | 5 (Deudas) |
| Selector Lite/Pro | Un segundo selector de contexto **Personal / Empresa A / Empresa B** que reescopa toda la app | 3 (Home) y todos |
| Cántaros | ¿Se escopan por empresa igual que cuentas/categorías, o siguen siendo personales? Sin resolver | 1 (Cántaros) |

- [ ] Antes de diseñar cualquier pantalla de Fase 2: **resuelto** — no hay dos selectores. El modo pasa a ser preferencia de cada contabilidad (D-009). Ver §11.
- [ ] Módulo 4: la vista `/user/accounts` (todavía inexistente, ver §4.1) tiene que nacer ya sabiendo que una cuenta puede ser compartida y puede pertenecer a una empresa. No diseñarla "personal-only" y parchearla después.
- [ ] Módulo 5: la vista de Deudas tiene que contemplar la deuda con contraparte interna desde el principio (ver D-004).
- [ ] Módulo 1: cerrar la pregunta abierta de cántaros por empresa antes de dar por cerrado Cántaros — si la respuesta es sí, `JarRef` gana `business_id` y la barra de distribución existe por contabilidad.

### 10.1 Fase 1 — Grupo familiar y cuentas compartidas (siguiente)

Diseñado en esta sesión. Documento de revisión: **`OW Finance - Grupo Familiar.html`** (mapa de rutas con los 12 estados).

- [x] `FamilyGroupPanel` — sin grupo / con grupo / invitando / invitación pendiente (reenviar·cancelar) / salir del grupo. El estado vacío **no ofrece compartir nada**: explica el candado en vez de mostrar una acción muerta.
- [x] `AccountShareDialog` — 4 niveles siempre visibles, uno activo por persona, `owner` como estado del dueño (no opción). Sin buscador libre de usuarios. Un solo hue en 4 intensidades (`owfPermTint`).
- [x] `SharedAccountsSection` — "Mis cuentas" vs "Compartidas conmigo" con dueño + badge de permiso.
- [x] Caso `view_balance`: al abrir el detalle no hay lista de movimientos y se dice por qué en una línea — no es un error ni un estado vacío genérico.
- [x] Variantes mobile de las tres (`FamilyGroupSheet` / `AccountShareSheet` / `SharedAccountsSheet`). En mobile los 4 niveles no caben por fila: se elige persona → nivel en dos pasos, filas de 56 px.
- [x] Fixtures `SAMPLE_FAMILY_GROUP` / `SAMPLE_ACCOUNT_SHARES` + vocabulario `OWF_PERMISSIONS` en `ui_kits/lite-desktop/data/family-data.jsx`, snake_case según el prompt.
- [x] Al salir del grupo se dice **cuántas cuentas** se dejan de ver en cada dirección, y que nada se borra.
- [ ] Mover los fixtures a `data/sample-data.contract.js` cuando existan las interfaces TS reales (hoy son propuesta, no contrato).
- [x] Ubicación final de `FamilyGroupPanel`: **resuelta** — vive en `/user/config/family` vía `templates/FamilyRoute.jsx`, alcanzable desde la fila "Grupo familiar" de Config en los dos modos. Config sí tenía diseño (`ConfigRoute.jsx` / `ProConfigRoute.jsx`); la afirmación anterior de que no lo tenía era falsa.
- [ ] Decidir si "Compartidas conmigo" es sección de `AccountsPanel.jsx` o de la futura `/user/accounts` (§4.1) — hoy el organismo es independiente y se puede insertar en cualquiera de las dos.

### 10.2 Fases 2–4

Decisiones cerradas el 2026-08-24 (ver `DECISIONS.md` D-009 a D-018). **Fase 2 arrancada** — ver §11.
- [ ] Fase 3 — Gastos fijos recurrentes: un solo mecanismo para condominio personal y para gasto de empresa; `auto_create` on/off cambia si la UI promete una transacción o solo un recordatorio.
- [ ] Fase 4 — Nómina: empleados, corridas, `payslips` con `deductions` como JSON configurable. El cálculo por país no se diseña hasta saber el país.

### 10.3 Preguntas abiertas del documento — todas resueltas

- [x] ¿Más de un grupo familiar? **Sí**, y una cuenta se comparte en más de uno (D-014).
- [x] `manage` sobre cuenta ajena: **con marca "operado por"**, visible en tabla y detalle (D-016).
- [x] ¿Cántaros por empresa? **Sí** (D-006).
- [ ] ¿País de la nómina real? — sigue abierta, pero es Fase 4 y no bloquea nada hoy.

### 10.4 Registro

- [x] Entradas abiertas en `views-registry.json`: `family-group-panel`, `account-share`, `shared-accounts` (estado `unreviewed` — feature nuevo, sin contraparte Vue, pendiente de revisión).

### 10.5 Deuda con contraparte interna (D-004) — diseñado

`ui_kits/lite-desktop/organisms/InternalDebtCard.jsx`, 4 estados en el documento de revisión.
Cierra la pregunta abierta de D-004: **la contraparte confirma o disputa, no edita**.

- [x] Distinción visual interna/externa: fila de contraparte con avatar + estado de confirmación.
- [x] Estados `pending` (dos vistas según quién registró) / `confirmed` / `disputed`.
- [x] Dirección en palabras ("te debe" / "le debés"), no con signo — un +/- entre dos personas es ambiguo.
- [x] Espejo mobile: `InternalDebtCardMobile` en `DebtComponents.jsx`, y `DebtsList` gana un tercer grupo **"Con tu grupo familiar"** con el conteo de deudas sin confirmar. Va primero y aparte de las externas: tiene acciones y un estado que las externas no tienen, mezclarlas ocultaría lo que hay que atender. Acciones full-width apiladas — "No estoy de acuerdo" no cabe al lado de "Confirmar" en 390 px.
- [ ] Salida del estado `disputed`: hoy la UI remite a hablarlo afuera de la app. Decidir si eso alcanza.
- [ ] `confirmation` y `registered_by_user_id` no están en el documento de arquitectura — proponerlos al contrato o simplificar el flujo.
- [x] Asientos de divergencia abiertos en `DECISIONS.md`: **D-004** (deuda con contraparte interna), **D-005** (`business_id` transversal vs módulo separado), **D-006** (cántaros por empresa, PENDIENTE).
