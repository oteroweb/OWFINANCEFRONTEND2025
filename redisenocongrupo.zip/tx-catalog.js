/* ─── OW Finance · Catálogo común de Transacciones ──────────────────────
 * FUENTE ÚNICA compartida por TODOS los kits (lite-desktop + mobile, Lite + Pro).
 *
 * Principio de producto (no negociable):
 *   • El CÁNTARO es una entidad de orden superior. NUNCA se elige a mano.
 *   • La CATEGORÍA es la unidad común que el usuario elige; cada categoría
 *     declara a qué cántaro aporta (jarId). El cántaro entra anclado.
 *
 * Por eso este archivo define:
 *   OWF_JARS          → los cántaros canónicos (método 55/10/10/10/10).
 *   OWF_CATEGORIES    → categorías comunes, cada una con su jarId.
 *   owfJarForCategory(catRef)  → resuelve el cántaro desde id o nombre de categoría.
 *   owfCategory(catRef)        → resuelve la categoría desde id o nombre.
 *
 * Compatibilidad: los ids de cántaro j1..j5 coinciden con SAMPLE_JARS del kit
 * desktop, para no romper las pantallas de Cántaros/Análisis ya existentes.
 *
 * Extensión adoptada 2026-07-20 (ver DECISIONS.md D-003): cada categoría
 * ahora declara `color` (string|null) y `description` (string) — antes vivían
 * como overrides paralelos en OwCategoryStore (JarsProConfig.jsx), duplicando
 * el modelo. Con esto TODAS las superficies (Pro desktop, mobile, futura
 * vista /user/categories) leen y escriben sobre ESTA única fuente en runtime
 * (`window.OWF_CATEGORIES`), nunca sobre una copia local. `color: null` =
 * hereda el color del cántaro (comportamiento por defecto, sin cambios).
 * Pendiente de adjudicar: si `color`/`description` se agregan también a
 * `CatalogCategory` en el backend Vue real (hoy no están en DESIGN_CONTRACT.md).
 * ──────────────────────────────────────────────────────────────────────── */
(function () {
  /* Cántaros canónicos — método de los cántaros (Harv Eker 55/10/10/10/10).
   * Cada uno: id · name · percent · icon · color · tone(semántico). */
  var OWF_JARS = [
    { id: 'j1', name: 'Necesidades básicas', percent: 55, icon: 'home',        color: '#1E3A8A', tone: 'need' },
    { id: 'j2', name: 'Diversión',           percent: 10, icon: 'celebration', color: '#F59E0B', tone: 'want' },
    { id: 'j3', name: 'Ahorro',              percent: 10, icon: 'savings',     color: '#10B981', tone: 'save' },
    { id: 'j4', name: 'Educación',           percent: 10, icon: 'school',      color: '#0EA5E9', tone: 'grow' },
    { id: 'j5', name: 'Reservas',            percent: 10, icon: 'shield',      color: '#8B5CF6', tone: 'safe' },
  ];

  /* Categorías comunes — kit + las que faltaban del brief (Ropa, Suscripciones,
   * Inversión, Salario, Freelance). kind: 'expense' | 'income'.
   * jarId null = no aporta a ningún cántaro (típico de ingresos).
   * Los `name` coinciden con los usados en los datos demo para que las
   * transacciones existentes sigan resolviendo su cántaro. */
  var OWF_CATEGORIES = [
    /* ── Gastos · Necesidades (j1) ── */
    { id: 1,  name: 'Vivienda',        icon: 'home',           jarId: 'j1', kind: 'expense', color: null, description: '' },
    { id: 2,  name: 'Supermercado',    icon: 'shopping_cart',  jarId: 'j1', kind: 'expense', color: null, description: '' },
    { id: 3,  name: 'Servicios',       icon: 'bolt',           jarId: 'j1', kind: 'expense', color: null, description: '' },
    { id: 4,  name: 'Transporte',      icon: 'directions_car', jarId: 'j1', kind: 'expense', color: null, description: '' },
    { id: 5,  name: 'Salud',           icon: 'favorite',       jarId: 'j1', kind: 'expense', color: null, description: '' },
    /* ── Gastos · Diversión / Quiero (j2) ── */
    { id: 6,  name: 'Restaurantes',    icon: 'restaurant',     jarId: 'j2', kind: 'expense', color: null, description: '' },
    { id: 7,  name: 'Entretenimiento', icon: 'sports_esports', jarId: 'j2', kind: 'expense', color: null, description: '' },
    { id: 8,  name: 'Ropa',            icon: 'checkroom',      jarId: 'j2', kind: 'expense', color: null, description: '' },
    { id: 9,  name: 'Suscripciones',   icon: 'subscriptions',  jarId: 'j2', kind: 'expense', color: null, description: '' },
    /* ── Gastos · Educación (j4) e Inversión / Ahorro (j3) ── */
    { id: 10, name: 'Educación',       icon: 'school',         jarId: 'j4', kind: 'expense', color: null, description: '' },
    { id: 11, name: 'Inversión',       icon: 'trending_up',    jarId: 'j3', kind: 'expense', color: null, description: '' },
    /* ── Gastos · sin cántaro asignado → Reservas (j5) ── */
    { id: 12, name: 'Otros',           icon: 'category',       jarId: 'j5', kind: 'expense', color: null, description: '' },
    /* ── Ingresos · no aportan a cántaro ── */
    { id: 20, name: 'Salario',         icon: 'payments',       jarId: null, kind: 'income', color: null, description: '' },
    { id: 21, name: 'Freelance',       icon: 'work',           jarId: null, kind: 'income', color: null, description: '' },
    { id: 22, name: 'Ingresos',        icon: 'savings',        jarId: null, kind: 'income', color: null, description: '' },
  ];

  /* Agrupación visual del selector de categorías (2.1) — por cántaro.
   * Orden y rótulos de los grupos. */
  var OWF_CATEGORY_GROUPS = [
    { jarId: 'j1', label: 'Necesidades básicas' },
    { jarId: 'j2', label: 'Diversión' },
    { jarId: 'j3', label: 'Ahorro e inversión' },
    { jarId: 'j4', label: 'Educación' },
    { jarId: 'j5', label: 'Reservas y otros' },
    { jarId: null, label: 'Ingresos' },
  ];

  function _norm(s) { return (s == null ? '' : String(s)).trim().toLowerCase(); }

  /* Catálogo de la contabilidad ACTIVA. `window.OWF_CATEGORIES` lo reapunta
   * `owfApplyContextData` al cambiar de contexto; si aún no hay ninguno
   * cargado, cae en la tabla local. Antes se leía `OWF_CATEGORIES` (la
   * personal) siempre, así que una empresa resolvía contra categorías que no
   * son suyas. */
  function owfCatalog() {
    var live = (typeof window !== 'undefined' && window.OWF_CATEGORIES) || null;
    return (live && live.length) ? live : OWF_CATEGORIES;
  }

  /* Resuelve una categoría desde su id (número) o su nombre (string). */
  function owfCategory(ref) {
    if (ref == null) return null;
    var cats = owfCatalog();
    if (typeof ref === 'number') return cats.find(function (c) { return c.id === ref; }) || null;
    var n = _norm(ref);
    return cats.find(function (c) { return _norm(c.name) === n || c.id === ref; }) || null;
  }

  /* Resuelve el cántaro derivado de una categoría (id o nombre). null si no aporta.
   *
   * Busca primero en los cántaros VIVOS del contexto y después en la tabla
   * canónica. `OWF_JARS` es el método 55/10/10/10/10 personal, así que mirando
   * solo ahí una categoría de empresa ("Insumos" → `b1j1`) no resolvía nunca —
   * y con eso se caían el anclaje del formulario y el aviso de presupuesto
   * estricto en toda empresa. */
  function owfJarForCategory(ref) {
    var cat = owfCategory(ref);
    if (!cat || !cat.jarId) return null;
    var live = (typeof window !== 'undefined' && window.SAMPLE_JARS) || [];
    return live.find(function (j) { return j.id === cat.jarId; })
      || OWF_JARS.find(function (j) { return j.id === cat.jarId; })
      || null;
  }

  function owfJar(id) {
    var live = (typeof window !== 'undefined' && window.SAMPLE_JARS) || [];
    return live.find(function (j) { return j.id === id; })
      || OWF_JARS.find(function (j) { return j.id === id; })
      || null;
  }

  /* Color efectivo de una categoría: el propio si se fijó uno, si no el de su cántaro. */
  function owfCategoryColor(ref) {
    var cat = owfCategory(ref);
    if (!cat) return '#64748B';
    if (cat.color) return cat.color;
    var jar = owfJarForCategory(ref);
    return jar ? jar.color : '#64748B';
  }

  /* Opciones listas para un <Picker>: { value:id, label:name, icon, jarId, jar }. */
  function owfCategoryOptions(opts) {
    opts = opts || {};
    return owfCatalog()
      .filter(function (c) { return opts.kind ? c.kind === opts.kind : true; })
      .map(function (c) { return { value: c.id, label: c.name, icon: c.icon, jarId: c.jarId, jar: owfJar(c.jarId) }; });
  }

  var api = { OWF_JARS: OWF_JARS, OWF_CATEGORIES: OWF_CATEGORIES, OWF_CATEGORY_GROUPS: OWF_CATEGORY_GROUPS,
    owfCategory: owfCategory, owfJarForCategory: owfJarForCategory, owfJar: owfJar, owfCategoryOptions: owfCategoryOptions,
    owfCategoryColor: owfCategoryColor };
  if (typeof window !== 'undefined') Object.assign(window, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
