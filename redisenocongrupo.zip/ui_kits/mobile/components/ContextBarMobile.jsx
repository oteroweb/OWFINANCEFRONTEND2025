/* ─── MOBILE-ONLY — ContextBarMobile (Fase 2 · D-009) ─────────────────────
 * Espejo mobile de `ui_kits/lite-desktop/organisms/ContextBar.jsx`. Mismas
 * decisiones (un solo selector, color por contabilidad, modo como subtítulo),
 * dos cambios que el teléfono obliga:
 *
 *   1. El menú es una HOJA, no un popover. Un desplegable de 300 px anclado a
 *      la izquierda no cabe en 390 px sin quedar pegado a los dos bordes, y
 *      una lista de contabilidades puede crecer.
 *
 *   2. En desktop la barra colapsa a una línea de 6 px y esa línea ES el botón.
 *      Acá no puede serlo: 6 px es un blanco imposible para un dedo, muy por
 *      debajo del mínimo de 44. Así que la línea colapsada queda como
 *      IDENTIDAD —te dice en qué contabilidad estás— y el control vive en un
 *      chip teñido dentro del header, que nunca desaparece y siempre mide 44.
 *      Una sola forma de cambiar de contabilidad, disponible siempre.
 *
 * Piezas: ContextChipMobile (va en el header) · ContextSheetMobile (la hoja) ·
 *         ContextLineMobile (la línea de identidad cuando está colapsada).
 * ──────────────────────────────────────────────────────────────────────── */
/* global React, MobileBottomSheet */

function ContextLineMobile({ context }) {
  if (!context) return null;
  /* Sin texto: a 4 px no se lee nada, y el nombre ya está en el chip del
   * header. La línea solo sostiene el color. */
  return <div style={{ height: 4, background: context.color, flexShrink: 0 }} />;
}

function ContextChipMobile({ context, onPress }) {
  if (!context) return null;
  return (
    <button type="button" onClick={onPress}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 7, minHeight: 44, border: 0, cursor: 'pointer', background: 'transparent', padding: '0 4px 0 0', maxWidth: 190 }}>
      <span style={{ width: 26, height: 26, borderRadius: 8, flexShrink: 0, background: context.color, color: '#fff', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12 }}>
        {context.kind === 'personal' ? <span className="material-icons" style={{ fontSize: 15 }}>person</span> : context.name.charAt(0)}
      </span>
      <span style={{ minWidth: 0, textAlign: 'left' }}>
        <span style={{ display: 'block', fontFamily: 'var(--font-body)', fontSize: 13.5, fontWeight: 600, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{context.name}</span>
        <span style={{ display: 'block', fontFamily: 'var(--font-body)', fontSize: 10.5, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--fg-3)', lineHeight: 1.2 }}>{context.mode === 'pro' ? 'Pro' : 'Lite'}</span>
      </span>
      <span className="material-icons" style={{ fontSize: 18, color: 'var(--fg-3)', flexShrink: 0 }}>expand_more</span>
    </button>
  );
}

function ContextSheetMobile({ open, contexts = [], activeId, onClose, onSwitch, onCreate, onGoConfig }) {
  if (!open) return null;
  const active = contexts.find(c => c.id === activeId);
  return (
    <MobileBottomSheet open onClose={onClose} title="Contabilidad">
      <div style={{ padding: '0 12px 24px', display: 'flex', flexDirection: 'column', gap: 4 }}>
        {contexts.map(c => {
          const on = c.id === activeId;
          return (
            <button key={c.id} type="button" onClick={() => { onSwitch && onSwitch(c.id); onClose && onClose(); }}
              style={{ display: 'flex', alignItems: 'center', gap: 13, width: '100%', minHeight: 60, border: 0, cursor: 'pointer', textAlign: 'left', padding: '12px 12px', borderRadius: 14, background: on ? 'var(--surface-2)' : 'transparent' }}>
              <span style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, background: c.color, color: '#fff', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>
                {c.kind === 'personal' ? <span className="material-icons" style={{ fontSize: 18 }}>person</span> : c.name.charAt(0)}
              </span>
              <span style={{ flex: 1, minWidth: 0 }}>
                <span style={{ display: 'block', fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</span>
                <span style={{ display: 'block', fontFamily: 'var(--font-body)', fontSize: 12.5, color: 'var(--fg-2)', marginTop: 1 }}>{c.mode === 'pro' ? 'Pro' : 'Lite'}</span>
              </span>
              {on && <span className="material-icons" style={{ fontSize: 20, color: c.color, flexShrink: 0 }}>check</span>}
            </button>
          );
        })}

        <div style={{ height: 1, background: 'var(--border-hairline)', margin: '8px 12px' }} />

        <button type="button" onClick={() => { onCreate && onCreate(); onClose && onClose(); }}
          style={{ display: 'flex', alignItems: 'center', gap: 13, width: '100%', minHeight: 56, border: 0, cursor: 'pointer', textAlign: 'left', padding: '12px', borderRadius: 14, background: 'transparent' }}>
          <span style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, background: 'var(--surface-3)', color: 'var(--fg-2)', display: 'grid', placeItems: 'center' }}>
            <span className="material-icons" style={{ fontSize: 18 }}>add</span>
          </span>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--fg-1)' }}>Crear una empresa</span>
        </button>

        {/* El atajo a Config es de la contabilidad activa, así que va después
          * de la lista y nombra a cuál — no es "Configuración" en abstracto. */}
        {active && (
          <button type="button" onClick={() => { onGoConfig && onGoConfig(active.id); onClose && onClose(); }}
            style={{ display: 'flex', alignItems: 'center', gap: 13, width: '100%', minHeight: 56, border: 0, cursor: 'pointer', textAlign: 'left', padding: '12px', borderRadius: 14, background: 'transparent' }}>
            <span style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, background: 'var(--surface-3)', color: 'var(--fg-2)', display: 'grid', placeItems: 'center' }}>
              <span className="material-icons" style={{ fontSize: 18 }}>tune</span>
            </span>
            <span style={{ flex: 1, minWidth: 0, fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Configuración de {active.name}</span>
            <span className="material-icons" style={{ fontSize: 20, color: 'var(--fg-3)', flexShrink: 0 }}>chevron_right</span>
          </button>
        )}
      </div>
    </MobileBottomSheet>
  );
}

Object.assign(window, { ContextChipMobile, ContextSheetMobile, ContextLineMobile });
