/* ─── MOBILE-ONLY — Seguridad y PIN ───────────────────────────────────────
 * Espejo mobile de `ui_kits/lite-desktop/organisms/SecurityDialogs.jsx`.
 * Mismos estados y mismas palabras; presentación distinta por dos razones
 * reales, no estéticas:
 *
 *   1. Un PIN en teléfono se teclea en KEYPAD, no en un campo de texto. Un
 *      campo abre el teclado del sistema y tapa media pantalla justo cuando
 *      el usuario necesita ver los puntos de progreso.
 *   2. El PIN es de largo variable (4–6), así que NO se puede auto-avanzar al
 *      llenarse: no hay "último dígito". El botón Continuar aparece a los 4.
 *      Con largo fijo el auto-avance sería lo correcto; acá mentiría.
 *
 * Piezas: SecuritySheetRows (filas, se insertan en la Config mobile) ·
 *         PinSheetMobile (hoja con keypad).
 * Contrato de callbacks idéntico al desktop.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React, MobileBottomSheet, PillButtonMobile, MobileToggle, MobileChip, Divider */

const PINM_MIN = 4, PINM_MAX = 6;

function SecuritySheetRows({ hasPin = false, privacyLock = false, onGo, onChange }) {
  const [ui, setUi] = React.useState({ hasPin, privacyLock, sheet: false, toast: null });
  const label = { fontFamily: 'var(--font-body)', fontSize: 12.5, color: 'var(--fg-2)' };

  const Row = ({ icon, title, hint, first, onPress, right }) => (
    <div>
      {!first && <Divider mx={0} />}
      <div onClick={onPress} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '14px 0', minHeight: 60, cursor: onPress ? 'pointer' : 'default' }}>
        <span className="material-icons" style={{ fontSize: 21, color: 'var(--fg-2)', flexShrink: 0 }}>{icon}</span>
        <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 500, color: 'var(--fg-1)' }}>{title}</span>
          {hint && <span style={label}>{hint}</span>}
        </div>
        {right}
      </div>
    </div>
  );

  const chevron = <span className="material-icons" style={{ fontSize: 20, color: 'var(--fg-3)' }}>chevron_right</span>;

  return (
    <div style={{ padding: '0 16px' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 11, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: 'var(--fg-3)', margin: '18px 0 2px' }}>Seguridad</div>
      <div style={{ background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', padding: '2px 16px', boxShadow: 'var(--shadow-card)' }}>
        <Row first icon="key" title="Contraseña" hint="Se cambia en tu perfil" onPress={() => onGo && onGo('profile')} right={chevron} />
        <Row icon="visibility_off" title="Bloqueo de privacidad" hint="Oculta los montos al salir de la app"
          right={<MobileToggle on={ui.privacyLock} onChange={() => { setUi(u => ({ ...u, privacyLock: !u.privacyLock })); onChange && onChange('privacyLock', !ui.privacyLock); }} />} />
        <Row icon="pin" title={ui.hasPin ? 'PIN de acceso' : 'Crear PIN de acceso'}
          hint={ui.hasPin ? 'Activo · se pide al abrir la app' : 'Sin configurar'}
          onPress={() => setUi(u => ({ ...u, sheet: true }))}
          right={ui.hasPin ? <MobileChip variant="income">Activo</MobileChip> : chevron} />
      </div>

      {ui.toast && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginTop: 10, padding: '11px 14px', borderRadius: 14, background: 'var(--income-soft)', color: 'var(--income-fg)' }}>
          <span className="material-icons" style={{ fontSize: 17 }}>check_circle</span>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600 }}>{ui.toast}</span>
        </div>
      )}

      {ui.sheet && (
        <PinSheetMobile hasPin={ui.hasPin}
          onClose={() => setUi(u => ({ ...u, sheet: false }))}
          onSave={() => setUi(u => ({ ...u, sheet: false, hasPin: true, toast: 'PIN guardado' }))}
          onRemove={() => setUi(u => ({ ...u, sheet: false, hasPin: false, toast: 'PIN eliminado' }))} />
      )}
    </div>
  );
}

/* ── Keypad ───────────────────────────────────────────────────────────────
 * 64 px de alto por tecla (muy por encima del mínimo de 44). El hueco de la
 * esquina inferior izquierda es a propósito: nada que tocar por accidente al
 * lado del 0 y del borrar. */
function PinKeypad({ onDigit, onDelete, disabled }) {
  const key = (content, onPress, ghost) => (
    <button key={String(content)} onClick={disabled ? undefined : onPress} disabled={disabled || !onPress}
      style={{
        height: 62, border: 0, borderRadius: 16, cursor: onPress && !disabled ? 'pointer' : 'default',
        background: ghost || !onPress ? 'transparent' : 'var(--surface-2)',
        color: 'var(--fg-1)', fontFamily: 'var(--font-money)', fontSize: 24, fontWeight: 500,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        opacity: disabled ? 0.4 : 1, transition: 'background 120ms',
      }}>{content}</button>
  );
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => key(n, () => onDigit(String(n))))}
      {key('', null, true)}
      {key(0, () => onDigit('0'))}
      {key(<span className="material-icons" style={{ fontSize: 24, color: 'var(--fg-2)' }}>backspace</span>, onDelete, true)}
    </div>
  );
}

function PinDots({ n, max = PINM_MAX }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, minHeight: 20 }}>
      {Array.from({ length: max }).map((_, i) => (
        <span key={i} style={{
          width: i < n ? 13 : 10, height: i < n ? 13 : 10, borderRadius: 999,
          background: i < n ? 'var(--brand-primary)' : 'var(--surface-3)',
          opacity: i < PINM_MIN || i < n ? 1 : 0.4, transition: 'width 120ms, height 120ms',
        }} />
      ))}
    </div>
  );
}

/* `initialStep` ('pass'|'new'|'repeat'|'remove') y `forceError` existen solo
 * para revisar estados desde el mapa de rutas. En producción salen del flujo. */
function PinSheetMobile({ hasPin = false, initialStep = null, forceError = null, onSave, onRemove, onClose }) {
  const [f, setF] = React.useState({
    step: initialStep || (hasPin ? 'menu' : 'pass'),
    pass: '', pin: '', repeat: '', error: forceError,
  });
  const set = (patch) => setF(s => ({ ...s, ...patch }));
  const label = { fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--fg-2)' };
  const input = { width: '100%', border: '1px solid var(--border-hairline)', borderRadius: 12, background: 'var(--surface-2)', color: 'var(--fg-1)', padding: '14px 14px', fontFamily: 'var(--font-body)', fontSize: 16, outline: 'none' };
  const pad = { padding: '0 20px 26px', display: 'flex', flexDirection: 'column', gap: 16 };

  const Err = ({ children }) => (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 9, padding: '12px 14px', borderRadius: 14, background: 'var(--expense-soft)' }}>
      <span className="material-icons" style={{ fontSize: 18, color: 'var(--expense-fg)' }}>error_outline</span>
      <span style={{ fontFamily: 'var(--font-body)', fontSize: 12.5, lineHeight: 1.5, color: 'var(--expense-fg)', textWrap: 'pretty' }}>{children}</span>
    </div>
  );

  const title = { menu: 'PIN de acceso', pass: hasPin ? 'Cambiar el PIN' : 'Crear un PIN', new: hasPin ? 'Nuevo PIN' : 'Elegí tu PIN', repeat: 'Repetí el PIN', remove: 'Eliminar el PIN' }[f.step];

  /* ── Ya hay PIN: qué querés hacer ─────────────────────────────────────── */
  if (f.step === 'menu') {
    return (
      <MobileBottomSheet open onClose={onClose} title={title}>
        <div style={pad}>
          <p style={{ ...label, lineHeight: 1.55, textWrap: 'pretty' }}>
            Se pide cada vez que abrís la app. No cifra tus datos: es una barrera para que nadie con tu teléfono en la mano vea tus cuentas.
          </p>
          <PillButtonMobile fullWidth icon="edit" onPress={() => set({ step: 'pass', pin: '', repeat: '', error: null })}>Cambiar PIN</PillButtonMobile>
          <PillButtonMobile fullWidth variant="ghost" icon="delete_outline" onPress={() => set({ step: 'remove', pass: '', error: null })}>Eliminar PIN</PillButtonMobile>
        </div>
      </MobileBottomSheet>
    );
  }

  /* ── Contraseña: confirmar identidad antes de tocar el PIN ────────────── */
  if (f.step === 'pass' || f.step === 'remove') {
    const removing = f.step === 'remove';
    return (
      <MobileBottomSheet open onClose={onClose} title={title}>
        <div style={pad}>
          <p style={{ ...label, lineHeight: 1.55, textWrap: 'pretty' }}>
            {removing ? 'La app deja de pedir PIN al abrirse. Tu contraseña sigue igual.' : 'Primero confirmá que sos vos con tu contraseña.'}
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            <span style={label}>Tu contraseña</span>
            <input style={input} type="password" value={f.pass} onChange={e => set({ pass: e.target.value, error: null })} placeholder="••••••••" />
          </div>
          {f.error === 'password' && <Err>{removing ? 'La contraseña no es correcta. El PIN sigue activo.' : 'La contraseña no es correcta.'}</Err>}
          <PillButtonMobile fullWidth variant={removing ? 'danger' : 'primary'} disabled={!f.pass}
            onPress={() => (removing ? onRemove && onRemove() : set({ step: 'new', error: null }))}>
            {removing ? 'Eliminar PIN' : 'Continuar'}
          </PillButtonMobile>
          {hasPin && <PillButtonMobile fullWidth variant="ghost" onPress={() => set({ step: 'menu', error: null })}>Volver</PillButtonMobile>}
        </div>
      </MobileBottomSheet>
    );
  }

  /* ── Keypad: elegir y repetir ─────────────────────────────────────────── */
  const repeating = f.step === 'repeat';
  const val = repeating ? f.repeat : f.pin;
  const enough = val.length >= PINM_MIN;
  const mismatch = repeating && f.repeat.length >= f.pin.length && f.repeat !== f.pin;

  return (
    <MobileBottomSheet open onClose={onClose} title={title}>
      <div style={{ ...pad, gap: 18 }}>
        <p style={{ ...label, textAlign: 'center', lineHeight: 1.5, textWrap: 'pretty' }}>
          {repeating ? 'Escribilo otra vez para confirmar.' : `Entre ${PINM_MIN} y ${PINM_MAX} dígitos. No cifra tus datos ni reemplaza tu contraseña.`}
        </p>
        <PinDots n={val.length} />
        <div style={{ ...label, textAlign: 'center', fontSize: 12, marginTop: -10 }}>
          {mismatch ? ' ' : val.length < PINM_MIN ? `mínimo ${PINM_MIN} dígitos` : `${val.length} dígitos`}
        </div>

        {mismatch && <Err>Los dos PIN no coinciden. Borrá y probá de nuevo.</Err>}
        {f.error === 'server' && <Err>No se pudo guardar el PIN. Seguís sin protección: volvé a intentarlo antes de cerrar.</Err>}

        <PinKeypad
          disabled={val.length >= PINM_MAX}
          onDigit={d => set(repeating ? { repeat: (f.repeat + d).slice(0, PINM_MAX), error: null } : { pin: (f.pin + d).slice(0, PINM_MAX), error: null })}
          onDelete={() => set(repeating ? { repeat: f.repeat.slice(0, -1), error: null } : { pin: f.pin.slice(0, -1), error: null })} />

        {/* Con largo variable el avance es explícito, no automático. */}
        <PillButtonMobile fullWidth disabled={!enough || mismatch}
          onPress={() => (repeating ? (f.repeat === f.pin && onSave && onSave()) : set({ step: 'repeat', repeat: '' }))}>
          {repeating ? 'Guardar PIN' : 'Continuar'}
        </PillButtonMobile>
        <PillButtonMobile fullWidth variant="ghost"
          onPress={() => (repeating ? set({ step: 'new', repeat: '', error: null }) : set({ step: hasPin ? 'menu' : 'pass', pin: '', error: null }))}>
          {repeating ? 'Cambiar el PIN' : 'Volver'}
        </PillButtonMobile>
      </div>
    </MobileBottomSheet>
  );
}

Object.assign(window, { SecuritySheetRows, PinSheetMobile, PinKeypad, PinDots });
