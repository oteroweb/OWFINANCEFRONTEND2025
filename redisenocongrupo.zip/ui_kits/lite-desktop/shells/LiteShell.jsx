/* global React */
const { useState: useShellState } = React;

const USER = { initial: 'J', name: 'José', greeting: 'Buenas tardes,' };

function LiteShell() {
  const [route,         setRouteRaw]      = useShellState(window.__appRoute || 'home');
  const setRoute = (r) => { window.__appRoute = r; setRouteRaw(r); };
  const [menuOpen,      setMenuOpen]      = useShellState(false);
  const [notifOpen,     setNotifOpen]     = useShellState(false);
  const [quickOpen,     setQuickOpen]     = useShellState(false);
  const [aiOpen,        setAIOpen]        = useShellState(false);
  const [balanceVisible,setBalanceVisible] = useShellState(true);
  const [currency]                        = useShellState('USD');
  const hidden = !balanceVisible;

  const [smartOpen, setSmartOpen] = useShellState(false);
  const [smartType, setSmartType] = useShellState('expense');
  const [smartTab,  setSmartTab]  = useShellState('text');
  const [detailTx,  setDetailTx]  = useShellState(null);
  const [onbOpen,   setOnbOpen]   = useShellState(false);
  const [ctxId,     setCtxIdRaw]  = useShellState(window.__owCtx || 'personal');
  const [createOpen, setCreateOpen] = useShellState(false);
  const [bizOnb,    setBizOnb]    = useShellState(false);
  const [addAcct,   setAddAcct]   = useShellState(false);
  const [ctxVer,    setCtxVer]    = useShellState(0);
  /* El modo es de la contabilidad (D-009): cambiar de contexto cambia de shell
   * si esa contabilidad está en el otro modo. */
  const setCtxId = (id) => {
    window.__owCtx = id;
    window.owfApplyContextData && window.owfApplyContextData(id);
    setCtxIdRaw(id);
    setDataVer(v => v + 1);
    const next = (window.OWF_CONTEXTS || []).find(c => c.id === id);
    if (next && next.mode !== 'lite' && window.setMode) window.setMode(next.mode);
  };
  const ctx = (window.OWF_CONTEXTS || []).find(c => c.id === ctxId) || (window.OWF_CONTEXTS || [])[0];
  const accent = (ctx && ctx.color) || 'var(--brand-primary)';
  /* Los datos del contexto se aplican también al montar, no solo al cambiar:
   * el shell puede arrancar ya parado en una empresa después de un remonte. */
  React.useMemo(() => window.owfApplyContextData && window.owfApplyContextData(ctxId), [ctxId]);
  const dataset = (window.owfDatasetFor && window.owfDatasetFor(ctxId)) || {};
  /* Una empresa sin cuentas muestra su estado de arranque en vez de un Inicio
   * de ceros: con cero movimientos no hay nada que resumir, y una pantalla de
   * ceros se lee como un error (ver BusinessEmptyState). En cuanto tiene una
   * cuenta cae a las rutas normales, que ya leen SUS datos. */
  const bizAccounts = ((dataset.SAMPLE_ACCOUNTS) || []).length;
  const isFresh = !!(ctx && ctx.kind === 'business' && !bizAccounts);
  const startBizOnboarding = () => setBizOnb(true);
  const [dataVer, setDataVer]      = useShellState(0);
  /* Se recalcula con `dataVer` porque aplicar o descartar la temporada cambia
   * justamente lo que decide si hay que preguntar. */
  const pendingSeason = React.useMemo(
    () => (window.owfSeasonPending ? window.owfSeasonPending(ctxId, new Date().getMonth()) : null),
    [ctxId, dataVer]);

  // Register the global opener used by every transaction row.
  React.useEffect(() => {
    window.__owOpenTxDetailDesktop = (tx) => setDetailTx(tx);
    window.__owStartOnboarding = () => setOnbOpen(true);
    return () => { if (window.__owOpenTxDetailDesktop) delete window.__owOpenTxDetailDesktop; if (window.__owStartOnboarding) delete window.__owStartOnboarding; };
  }, []);

  const openAI    = () => { setQuickOpen(false); setSmartOpen(false); setAIOpen(true); };
  const openQuick = () => { setAIOpen(false);    setSmartOpen(false); setQuickOpen(true); };
  const openSmart = (type = 'expense', tab = 'text') => { setSmartType(type); setSmartTab(tab); setQuickOpen(false); setSmartOpen(true); };

  return (
    <div data-screen-label={`Lite Desktop · ${route}`} style={{ minHeight: '100vh', background: 'var(--bg-canvas)', color: 'var(--fg-1)', position: 'relative', paddingBottom: 140, ...(window.owfContextVars ? window.owfContextVars(ctx, 'lite') || {} : {}) }}>

      {/* Barra de contexto — se suma por encima del header (D-009) */}
      <ContextBar key={ctxVer} contexts={window.OWF_CONTEXTS || []} activeId={ctxId}
        onSwitch={setCtxId}
        onCreate={() => setCreateOpen(true)}
        onGoConfig={() => setRoute('config')} />

      {/* Header + expanded menu */}
      <div style={{ position: 'relative' }}>
        <LiteHeader
          user={USER} currency={currency}
          balanceVisible={balanceVisible}
          onToggleVisibility={() => setBalanceVisible(v => !v)}
          onOpenMenu={() => { setNotifOpen(false); setMenuOpen(o => !o); }}
          onAvatarClick={() => { setNotifOpen(false); setMenuOpen(o => !o); }}
          onOpenNotifications={() => { setMenuOpen(false); setNotifOpen(o => !o); }}
        />
        <ExpandedMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
      </div>

      {/* Page content */}
      <main style={{ maxWidth: 'var(--container-max)', margin: '0 auto', width: '100%', padding: '12px 32px 32px', boxSizing: 'border-box' }}>
        {isFresh && route === 'home' ? (
          <BusinessEmptyState ctx={ctx} hasAccounts={bizAccounts > 0} onboarded={!!(window.owfBusinessProfile && window.owfBusinessProfile(ctxId))}
            onOnboard={startBizOnboarding}
            onAddAccount={() => setAddAcct(true)}
            onAddTx={openQuick} />
        ) : (
        <React.Fragment>
        {/* App-wide month navigator — present on every route */}
        <MonthNavigator accent={accent} />
        {route === 'home'         && <HomeRoute hidden={hidden} onQuickAdd={openQuick} onGo={setRoute} ctx={ctx} />}
        {route === 'transactions' && <TransactionsRoute hidden={hidden} />}
        {route === 'analisis'     && <AnalisisRoute hidden={hidden} />}
        {route === 'jars'         && <JarsRoute hidden={hidden} onQuickAdd={openQuick} ctx={ctx} />}
        {route === 'dreams'       && <DreamsRoute hidden={hidden} />}
        {route === 'debts'        && <DebtsRoute hidden={hidden} />}
        {route === 'config'       && <ConfigRoute onGo={setRoute} onStartOnboarding={() => setOnbOpen(true)} />}
        {route === 'profile'      && <ProfileRoute onGo={setRoute} />}
        {route === 'finprofile'   && <FinancialProfileRoute onGo={setRoute} />}
        {route === 'family'       && <FamilyRoute onGo={setRoute} />}
        {route === 'notifications' && <NotificationsRoute />}
        </React.Fragment>
        )}
      </main>

      {/* Floating nav pill — Lite signature */}
      <LiteNavPill active={route} onChange={setRoute} onQuickAdd={openQuick} />

      {/* Desktop Quick Action Modal */}
      <DesktopQuickModal
        open={quickOpen}
        onClose={() => setQuickOpen(false)}
        onOpenAI={openAI}
        onSelectAction={(id) => {
          if (id.includes(':')) { const [t, tab] = id.split(':'); openSmart(t, tab); return; }
          const cfg = STM_ACTION_MAP[id]; if (cfg) openSmart(cfg.type, cfg.tab);
        }}
        mode="lite"
      />
      {/* Smart Transaction Modal */}
      <SmartTransactionModal open={smartOpen} onClose={() => setSmartOpen(false)} initialType={smartType} initialTab={smartTab} mode="lite" />
      {/* Transaction detail / edit modal — opened by clicking any row */}
      <TransactionDetailModal open={!!detailTx} tx={detailTx} mode="lite" hidden={hidden} onClose={() => setDetailTx(null)} onChanged={() => setDataVer(v => v + 1)} />
      {/* AI Advisor slide-in panel */}
      <AIAdvisorPanel open={aiOpen} onClose={() => setAIOpen(false)} />
      {/* Notifications (popover desktop · sheet mobile) */}
      <NotificationsPanel open={notifOpen} onClose={() => setNotifOpen(false)} onViewAll={() => setRoute('notifications')} accent="var(--brand-primary)" anchorRight={32} />
      {/* Onboarding post-creación de cuenta */}
      <OnboardingFlow open={onbOpen} onClose={() => setOnbOpen(false)} onFinish={() => { setOnbOpen(false); setRoute('home'); }} />
      <CreateBusinessModal open={createOpen}
        usedColors={(window.OWF_CONTEXTS || []).map(c => c.color)}
        onClose={() => setCreateOpen(false)}
        onCreate={(biz) => { window.owfAddContext && window.owfAddContext(biz); setCreateOpen(false); setRoute('home'); setCtxId(biz.id); }} />
      {/* Wizard propio de la empresa — NO el personal (D-011) */}
      <BusinessOnboardingFlow open={bizOnb} ctx={ctx || {}}
        onClose={() => setBizOnb(false)}
        onFinish={(profile) => { window.owfSaveBusinessProfile && window.owfSaveBusinessProfile(ctxId, profile); setCtxVer(v => v + 1); setDataVer(v => v + 1); setBizOnb(false); }} />
      <AddAccountModal open={addAcct} onClose={() => setAddAcct(false)}
        onCreateAccount={(acct) => { const d = window.owfDatasetFor(ctxId); d.SAMPLE_ACCOUNTS = d.SAMPLE_ACCOUNTS.concat([acct]); window.owfApplyContextData(ctxId); setDataVer(v => v + 1); }} />
      {/* Cambio de temporada: propone, no cambia solo (D-012) */}
      {pendingSeason && <SeasonPrompt ctxId={ctxId} season={pendingSeason} tint={accent}
        onApply={() => setDataVer(v => v + 1)} onDismiss={() => setDataVer(v => v + 1)} />}
    </div>
  );
}

Object.assign(window, { LiteShell });
