/* ─── Pro Desktop Shell — 3-column layout ───────────────────────────────
 * [Sidebar 240px] [Main content flex] [Accounts+Debts panel 280px]
 * Pro primary: cyan (#0EA5E9). Sidebar + AccountsPanel always visible.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */
const { useState: useProState } = React;

const PRO_NAV = [
  { id: 'home',         icon: 'home',            label: 'Inicio' },
  { id: 'transactions', icon: 'receipt_long',     label: 'Transacciones' },
  { id: 'analisis',     icon: 'donut_small',      label: 'Análisis' },
  { id: 'jars',         icon: 'savings',          label: 'Cántaros' },
  { id: 'dreams',       icon: 'auto_awesome',     label: 'Sueños' },
  { id: 'debts',        icon: 'credit_card',      label: 'Deudas' },
  { id: 'config',       icon: 'settings',         label: 'Configuración' },
];

function ProShell() {
  const [route,          setRouteRaw]      = useProState(window.__appRoute || 'home');
  const setRoute = (r) => { window.__appRoute = r; setRouteRaw(r); };
  const [balanceVisible, setBalanceVisible] = useProState(true);
  const [aiOpen,         setAIOpen]         = useProState(false);
  const [quickOpen,      setQuickOpen]      = useProState(false);
  const [smartOpen,      setSmartOpen]      = useProState(false);
  const [smartType,      setSmartType]      = useProState('expense');
  const [smartTab,       setSmartTab]       = useProState('text');
  const [rates,          setRates]          = useProState({ ...DEFAULT_RATES });
  const [notifOpen,      setNotifOpen]      = useProState(false);
  const [detailTx,       setDetailTx]       = useProState(null);
  const [onbOpen,        setOnbOpen]        = useProState(false);
  const [ctxId,          setCtxIdRaw]       = useProState(window.__owCtx || 'personal');
  const [createOpen,     setCreateOpen]     = useProState(false);
  const [bizOnb,         setBizOnb]         = useProState(false);
  const [addAcct,        setAddAcct]        = useProState(false);
  const [ctxVer,         setCtxVer]         = useProState(0);
  /* El modo es de la contabilidad (D-009): cambiar de contexto cambia de shell
   * si esa contabilidad está en el otro modo. */
  const setCtxId = (id) => {
    window.__owCtx = id;
    window.owfApplyContextData && window.owfApplyContextData(id);
    setCtxIdRaw(id);
    setDataVer(v => v + 1);
    const next = (window.OWF_CONTEXTS || []).find(c => c.id === id);
    if (next && next.mode !== 'pro' && window.setMode) window.setMode(next.mode);
  };
  const [navOpen,        setNavOpen]        = useProState(true);   // barra lateral izquierda
  const [panelOpen,      setPanelOpen]      = useProState(true);   // panel derecho (cuentas)
  const [dataVer,        setDataVer]         = useProState(0);
  /* Se recalcula con `dataVer`: aplicar o descartar la temporada cambia justo
   * lo que decide si hay que preguntar. */
  const pendingSeason = React.useMemo(
    () => (window.owfSeasonPending ? window.owfSeasonPending(ctxId, new Date().getMonth()) : null),
    [ctxId, dataVer]);

  React.useEffect(() => {
    window.__owOpenTxDetailDesktop = (tx) => setDetailTx(tx);
    window.__owStartOnboarding = () => setOnbOpen(true);
    return () => { if (window.__owOpenTxDetailDesktop) delete window.__owOpenTxDetailDesktop; if (window.__owStartOnboarding) delete window.__owStartOnboarding; };
  }, []);

  const hidden = !balanceVisible;
  const isMobile = useViewportMobile();
  const appTheme = useAppTheme();
  const openAI    = () => { setQuickOpen(false); setSmartOpen(false); setAIOpen(true); };
  const openQuick = () => { setAIOpen(false);    setSmartOpen(false); setQuickOpen(true); };
  const openSmart = (type = 'expense', tab = 'text') => { setSmartType(type); setSmartTab(tab); setQuickOpen(false); setSmartOpen(true); };

  const ctx = (window.OWF_CONTEXTS || []).find(c => c.id === ctxId) || (window.OWF_CONTEXTS || [])[0];
  /* Los datos del contexto se aplican también al montar, no solo al cambiar:
   * el shell puede arrancar ya parado en una empresa después de un remonte. */
  React.useMemo(() => window.owfApplyContextData && window.owfApplyContextData(ctxId), [ctxId]);
  const dataset = (window.owfDatasetFor && window.owfDatasetFor(ctxId)) || {};
  /* Una empresa sin cuentas muestra su estado de arranque en vez de un Inicio
   * de ceros: con cero movimientos no hay nada que resumir, y una pantalla de
   * ceros se lee como un error (ver BusinessEmptyState). En cuanto tiene una
   * cuenta cae a las rutas normales, que ya leen SUS datos. */
  const bizAccounts = ((dataset.SAMPLE_ACCOUNTS) || []).length;
  const isFresh = !!(ctx && ctx.kind === 'business' && !bizAccounts);
  const startBizOnboarding = () => setBizOnb(true);

  /* Admin tiene su propio layout completo (AdminLayout.vue en el Vue real,
   * sin sidebar/topbar de AppShell) — se renderiza como pantalla completa
   * en vez de dentro del <main> de este shell. */
  if (route === 'admin') return <AdminRoute onExit={() => setRoute('home')} />;

  return (
    <div data-screen-label="Pro Desktop" style={{ display: 'flex', height: '100vh', background: 'var(--bg-canvas)', overflow: 'hidden', position: 'relative', ...(window.owfContextVars ? window.owfContextVars(ctx, 'pro') || {} : {}) }}>

      {/* ── Left sidebar ─────────────────────────────────────────── */}
      {!isMobile && navOpen && (
      <aside style={{ width: 240, flexShrink: 0, background: 'var(--surface-1)', borderRight: '1px solid var(--border-hairline)', display: 'flex', flexDirection: 'column', padding: '24px 16px', boxSizing: 'border-box' }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 8px 28px' }}>
          <div style={{ width: 32, height: 32, borderRadius: 9, background: 'var(--info)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 12, color: '#fff', letterSpacing: '-0.04em' }}>OW</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--fg-1)' }}>Finance</span>
            <span style={{ fontFamily: 'var(--font-body)', fontSize: 10, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--info)', padding: '1px 6px', background: 'var(--info-soft)', borderRadius: 4, alignSelf: 'flex-start' }}>PRO</span>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: 10, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--fg-3)', padding: '0 8px', marginBottom: 6 }}>{t('Menú')}</div>
          {PRO_NAV.map(item => {
            const active = route === item.id;
            return (
              <button key={item.id} onClick={() => setRoute(item.id)}
                onMouseEnter={e => { if (!active) { e.currentTarget.style.background = 'var(--surface-2)'; e.currentTarget.style.color = 'var(--fg-1)'; } }}
                onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--fg-2)'; } }}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', border: 0, cursor: 'pointer', borderRadius: 'var(--radius-sm)', background: active ? 'var(--info-soft)' : 'transparent', color: active ? 'var(--info)' : 'var(--fg-2)', fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: active ? 600 : 500, textAlign: 'left', width: '100%', transition: 'background 150ms, color 150ms' }}>
                <span className="material-icons" style={{ fontSize: 20 }}>{item.icon}</span>
                {t(item.label)}
              </button>
            );
          })}

          <div style={{ height: 1, background: 'var(--border-hairline)', margin: '12px 0' }} />
          <button onClick={openAI}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', border: 0, cursor: 'pointer', borderRadius: 'var(--radius-sm)', background: 'linear-gradient(90deg, rgba(124,58,237,.10) 0%, rgba(14,165,233,.10) 100%)', color: '#8B5CF6', fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: 600, textAlign: 'left', width: '100%' }}>
            <span className="material-icons" style={{ fontSize: 20 }}>auto_awesome</span>
            {t('Asesor IA')}
          </button>
        </nav>

        {/* User */}
        <div style={{ paddingTop: 16, borderTop: '1px solid var(--border-hairline)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px', borderRadius: 'var(--radius-sm)' }}>
            <div style={{ width: 32, height: 32, borderRadius: 16, background: 'var(--info)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>J</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>José Otero</div>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: 11, color: 'var(--fg-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>jose@owfinance.com</div>
            </div>
            <span className="material-icons" style={{ fontSize: 16, color: 'var(--fg-3)', flexShrink: 0 }}>more_vert</span>
          </div>
        </div>
      </aside>
      )}

      {/* ── Main content ─────────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Barra de contexto — se suma por encima del top bar (D-009) */}
        <ContextBar key={ctxVer} contexts={window.OWF_CONTEXTS || []} activeId={ctxId}
          onSwitch={setCtxId}
          onCreate={() => setCreateOpen(true)}
          onGoConfig={() => setRoute('config')} />
        {/* Top bar */}
        <header style={{ height: 60, flexShrink: 0, padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--surface-1)', borderBottom: '1px solid var(--border-hairline)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {!isMobile && <IconButton icon={navOpen ? 'menu_open' : 'menu'} ariaLabel={navOpen ? 'Ocultar menú' : 'Mostrar menú'} onClick={() => setNavOpen(v => !v)} />}
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, color: 'var(--fg-1)' }}>
              {route === 'profile' ? t('Perfil') : route === 'finprofile' ? t('Mi perfil financiero') : route === 'family' ? t('Grupo familiar') : (t(PRO_NAV.find(n => n.id === route)?.label) || t('Inicio'))}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button onClick={openQuick} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 20px', border: 0, cursor: 'pointer', borderRadius: 'var(--radius-pill)', background: 'var(--info)', color: '#fff', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 14, boxShadow: '0 4px 14px rgba(14,165,233,.30)' }}>
              <span className="material-icons" style={{ fontSize: 18 }}>add</span>{t('Agregar')}
            </button>
            <span style={{ width: 1, height: 22, background: 'var(--border-hairline)', margin: '0 2px', flexShrink: 0 }} />
            <IconButton icon={balanceVisible ? 'visibility' : 'visibility_off'} ariaLabel="Ocultar saldos" onClick={() => setBalanceVisible(v => !v)} />
            <IconButton icon={appTheme === 'dark' ? 'light_mode' : 'dark_mode'} ariaLabel={appTheme === 'dark' ? 'Modo claro' : 'Modo oscuro'} onClick={() => window.toggleAppTheme && window.toggleAppTheme()} />
            <div style={{ position: 'relative' }}>
              <IconButton icon="notifications" ariaLabel="Notificaciones" onClick={() => setNotifOpen(o => !o)} />
              <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: 4, background: 'var(--expense)', boxShadow: '0 0 0 2px var(--surface-1)' }} />
            </div>
            {/* Solo visible si auth.role === 'admin' en el Vue real — siempre visible acá porque el mock no modela roles. */}
            <IconButton icon="admin_panel_settings" ariaLabel="Panel de administración" onClick={() => setRoute('admin')} />
            {!isMobile && (
              <React.Fragment>
                <span style={{ width: 1, height: 22, background: 'var(--border-hairline)', margin: '0 2px', flexShrink: 0 }} />
                <IconButton icon="view_sidebar" ariaLabel={panelOpen ? 'Ocultar panel de cuentas' : 'Mostrar panel de cuentas'} onClick={() => setPanelOpen(v => !v)} />
              </React.Fragment>
            )}
          </div>
        </header>

        <main style={{ flex: 1, overflowY: 'auto', padding: '24px 24px 80px', boxSizing: 'border-box' }}>
          {isFresh && route === 'home' ? (
            <BusinessEmptyState ctx={ctx} hasAccounts={bizAccounts > 0} onboarded={!!(window.owfBusinessProfile && window.owfBusinessProfile(ctxId))}
              onOnboard={startBizOnboarding}
              onAddAccount={() => setAddAcct(true)}
              onAddTx={openQuick} />
          ) : (
          <React.Fragment>
          {isMobile && route === 'home' && (
            <Card style={{ marginBottom: 16, padding: 18 }}>
              <AccountsPanel hidden={hidden} rates={rates} mobile={true} />
            </Card>
          )}
          {/* App-wide month navigator — present on every route */}
          <MonthNavigator accent="var(--info)" />
          {route === 'home'         && <ProHomeRoute hidden={hidden} onQuickAdd={openQuick} onGo={setRoute} onOpenAI={openAI} ctx={ctx} />}
          {route === 'transactions' && <TransactionsRoute hidden={hidden} />}
          {route === 'analisis'     && <ProAnalisisRoute hidden={hidden} />}
          {route === 'jars'         && <ProJarsRoute hidden={hidden} ctx={ctx} />}
          {route === 'dreams'       && <DreamsRoute hidden={hidden} />}
          {route === 'debts'        && <DebtsRoute hidden={hidden} />}
          {route === 'config'       && <ProConfigRoute rates={rates} onRatesChange={setRates} onGo={setRoute} onStartOnboarding={() => setOnbOpen(true)} />}
          {route === 'profile'      && <ProfileRoute onGo={setRoute} />}
          {route === 'finprofile'   && <FinancialProfileRoute onGo={setRoute} />}
          {route === 'family'       && <FamilyRoute onGo={setRoute} />}
          {route === 'notifications' && <NotificationsRoute />}
          </React.Fragment>
          )}
        </main>
      </div>

      {/* ── Right panel: Accounts + Debts (desktop only) ─────── */}
      {!isMobile && panelOpen && <AccountsPanel hidden={hidden} rates={rates} />}

      {/* ── Mobile bottom tab bar ─────────────────────────────── */}
      {isMobile && (
        <MobileTabBar
          items={[
            { id: 'home',         icon: 'home',         label: 'Inicio' },
            { id: 'transactions', icon: 'receipt_long', label: 'Movs' },
            { id: 'analisis',     icon: 'donut_small',  label: 'Análisis' },
            { id: 'jars',         icon: 'savings',      label: 'Cántaros' },
            { id: 'dreams',       icon: 'auto_awesome', label: 'Sueños' },
            { id: 'debts',        icon: 'credit_card',  label: 'Deudas' },
            { id: 'config',       icon: 'settings',     label: 'Ajustes' },
          ]}
          active={route}
          onChange={setRoute}
          onQuickAdd={openQuick}
          accent="var(--info)"
        />
      )}

      {/* ── Overlays ─────────────────────────────────────────────── */}
      <DesktopQuickModal
        open={quickOpen}
        onClose={() => setQuickOpen(false)}
        onOpenAI={openAI}
        onSelectAction={(id) => {
          if (id.includes(':')) { const [t, tab] = id.split(':'); openSmart(t, tab); return; }
          const cfg = STM_ACTION_MAP[id]; if (cfg) openSmart(cfg.type, cfg.tab);
        }}
        mode="pro"
      />
      <SmartTransactionModal open={smartOpen} onClose={() => setSmartOpen(false)} initialType={smartType} initialTab={smartTab} mode="pro" rates={rates} />
      <TransactionDetailModal open={!!detailTx} tx={detailTx} mode="pro" hidden={hidden} onClose={() => setDetailTx(null)} onChanged={() => setDataVer(v => v + 1)} />
      <AIAdvisorPanel open={aiOpen} onClose={() => setAIOpen(false)} />
      <NotificationsPanel open={notifOpen} onClose={() => setNotifOpen(false)} onViewAll={() => setRoute('notifications')} accent="var(--info)" anchorRight={24} anchorTop={60} />
      <OnboardingFlow open={onbOpen} onClose={() => setOnbOpen(false)} onFinish={() => { setOnbOpen(false); setRoute('home'); }} />
      {/* Alta de contabilidad de empresa (D-009 · D-011) */}
      <CreateBusinessModal open={createOpen}
        usedColors={(window.OWF_CONTEXTS || []).map(c => c.color)}
        onClose={() => setCreateOpen(false)}
        onCreate={(biz) => { window.owfAddContext && window.owfAddContext(biz); setCreateOpen(false); setRoute('home'); setCtxId(biz.id); }} />
      {/* Wizard propio de la empresa — NO el personal (D-011) */}
      <BusinessOnboardingFlow open={bizOnb} ctx={ctx || {}}
        onClose={() => setBizOnb(false)}
        onFinish={(profile) => { window.owfSaveBusinessProfile && window.owfSaveBusinessProfile(ctxId, profile); setCtxVer(v => v + 1); setDataVer(v => v + 1); setBizOnb(false); }} />
      <AddAccountModal open={addAcct} onClose={() => setAddAcct(false)}
        onCreateAccount={(acct) => { const d = window.owfDatasetFor(ctxId); d.SAMPLE_ACCOUNTS = d.SAMPLE_ACCOUNTS.concat([acct]); window.owfApplyContextData(ctxId); setDataVer(v => v + 1); }} />
      {/* Cambio de temporada: propone, no cambia solo (D-012) */}
      {pendingSeason && <SeasonPrompt ctxId={ctxId} season={pendingSeason} tint={(ctx && ctx.color) || 'var(--brand-primary)'}
        onApply={() => setDataVer(v => v + 1)} onDismiss={() => setDataVer(v => v + 1)} />}
    </div>
  );
}

Object.assign(window, { ProShell });
