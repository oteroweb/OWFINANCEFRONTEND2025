/* ─── Data · Grupo familiar y cuentas compartidas (Fase 1) ───────────────
 * Fixtures PROPUESTOS — todavía no existen en data/sample-data.contract.js.
 * Shape exacta pedida por PROMPT_REDISENO_GRUPO_FAMILIAR_CUENTAS_COMPARTIDAS.md
 * (snake_case) para que el port a Vue no tenga que renombrar nada.
 * Fuente del modelo: ARQUITECTURA_GRUPO_FAMILIAR_EMPRESAS.md §01.
 * ──────────────────────────────────────────────────────────────────────── */

window.SAMPLE_FAMILY_GROUP = {
  id: 1,
  name: 'Familia Otero',
  members: [
    { user_id: 1, name: 'José Otero', email: 'jose@ejemplo.com', is_you: true, status: 'active' },
    { user_id: 2, name: 'Mariangela', email: 'mariangela@ejemplo.com', is_you: false, status: 'active' },
    { user_id: 3, name: 'Carmen Otero', email: 'carmen@ejemplo.com', is_you: false, status: 'invited' },
  ],
};

window.SAMPLE_ACCOUNT_SHARES = [
  {
    account_id: 12, account_name: 'Banesco Mariangela',
    owner_user_id: 2, owner_name: 'Mariangela', shared_with_user_id: 1,
    permission: 'manage', balance: 340.5, currency_symbol: '$',
  },
  {
    account_id: 14, account_name: 'Ahorro conjunto',
    owner_user_id: 2, owner_name: 'Mariangela', shared_with_user_id: 1,
    permission: 'view_full', balance: 1280.0, currency_symbol: '$',
  },
  {
    account_id: 17, account_name: 'Nómina Carmen',
    owner_user_id: 3, owner_name: 'Carmen Otero', shared_with_user_id: 1,
    permission: 'view_balance', balance: 96.75, currency_symbol: '$',
  },
];

/* Vocabulario único de permisos — misma palabra en las 3 pantallas.
 * `weight` es intensidad del MISMO --brand-primary (regla del prompt: no
 * inventar una paleta por nivel; son estados de un concepto, no categorías). */
window.OWF_PERMISSIONS = [
  { id: 'none',         label: 'Sin acceso',      badge: '—',           icon: 'block',           weight: 0,  desc: 'No ve esta cuenta.' },
  { id: 'view_balance', label: 'Solo ve el saldo', badge: 'Solo saldo',  icon: 'lock',            weight: 22, desc: 'Ve el saldo actual, no los movimientos ni el historial.' },
  { id: 'view_full',    label: 'Puede ver todo',   badge: 'Ver todo',    icon: 'visibility',      weight: 55, desc: 'Ve saldo y movimientos completos, sin poder editar.' },
  { id: 'manage',       label: 'Puede gestionar',  badge: 'Gestión',     icon: 'edit',            weight: 100, desc: 'Registra y edita movimientos como si la cuenta fuera suya. No puede compartirla ni borrarla.' },
];

window.owfPermission = (id) => window.OWF_PERMISSIONS.find(p => p.id === id) || window.OWF_PERMISSIONS[0];

/* ─── Deuda con contraparte interna (D-004) ───────────────────────────────
 * `provider: 'personal'` ya existe en SAMPLE_DEBTS. Lo nuevo es
 * counterparty_user_id: la deuda deja de ser texto libre y queda vinculada
 * a otro miembro del grupo. Un solo registro, dos vistas.
 *
 * `confirmation` es el campo de diseño que resuelve la pregunta abierta de
 * D-004 (¿la contraparte edita o solo confirma?): SOLO CONFIRMA.
 *   pending  — registrada, esperando que la otra persona la confirme
 *   confirmed— las dos personas la reconocen
 *   disputed — la contraparte no está de acuerdo
 * `registered_by_user_id` dice quién la creó: el otro nunca edita el monto.
 * ──────────────────────────────────────────────────────────────────────── */
window.SAMPLE_INTERNAL_DEBTS = [
  {
    id: 'id1', name: 'Mitad del mercado', provider: 'personal',
    counterparty_user_id: 2, counterparty_name: 'Mariangela',
    registered_by_user_id: 1, direction: 'they_owe_me',
    balance: 64.5, original: 64.5, currency_symbol: '$',
    confirmation: 'pending', created_at: '19 ago',
  },
  {
    id: 'id2', name: 'Adelanto del alquiler', provider: 'personal',
    counterparty_user_id: 2, counterparty_name: 'Mariangela',
    registered_by_user_id: 2, direction: 'i_owe_them',
    balance: 180, original: 300, currency_symbol: '$',
    confirmation: 'confirmed', created_at: '02 ago',
  },
  {
    id: 'id3', name: 'Taxi al aeropuerto', provider: 'personal',
    counterparty_user_id: 3, counterparty_name: 'Carmen Otero',
    registered_by_user_id: 3, direction: 'i_owe_them',
    balance: 22, original: 22, currency_symbol: '$',
    confirmation: 'disputed', created_at: '17 ago',
    participants: [{ user_id: 1, name: 'José Otero' }, { user_id: 3, name: 'Carmen Otero' }],
    /* Historial de la negociación (D-013). El turno es de quien NO propuso
     * último: acá propuso Carmen (id 3), así que le toca a José (id 1). */
    offers: [
      { by_user_id: 3, by_name: 'Carmen Otero', amount: 22, reason: 'El taxi salió 44 y lo pagué yo', at: '17 ago' },
      { by_user_id: 1, by_name: 'José Otero',   amount: 15, reason: 'Me bajé antes, no hice todo el viaje', at: '18 ago' },
      { by_user_id: 3, by_name: 'Carmen Otero', amount: 18, reason: null, at: '19 ago' },
    ],
  },
  {
    id: 'id4', name: 'Reparación del lavaplatos', provider: 'personal',
    counterparty_user_id: 4, counterparty_name: 'Andrés Otero',
    registered_by_user_id: 1, direction: 'they_owe_me',
    balance: 95, original: 95, currency_symbol: '$',
    /* Congelada (D-015): Andrés salió del grupo. Visible para los dos, solo
     * lectura. No se borra ni bloqueó su salida. */
    confirmation: 'frozen', created_at: '11 jul',
    offers: [
      { by_user_id: 1, by_name: 'José Otero', amount: 95, reason: 'Mitad del técnico', at: '11 jul' },
    ],
  },
];

/* El fixture describe cada deuda desde el punto de vista del usuario 1, así
 * que `counterparty_name` y `direction` NO sirven tal cual para otro viewer:
 * a Carmen le decían "le debés a Carmen". `participants` da los dos nombres y
 * este helper resuelve quién es "el otro" y hacia dónde va la plata según
 * quién mira. UN registro, DOS vistas — también en la copy. */
window.owfDebtView = function (debt, viewerUserId) {
  const parts = debt.participants || [
    { user_id: 1, name: 'José Otero' },
    { user_id: debt.counterparty_user_id, name: debt.counterparty_name },
  ];
  const other = parts.find(p => p.user_id !== viewerUserId) || parts[0];
  /* El fixture está escrito desde el 1: si mira otro, la dirección se invierte. */
  const flip = viewerUserId !== 1;
  const dir = flip
    ? (debt.direction === 'they_owe_me' ? 'i_owe_them' : 'they_owe_me')
    : debt.direction;
  const first = other.name.split(' ')[0];
  return {
    otherName: other.name, otherFirst: first, direction: dir,
    directionText: dir === 'they_owe_me' ? `${first} te debe` : `Le debés a ${first}`,
  };
};

window.OWF_DEBT_CONFIRMATION = {
  pending:   { label: 'Sin confirmar', icon: 'schedule',    bg: 'var(--warning-soft)', fg: 'var(--warning-fg)' },
  confirmed: { label: 'Confirmada',    icon: 'handshake',   bg: 'var(--income-soft)',  fg: 'var(--income-fg)'  },
  disputed:  { label: 'En negociación', icon: 'swap_vert',  bg: 'var(--expense-soft)', fg: 'var(--expense-fg)' },
  /* Congelada usa gris, no rojo: no es un problema por resolver — es un
   * registro cerrado (D-015). */
  frozen:    { label: 'Congelada',     icon: 'ac_unit',     bg: 'var(--surface-2)',    fg: 'var(--fg-2)'       },
};

/* Tinte del nivel: un solo hue, distinta intensidad. */
window.owfPermTint = (weight, on) => ({
  background: on ? `color-mix(in oklab, var(--brand-primary) ${Math.max(weight, 8)}%, var(--surface-1))` : 'var(--surface-2)',
  color: on ? (weight >= 70 ? 'var(--fg-on-brand)' : 'var(--brand-primary-fg-soft)') : 'var(--fg-2)',
});
