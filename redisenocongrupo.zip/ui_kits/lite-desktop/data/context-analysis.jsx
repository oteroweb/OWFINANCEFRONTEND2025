/* ─── Análisis por contabilidad (Fase 2) ──────────────────────────────────
 * Análisis era la última vista que seguía mostrando datos personales sin
 * importar en qué contabilidad estuvieras: `AN_JARS`, `AN_DETALLE`, los KPIs y
 * toda la narrativa ("en junio hiciste 29 movimientos… Donaciones se pasó del
 * límite") estaban escritos a mano en `analisis-data.jsx` y en las dos rutas.
 * Entrar a una empresa y ver tu gasto personal en Donaciones no es un detalle
 * cosmético: es la app diciendo una cifra que no es de esa empresa.
 *
 * Cómo se resuelve: para una empresa el análisis **se deriva** de sus propios
 * movimientos y cántaros — no hay un segundo juego de datos escrito a mano que
 * pueda quedar desincronizado del primero. Lo personal se conserva tal cual
 * está, porque su drill-down tiene detalle por transacción (tasa de cambio,
 * cuenta, subcategoría) que no se puede inventar desde los agregados.
 *
 * Todo lo que las rutas necesitan sale de acá con nombres estables:
 *   AN_JARS · AN_TOTAL · AN_BUDGET · AN_KPIS · AN_DETALLE · AN_NARRATIVE
 *
 * `AN_NARRATIVE` es nuevo. Existe porque la prosa de las dos rutas tenía las
 * cifras incrustadas en el texto; sin un lugar donde vivan, escoparlas
 * significaba reescribir las frases en cada contabilidad.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */

const OWF_MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const OWF_MONTH_ABBR = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

/* El periodo sale de los movimientos, no del reloj. Los datos de muestra están
 * fechados en mayo y el navegador de mes dice "Mayo 2026": tomar `new Date()`
 * hacía que la cabecera dijera "en agosto" arriba de cuatro transacciones de
 * mayo — la página contradiciendo lo que ella misma muestra. */
function owfPeriodFromTx(tx) {
  const counts = {};
  (tx || []).forEach(t => {
    const s = String(t.meta || t.day || '').toLowerCase();
    OWF_MONTH_ABBR.forEach((ab, i) => { if (s.indexOf(ab) >= 0) counts[i] = (counts[i] || 0) + 1; });
  });
  const keys = Object.keys(counts);
  if (!keys.length) return null;
  /* El mes con más movimientos es el periodo que la vista está mostrando. */
  return parseInt(keys.sort((a, b) => counts[b] - counts[a])[0], 10);
}

/* Los cántaros guardan la meta como texto ("$ 14,400") porque es lo que la
 * tarjeta muestra. Para comparar contra lo gastado hace falta el número. */
function owfGoalNumber(jar) {
  if (!jar) return 0;
  if (typeof jar.goal === 'number') return jar.goal;
  const raw = String(jar.goalText || '').replace(/[^\d.]/g, '');
  return raw ? parseFloat(raw) : 0;
}

/* Snapshot de lo personal: lo que ya estaba cargado, tal cual. Se toma una
 * sola vez, antes de que ningún cambio de contexto reasigne los globales. */
const OWF_PERSONAL_ANALYSIS = {
  AN_JARS: window.AN_JARS || [],
  AN_TOTAL: window.AN_TOTAL || 0,
  AN_BUDGET: window.AN_BUDGET || 0,
  AN_KPIS: window.AN_KPIS || [],
  AN_DETALLE: window.AN_DETALLE || [],
  /* Las cifras que estaban escritas dentro de las frases de las dos rutas.
   * No cambian de valor: cambian de lugar, para que se puedan escopar. */
  AN_NARRATIVE: {
    period: 'junio', periodLong: 'junio 2026', prevPeriod: 'mayo',
    txCount: 29, spent: 162.26, budget: 267.00, budgetPct: 51,
    incomeText: '$17.79M', deltaPct: -18,
    unassigned: 17787042.81,
    unassignedNote: 'Un ingreso atípico entró fuera del método 55/10/10/10/10. Asígnalo para que tu análisis cuadre.',
    topShare: 57, topNames: ['Necesidades básicas', 'Ocio / Diversión'],
    overJar: { name: 'Donaciones', spent: 26.17, budget: 20.00, pct: 131 },
  },
  /* Los tres números grandes de Inicio. Estaban escritos a mano en
   * `HomeRoute.jsx` y `ProHomeRoute.jsx`, así que una empresa mostraba el
   * disponible y los ingresos personales con su propio color y su nombre
   * arriba — con los Cántaros correctos justo debajo, contradiciéndose en la
   * misma pantalla.
   *
   * Lo personal se deriva igual que una empresa, no con un fixture aparte: el
   * número escrito a mano decía 12.480,50, que no era ningún total de sus
   * cuentas — coincidía con el saldo de UNA de ellas. Y sin derivar no hay
   * `otherCurrencies`, así que descartaba dos cuentas en bolívares en
   * silencio. Una asimetría "personal es especial" no se sostiene acá. */
  AN_HOME: null,   // se llena abajo, cuando el dataset personal ya existe
};

/* Los totales de Inicio, derivados de las cuentas y los movimientos.
 *
 * CONVIERTE con la tasa que el usuario fija a mano (D-019). Antes excluía las
 * cuentas en otra moneda y avisaba — defendible sola, pero desde que la
 * tarjeta de salud financiera vive a 40 px de distancia y **sí** convierte,
 * los dos números se llamaban igual ("lo que hay en tus cuentas") y diferían
 * en $1.182. Un solo criterio en toda la pantalla. */
function owfHomeTotals(dataset, base = 'USD') {
  const accounts = dataset.SAMPLE_ACCOUNTS || [];
  const tx = dataset.SAMPLE_TX || [];
  const rate = c => (window.owfUserRate ? window.owfUserRate(c) : 1);
  let available = 0;
  const rates = {};
  accounts.forEach(a => {
    const ccy = a.currency || base;
    available += ccy === base ? (a.balance || 0) : (a.balance || 0) / rate(ccy);
    if (ccy !== base) rates[ccy] = rate(ccy);
  });
  available = Math.round(available * 100) / 100;
  const income = tx.filter(t => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const expenses = tx.filter(t => t.amount < 0).reduce((s, t) => s + t.amount, 0);
  const net = income + expenses;
  return {
    available, income, expenses, net,
    savingsRateText: income ? Math.round(net / income * 100) + '%' : '—',
    /* Con qué tasas se convirtió, para poder decirlo al lado del monto. */
    rates,
    asOf: null,
    /* Sin periodo anterior no hay con qué comparar: el chip no se muestra en
     * vez de mostrar 0%. */
    deltaAvailable: null, deltaIncome: null, deltaExpenses: null,
  };
}

/* Cántaros del perfil financiero (`USER_JARS`): la tabla de "propósito" de
 * cada cántaro. Igual que arriba, lo personal se preserva; una empresa usa
 * SUS cántaros con el subtítulo del reparto como propósito. */
const OWF_PERSONAL_PROFILE_JARS = window.USER_JARS || [];

function owfProfileJarsFor(ctxId, dataset) {
  if (ctxId === 'personal') return OWF_PERSONAL_PROFILE_JARS;
  return (dataset.SAMPLE_JARS || []).map(j => ({
    id: j.id, name: j.name, percent: j.percent || 0, color: j.color,
    description: j.subtitle || '',
  }));
}

/* ── Derivación desde los movimientos de la contabilidad ─────────────────
 * Un solo recorrido de las transacciones alimenta el donut, el drill-down y
 * los KPIs, así que las tres cosas no pueden contradecirse entre sí. */
function owfDeriveAnalysis(dataset) {
  const jars = dataset.SAMPLE_JARS || [];
  const tx = dataset.SAMPLE_TX || [];
  const accounts = dataset.SAMPLE_ACCOUNTS || [];
  const acctName = id => (accounts.find(a => a.id === id) || {}).name || '—';

  const spend = tx.filter(t => t.amount < 0);
  const income = tx.filter(t => t.amount > 0);
  const spentByJar = {};
  spend.forEach(t => { const k = t.jar || null; spentByJar[k] = (spentByJar[k] || 0) + Math.abs(t.amount); });

  const anJars = jars
    .map(j => ({ id: j.id, name: j.name, color: j.color, spent: spentByJar[j.name] || 0, budget: owfGoalNumber(j) }))
    .filter(j => j.spent > 0 || j.budget > 0);

  const total = anJars.reduce((s, j) => s + j.spent, 0);
  const budget = anJars.reduce((s, j) => s + j.budget, 0);
  const incomeTotal = income.reduce((s, t) => s + t.amount, 0);

  /* Lo que se gastó sin cántaro asignado. Es el mismo aviso que existe en
   * personal, pero con la cifra real de esta contabilidad — y si es cero, la
   * ruta no muestra el aviso en vez de mostrarlo en $0. */
  const unassigned = spentByJar[null] || 0;

  /* Drill-down: cántaro › categoría › transacción, con los datos que hay.
   * No se inventa tasa de cambio ni subcategoría: lo que no existe no se
   * muestra, en vez de rellenarse con un valor plausible. */
  const detalle = anJars
    .filter(j => j.spent > 0)
    .sort((a, b) => b.spent - a.spent)
    .map(j => {
      const mine = spend.filter(t => t.jar === j.name);
      const byCat = {};
      mine.forEach(t => {
        const c = t.category || 'Sin categoría';
        (byCat[c] = byCat[c] || []).push(t);
      });
      return {
        jar: j.id, name: j.name, count: mine.length, total: j.spent,
        subs: Object.keys(byCat).map(c => ({
          name: c, count: byCat[c].length,
          total: byCat[c].reduce((s, t) => s + Math.abs(t.amount), 0),
          tx: byCat[c].map(t => ({
            nm: t.label, date: t.meta || t.day, acct: acctName(t.acctId),
            cat: c, amt: Math.abs(t.amount), src: null, rate: null,
          })),
        })),
      };
    });

  const fmt = n => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const over = anJars.filter(j => j.budget > 0 && j.spent > j.budget).sort((a, b) => (b.spent / b.budget) - (a.spent / a.budget))[0];
  const top = [...anJars].sort((a, b) => b.spent - a.spent).slice(0, 2);
  const now = new Date();
  const mi = owfPeriodFromTx(tx);
  const month = mi == null ? now.getMonth() : mi;
  const year = now.getFullYear();

  return {
    AN_JARS: anJars,
    AN_TOTAL: total,
    AN_BUDGET: budget,
    AN_DETALLE: detalle,
    AN_KPIS: [
      { label: 'Transacciones visibles', val: String(tx.length), meta: `Periodo: ${OWF_MONTHS[month]} ${year}`, color: 'var(--fg-1)' },
      { label: 'Gastos', val: fmt(total), meta: 'Convertido a USD', color: 'var(--expense-fg)' },
      { label: 'Ingresos', val: fmt(incomeTotal), meta: 'Convertido a USD', color: 'var(--income-fg)' },
      { label: 'Balance del periodo', val: fmt(incomeTotal - total), meta: incomeTotal - total >= 0 ? 'Entró más de lo que salió' : 'Salió más de lo que entró', color: incomeTotal - total >= 0 ? 'var(--income-fg)' : 'var(--expense-fg)' },
    ],
    AN_NARRATIVE: {
      period: OWF_MONTHS[month], periodLong: `${OWF_MONTHS[month]} ${year}`,
      prevPeriod: OWF_MONTHS[(month + 11) % 12],
      txCount: tx.length, spent: total, budget, budgetPct: budget ? Math.round(total / budget * 100) : 0,
      incomeText: fmt(incomeTotal), deltaPct: null,
      unassigned,
      unassignedNote: 'Un gasto quedó fuera de todos los cántaros. Asignalo para que el análisis cuadre.',
      topShare: total ? Math.round(top.reduce((s, j) => s + j.spent, 0) / total * 100) : 0,
      topNames: top.map(j => j.name),
      overJar: over ? { name: over.name, spent: over.spent, budget: over.budget, pct: Math.round(over.spent / over.budget * 100) } : null,
    },
    AN_HOME: owfHomeTotals(dataset),
  };
}

function owfAnalysisFor(ctxId, dataset) {
  if (ctxId === 'personal') {
    /* Perezoso: al construir el snapshot los globales personales pueden no
     * estar cargados todavía, y al primer acceso sí. */
    if (!OWF_PERSONAL_ANALYSIS.AN_HOME) {
      const personal = (window.owfDatasetFor && window.owfDatasetFor('personal')) ||
        { SAMPLE_ACCOUNTS: window.SAMPLE_ACCOUNTS, SAMPLE_TX: window.SAMPLE_TX };
      OWF_PERSONAL_ANALYSIS.AN_HOME = owfHomeTotals(personal);
    }
    return OWF_PERSONAL_ANALYSIS;
  }
  return owfDeriveAnalysis(dataset || {});
}

Object.assign(window, {
  OWF_MONTHS, OWF_MONTH_ABBR, OWF_PERSONAL_ANALYSIS, OWF_PERSONAL_PROFILE_JARS,
  owfGoalNumber, owfPeriodFromTx, owfHomeTotals, owfAnalysisFor, owfDeriveAnalysis, owfProfileJarsFor,
});
