/* ─── Datos por contabilidad (Fase 2 · D-006 / D-009) ─────────────────────
 * Hasta acá los datos eran globales: `SAMPLE_ACCOUNTS`, `SAMPLE_TX`,
 * `SAMPLE_JARS`… y todas las rutas los leían directo. Con Fase 2 eso deja de
 * ser cierto — una empresa tiene sus propias cuentas, cántaros y movimientos.
 *
 * Cómo se escopa sin reescribir las 15 rutas: cada archivo declara sus datos
 * con `const` en su propio script y los publica con `Object.assign(window,…)`.
 * Los CONSUMIDORES, que viven en otros scripts, resuelven ese nombre contra
 * `window` en cada render. Así que reasignar `window.SAMPLE_TX` al cambiar de
 * contabilidad cambia lo que ve toda la app, sin tocar las rutas.
 *
 * Esto es una maqueta: en el backend real el escopado es un `business_id` en
 * la consulta, no un swap de globales.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */

/* `SAMPLE_CATEGORIES` entra al escopado: era la última pieza global. Sin ella,
 * una empresa veía el menú personal —"Vivienda / Supermercado / Restaurantes"—
 * mientras su propio libro mostraba "Insumos / Logística / Nómina", y el
 * mapeo categoría→cántaro nunca resolvía contra los cántaros de la empresa
 * (por eso el aviso de presupuesto estricto era inerte en toda empresa). */
const OWF_SCOPED_KEYS = ['SAMPLE_ACCOUNTS', 'SAMPLE_TX', 'SAMPLE_JARS', 'SAMPLE_DEBTS', 'SAMPLE_DREAMS', 'SAMPLE_CATEGORIES'];

/* Lo personal es lo que ya estaba cargado: se guarda tal cual, una sola vez. */
const OWF_PERSONAL_DATA = {
  SAMPLE_ACCOUNTS: window.SAMPLE_ACCOUNTS || [],
  SAMPLE_TX:       window.SAMPLE_TX || [],
  SAMPLE_JARS:     window.SAMPLE_JARS || [],
  SAMPLE_DEBTS:    window.SAMPLE_DEBTS || [],
  SAMPLE_DREAMS:   window.SAMPLE_DREAMS || [],
  SAMPLE_CATEGORIES: window.SAMPLE_CATEGORIES || [],
};

/* Los grupos del selector de categorías estaban clavados a los cántaros
 * personales (`j1`…`j5`), así que en una empresa ningún grupo casaba con sus
 * categorías (`b1j*`) y el selector se quedaba **sin nada que explorar**: solo
 * buscando por texto aparecían. Se derivan del contexto por el mismo motivo
 * que las categorías: un grupo por cántaro vivo, más Ingresos. */
const OWF_PERSONAL_GROUPS = (window.OWF_CATEGORY_GROUPS || []).slice();

function owfCategoryGroupsFor(dataset) {
  const jars = dataset.SAMPLE_JARS || [];
  if (!jars.length) return OWF_PERSONAL_GROUPS;
  return jars.map(j => ({ jarId: j.id, label: j.name })).concat([{ jarId: null, label: 'Ingresos' }]);
}

/* Categorías de una empresa, derivadas de sus propios movimientos: cada fila
 * ya trae el par `cat` → `jar`, así que la lista y el anclaje al cántaro salen
 * del mismo lugar y no pueden contradecirse. Se derivan en vez de escribirse a
 * mano porque una lista aparte volvería a desincronizarse en el próximo cambio
 * — que es exactamente el defecto que esto cierra. */
function owfCategoriesFromTx(dataset) {
  const jars = dataset.SAMPLE_JARS || [];
  const out = [];
  (dataset.SAMPLE_TX || []).forEach(tx => {
    if (!tx.category || out.some(c => c.name === tx.category)) return;
    const jar = jars.find(j => j.name === tx.jar);
    out.push({
      id: 900 + out.length, name: tx.category,
      icon: (jar && jar.icon) || 'label', color: jar && jar.color,
      jarId: jar ? jar.id : null, kind: tx.amount > 0 ? 'income' : 'expense',
    });
  });
  return out;
}

/* Paleta de cántaros de empresa. No usa el color del contexto: dentro de una
 * contabilidad los cántaros tienen que distinguirse entre sí. */
const OWF_BIZ_JAR_COLORS = ['#1E3A8A', '#0EA5E9', '#8B5CF6', '#475569', '#0D9488', '#B45309'];
const OWF_BIZ_JAR_ICONS = {
  'Insumos y mercancía': 'inventory_2', 'Materiales': 'construction', 'Insumos': 'inventory_2',
  'Nómina': 'groups', 'Operación': 'settings', 'Operación y local': 'storefront',
  'Operación y logística': 'local_shipping', 'Herramientas y transporte': 'build',
  'Herramientas y servicios': 'cloud', 'Impuestos': 'gavel', 'Reserva': 'shield', 'Crecimiento': 'trending_up',
};

/* Convierte el reparto que devuelve el wizard (D-011) en cántaros de verdad.
 * Nacen en cero: la empresa todavía no facturó nada, y poner montos de ejemplo
 * haría que su Inicio mienta desde el primer día. */
function owfJarsFromPlan(plan) {
  return (plan || []).map(([name, percent], i) => ({
    id: 'bj' + i, name, subtitle: `${percent}% del ingreso`, percent, type: 'percent',
    icon: OWF_BIZ_JAR_ICONS[name] || 'savings', color: OWF_BIZ_JAR_COLORS[i % OWF_BIZ_JAR_COLORS.length],
    amount: 0, progress: 0, goalText: '$ 0', statusText: 'Sin movimientos', tone: 'brand',
  }));
}

/* Dos empresas de muestra con datos propios, para poder ver el escopado
 * funcionando sin tener que crear una empresa a mano cada vez. */
const OWF_CTX_DATA = {
  personal: OWF_PERSONAL_DATA,

  b1: {
    SAMPLE_ACCOUNTS: [
      { id: 101, name: 'Banesco · Empresa',  short: 'BAN', type: 'bank', currency: 'VES', balance: 186420.00, last4: '3311', color: '#0EA5E9', group: 'Mis cuentas' },
      { id: 102, name: 'BofA · Operativa',   short: 'BofA', type: 'bank', currency: 'USD', balance: 14280.65, last4: '9014', color: '#1E3A8A', group: 'Mis cuentas' },
      { id: 103, name: 'Caja chica',         short: 'CAJ', type: 'cash', currency: 'USD', balance: 840.00, color: '#10B981', group: 'Mis cuentas' },
    ],
    SAMPLE_JARS: [
      { id: 'b1j1', name: 'Insumos y mercancía', subtitle: '50% del ingreso', percent: 50, type: 'percent', icon: 'inventory_2', color: '#1E3A8A', amount: 9210.00, progress: 64, goalText: '$ 14,400', statusText: '64% usado', tone: 'brand' },
      { id: 'b1j2', name: 'Operación y logística', subtitle: '17% del ingreso', percent: 17, type: 'percent', icon: 'local_shipping', color: '#0EA5E9', amount: 2140.00, progress: 43, goalText: '$ 4,896', statusText: '43% usado', tone: 'brand' },
      { id: 'b1j3', name: 'Nómina', subtitle: '13% del ingreso', percent: 13, type: 'percent', icon: 'groups', color: '#8B5CF6', amount: 3744.00, progress: 100, goalText: '$ 3,744', statusText: 'Apartado', tone: 'income' },
      { id: 'b1j4', name: 'Impuestos', subtitle: '12% del ingreso', percent: 12, type: 'percent', icon: 'gavel', color: '#475569', amount: 3456.00, progress: 78, goalText: '$ 3,456', statusText: '78% usado', tone: 'warn' },
      { id: 'b1j5', name: 'Reserva', subtitle: '8% del ingreso', percent: 8, type: 'percent', icon: 'shield', color: '#0D9488', mode: 'accumulate', amount: 5180.00, progress: 22, goalText: '$ 2,304', statusText: 'Acumula', tone: 'brand' },
    ],
    SAMPLE_TX: [
      { label: 'Factura 1042 · Comercial Ruiz', meta: 'Hoy · 26 May · 10:15', amount: 4820.00, day: 'Hoy · lun 26 May', category: 'Ingresos', jar: null, jarColor: null, acctId: 102 },
      { label: 'Compra de mercancía · Mayorista', meta: 'Hoy · 26 May · 8:40', amount: -2310.00, day: 'Hoy · lun 26 May', category: 'Insumos', jar: 'Insumos y mercancía', jarColor: '#1E3A8A', acctId: 102 },
      { label: 'Flete · entrega Valencia', meta: 'dom 25 May', amount: -180.00, day: 'dom 25 May', category: 'Logística', jar: 'Operación y logística', jarColor: '#0EA5E9', acctId: 103 },
      { label: 'Quincena · 4 empleados', meta: 'sáb 24 May', amount: -1872.00, day: 'sáb 24 May', category: 'Nómina', jar: 'Nómina', jarColor: '#8B5CF6', acctId: 102, operated_by_name: 'Marta Rivas' },
      { label: 'Factura 1041 · Bodegón Norte', meta: 'sáb 24 May', amount: 2140.00, day: 'sáb 24 May', category: 'Ingresos', jar: null, jarColor: null, acctId: 101 },
      { label: 'IVA · declaración mayo', meta: 'vie 23 May', amount: -1104.00, day: 'vie 23 May', category: 'Impuestos', jar: 'Impuestos', jarColor: '#475569', acctId: 101, operated_by_name: 'Marta Rivas' },
      { label: 'Alquiler del depósito', meta: 'vie 23 May', amount: -900.00, day: 'vie 23 May', category: 'Operación', jar: 'Operación y logística', jarColor: '#0EA5E9', acctId: 102 },
    ],
    SAMPLE_DEBTS: [
      { id: 'b1d1', name: 'Camioneta de reparto', provider: 'loan', merchant: 'Banesco', balance: 8400.00, original: 14000.00, paid: 8, total: 24, nextDue: '05 jun', next: 583.33, status: 'on-track', currency: 'USD', apr: 14 },
    ],
    /* Una empresa no tiene "sueños": eso es una meta personal. La ruta queda
     * vacía a propósito, no por falta de datos de muestra. */
    SAMPLE_DREAMS: [],
  },

  b2: {
    SAMPLE_ACCOUNTS: [
      { id: 201, name: 'Mercantil · MG',  short: 'MER', type: 'bank', currency: 'USD', balance: 6210.00, last4: '7742', color: '#8B5CF6', group: 'Mis cuentas' },
    ],
    SAMPLE_JARS: [
      { id: 'b2j1', name: 'Nómina', subtitle: '40% del ingreso', percent: 40, type: 'percent', icon: 'groups', color: '#8B5CF6', amount: 2400.00, progress: 80, goalText: '$ 3,000', statusText: '80% usado', tone: 'brand' },
      { id: 'b2j2', name: 'Operación', subtitle: '18% del ingreso', percent: 18, type: 'percent', icon: 'settings', color: '#0EA5E9', amount: 610.00, progress: 45, goalText: '$ 1,350', statusText: '45% usado', tone: 'brand' },
      { id: 'b2j3', name: 'Impuestos', subtitle: '15% del ingreso', percent: 15, type: 'percent', icon: 'gavel', color: '#475569', amount: 1125.00, progress: 100, goalText: '$ 1,125', statusText: 'Apartado', tone: 'income' },
      { id: 'b2j4', name: 'Crecimiento', subtitle: '12% del ingreso', percent: 12, type: 'percent', icon: 'trending_up', color: '#0D9488', mode: 'accumulate', amount: 480.00, progress: 53, goalText: '$ 900', statusText: '53% usado', tone: 'brand' },
      { id: 'b2j5', name: 'Reserva', subtitle: '15% del ingreso', percent: 15, type: 'percent', icon: 'shield', color: '#1E3A8A', mode: 'accumulate', amount: 3300.00, progress: 29, goalText: '$ 1,125', statusText: 'Acumula', tone: 'brand' },
    ],
    SAMPLE_TX: [
      { label: 'Retainer mayo · Cliente A', meta: 'Hoy · 26 May · 9:30', amount: 3500.00, day: 'Hoy · lun 26 May', category: 'Ingresos', jar: null, jarColor: null, acctId: 201 },
      { label: 'Honorarios · consultora externa', meta: 'dom 25 May', amount: -1200.00, day: 'dom 25 May', category: 'Nómina', jar: 'Nómina', jarColor: '#8B5CF6', acctId: 201 },
      { label: 'Suscripciones · software', meta: 'sáb 24 May', amount: -218.00, day: 'sáb 24 May', category: 'Operación', jar: 'Operación', jarColor: '#0EA5E9', acctId: 201 },
      { label: 'ISLR · anticipo', meta: 'vie 23 May', amount: -525.00, day: 'vie 23 May', category: 'Impuestos', jar: 'Impuestos', jarColor: '#475569', acctId: 201 },
    ],
    SAMPLE_DEBTS: [],
    SAMPLE_DREAMS: [],
  },
};

/* Perfiles guardados por el wizard de empresa (D-011). */
const OWF_BIZ_PROFILES = window.__owBizProfiles || (window.__owBizProfiles = {});

function owfEmptyDataset() {
  return { SAMPLE_ACCOUNTS: [], SAMPLE_TX: [], SAMPLE_JARS: [], SAMPLE_DEBTS: [], SAMPLE_DREAMS: [] };
}

/* Una empresa creada en la sesión no tiene dataset hasta que se le pide uno:
 * nace vacía, que es justamente lo que su estado inicial dice. */
function owfDatasetFor(ctxId) {
  if (!OWF_CTX_DATA[ctxId]) OWF_CTX_DATA[ctxId] = owfEmptyDataset();
  return OWF_CTX_DATA[ctxId];
}

/* Aplica el dataset de una contabilidad a los globales que leen las rutas.
 * Análisis y el perfil financiero no viven en el dataset: se derivan de él
 * (ver `context-analysis.jsx`), así que se recalculan en cada cambio en vez de
 * guardarse — un cántaro nuevo o un movimiento nuevo tienen que aparecer en el
 * análisis sin que nadie lo sincronice a mano. */
function owfApplyContextData(ctxId) {
  const d = owfDatasetFor(ctxId);
  /* Las categorías de una empresa se derivan al aplicar, no se guardan: así
   * un movimiento o un cántaro nuevo aparece en el menú sin sincronizar nada. */
  if (ctxId !== 'personal' && !(d.SAMPLE_CATEGORIES || []).length) d.SAMPLE_CATEGORIES = owfCategoriesFromTx(d);
  OWF_SCOPED_KEYS.forEach(k => { window[k] = d[k] || []; });
  /* `OWF_CATEGORIES` es el nombre que leen el selector de categoría y
   * `owfJarForCategory`. Apunta a las del contexto o vuelve a las personales. */
  window.OWF_CATEGORIES = window.SAMPLE_CATEGORIES.length ? window.SAMPLE_CATEGORIES : OWF_PERSONAL_DATA.SAMPLE_CATEGORIES;
  /* Y los grupos, del mismo lugar: si no, el selector no tiene dónde poner las
   * categorías y muestra una lista vacía. */
  window.OWF_CATEGORY_GROUPS = ctxId === 'personal' ? OWF_PERSONAL_GROUPS : owfCategoryGroupsFor(d);
  const an = (window.owfAnalysisFor && window.owfAnalysisFor(ctxId, d)) || {};
  Object.keys(an).forEach(k => { window[k] = an[k]; });
  if (window.owfProfileJarsFor) window.USER_JARS = window.owfProfileJarsFor(ctxId, d);
  return d;
}

/* Guarda lo que respondió el wizard y deja los cántaros armados. Es el paso
 * que hacía falta para que terminar el wizard signifique algo: antes el
 * reparto propuesto se mostraba y se tiraba. */
function owfSaveBusinessProfile(ctxId, profile) {
  OWF_BIZ_PROFILES[ctxId] = profile;
  const d = owfDatasetFor(ctxId);
  d.SAMPLE_JARS = owfJarsFromPlan(profile && profile.jars);
  if (window.__owCtx === ctxId) owfApplyContextData(ctxId);
  return d;
}

function owfBusinessProfile(ctxId) { return OWF_BIZ_PROFILES[ctxId] || null; }

Object.assign(window, {
  OWF_CTX_DATA, OWF_SCOPED_KEYS, OWF_PERSONAL_DATA,
  owfDatasetFor, owfApplyContextData, owfSaveBusinessProfile, owfBusinessProfile, owfJarsFromPlan,
  owfCategoriesFromTx, owfCategoryGroupsFor, OWF_PERSONAL_GROUPS,
});
