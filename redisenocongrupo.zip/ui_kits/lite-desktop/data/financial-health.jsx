/* ─── Salud financiera · días de libertad / runway ────────────────────────
 * Un solo lugar donde se calcula "cuánto aguanto sin ingresar nada".
 * Decisiones de Jose (2026-08-28), y por qué cada una cambia el número:
 *
 *   · DIVISOR: los cántaros de GASTO completos. Los de meta no cuentan —
 *     dejar de ahorrar no es un gasto que tengas que seguir pagando. Los
 *     gastos fijos declarados serían mejores, pero son Fase 3 y no existen.
 *   · NUMERADOR: todo lo líquido, incluido lo apartado para sueños. Es tu
 *     plata; el escenario es "si dejo de ingresar, ¿cuánto aguanto?".
 *   · MONEDA: convierte con la tasa que el usuario fija a mano, y el número
 *     dice con cuál convirtió. Sin alarma ni fecha, por decisión explícita.
 *   · PATRIMONIO: resta las deudas COMPLETAS, y muestra aparte lo que vence
 *     este mes. Debés $8.400 aunque pagues en 24 cuotas.
 *   · NOMBRE: "días de libertad" en lo personal, "runway" en una empresa —
 *     el mismo cálculo mide otra cosa: cuánto aguanta operando sin facturar.
 *
 * Qué es un cántaro de meta: uno que ACUMULA en vez de reiniciarse cada mes.
 * Es la distinción que ya existe en Cántaros Pro (`mode: 'accumulate'`), no
 * una bandera nueva en paralelo.
 * ──────────────────────────────────────────────────────────────────────── */
/* global window */

/* La tasa la fija el usuario en Configuración. Arranca en la del fixture para
 * no obligar a configurarla antes de ver un número. */
function owfUserRate(ccy) {
  if (!ccy || ccy === 'USD') return 1;
  const set = window.OWF_USER_RATES || {};
  if (set[ccy]) return set[ccy];
  const d = (window.DEFAULT_RATES || {})[ccy];
  return (d && (d.current || d.official)) || 1;
}

function owfSetUserRate(ccy, value) {
  window.OWF_USER_RATES = { ...(window.OWF_USER_RATES || {}), [ccy]: Number(value) || 1 };
  return window.OWF_USER_RATES;
}

function owfIsGoalJar(j) { return j && j.mode === 'accumulate'; }

/* Total líquido en la moneda base, convirtiendo con la tasa del usuario.
 * Devuelve también qué tasas usó, para poder decirlo al lado del número. */
function owfLiquid(accounts, base = 'USD') {
  let total = 0;
  const used = {};
  (accounts || []).forEach(a => {
    const ccy = a.currency || base;
    const rate = owfUserRate(ccy);
    total += ccy === base ? (a.balance || 0) : (a.balance || 0) / rate;
    if (ccy !== base) used[ccy] = rate;
  });
  return { total: Math.round(total * 100) / 100, rates: used };
}

/* Gasto mensual esencial: la porción del ingreso que va a cántaros de gasto.
 * Con `percent` describe la intención del mes, que es lo que la app conoce
 * hasta que Fase 3 permita declarar gastos fijos de verdad. */
function owfEssentialMonthly(jars, income) {
  const spend = (jars || []).filter(j => !owfIsGoalJar(j));
  const pct = spend.reduce((s, j) => s + (Number(j.percent) || 0), 0);
  return Math.round((income || 0) * (pct / 100) * 100) / 100;
}

/* La palanca: la categoría de gasto más grande del mes, no el cántaro.
 * Un cántaro no se puede cancelar — "Necesidades" no es una acción. Una
 * categoría sí: "Vivienda", "Insumos". Por eso la frase la nombra a ella.
 *
 * Devuelve **cuántos días se ganan** recortándola, no qué tajada del total
 * representa. La primera versión dividía el gasto MENSUAL entre el burn
 * DIARIO, así que daba 11 días donde el recorte vale 80: el número no era una
 * tajada de nada, porque los 128 días ya asumen que Vivienda se repite todos
 * los meses. Sacarla no libera su monto una vez, baja el gasto de cada mes. */
function owfTopLever(tx, jars, liquid, burnMonthly, currentDays) {
  const goalNames = (jars || []).filter(owfIsGoalJar).map(j => j.name);
  const byCat = {};
  (tx || []).forEach(t => {
    if (!(t.amount < 0) || !t.category) return;
    if (goalNames.indexOf(t.jar) >= 0) return;   // aportes a meta no son gasto
    byCat[t.category] = (byCat[t.category] || 0) + Math.abs(t.amount);
  });
  const top = Object.keys(byCat).sort((a, b) => byCat[b] - byCat[a])[0];
  if (!top) return null;
  const amount = Math.round(byCat[top] * 100) / 100;
  const rest = burnMonthly - amount;
  /* Si la categoría es todo el gasto, recortarla no da "X días más": da un
   * horizonte sin fin, y prometer un número ahí sería inventarlo. */
  const gainDays = rest > 0 ? Math.floor(liquid / (rest / 30)) - currentDays : null;
  return { category: top, amount, gainDays };
}

/* La cuota del mes. Los fixtures personales la llaman `nextDueAmount` y los de
 * empresa `next`: dos nombres para el mismo campo, y leyendo solo uno la deuda
 * personal salía en $0 mientras la tarjeta afirmaba "cuota incluida". Se
 * normaliza acá hasta que el contrato de datos unifique el nombre. */
function owfDebtDue(d) {
  const v = d && (d.next != null ? d.next : d.nextDueAmount);
  return Number(v) || 0;
}

/* `null` en `days` significa "no hay con qué calcular", y `missing` dice qué
 * falta: la tarjeta muestra el hueco en vez de un número inventado. */
function owfFinancialHealth(ctxId) {
  const d = (window.owfDatasetFor && window.owfDatasetFor(ctxId)) || {};
  const isBiz = ctxId && ctxId !== 'personal';
  const jars = d.SAMPLE_JARS || [];
  const tx = d.SAMPLE_TX || [];
  const debts = d.SAMPLE_DEBTS || [];
  const liq = owfLiquid(d.SAMPLE_ACCOUNTS);
  const income = (tx.filter(t => t.amount > 0).reduce((s, t) => s + t.amount, 0)) || 0;

  const debtTotal = Math.round(debts.reduce((s, x) => s + (x.balance || 0), 0) * 100) / 100;
  const dueThisMonth = Math.round(debts.reduce((s, x) => s + owfDebtDue(x), 0) * 100) / 100;
  const netWorth = Math.round((liq.total - debtTotal) * 100) / 100;

  const base = {
    isBiz, label: isBiz ? 'Runway' : 'Días de libertad',
    liquid: liq.total, rates: liq.rates, netWorth, debtTotal, dueThisMonth,
  };

  if (!jars.length) return { ...base, days: null, missing: 'jars' };
  const monthly = owfEssentialMonthly(jars, income);
  if (!monthly) return { ...base, days: null, missing: income ? 'jars' : 'tx' };

  /* La cuota de deuda no está en ningún cántaro, y sin ella el número
   * exagera: hay que seguir pagándola aunque dejes de ingresar. */
  const burnMonthly = Math.round((monthly + dueThisMonth) * 100) / 100;
  const daily = burnMonthly / 30;
  const days = Math.floor(liq.total / daily);

  return {
    ...base, days, months: Math.floor(days / 30), burnMonthly, dailyBurn: Math.round(daily * 100) / 100,
    lever: owfTopLever(tx, jars, liq.total, burnMonthly, days),
    /* Bajo = menos de 3 meses. Es el umbral que usa cualquier fondo de
     * emergencia, no un número elegido para que se vea bien. */
    low: days < 90,
  };
}

/* Consejo del asesor, derivado del contexto activo.
 *
 * Era una cadena literal con la tasa, el monto y el nombre del cántaro escritos
 * dentro ("tu tasa de ahorro es 42%… al jar de emergencia"), en tres copias:
 * la tira de Inicio, el panel de Pro y el de mobile. Al derivar el KPI de la
 * tasa, esas copias quedaron varadas afirmando 42% al lado de un 9% real — y
 * en una empresa recomendaban un "jar de emergencia" que no existe.
 *
 * Devuelve piezas (`rate`, `jar`, `amount`, `text`) para que cada vista las
 * pinte a su manera sin volver a escribir la frase. */
function owfAdvisorInsight(ctxId) {
  const id = ctxId || window.__owCtx || 'personal';
  const h = (window.owfFinancialHealth && window.owfFinancialHealth(id)) || {};
  const rate = (window.AN_HOME || {}).savingsRateText || '—';
  const jars = (window.owfDatasetFor ? window.owfDatasetFor(id).SAMPLE_JARS : window.SAMPLE_JARS) || [];
  /* El cántaro que se sugiere sale de los que EXISTEN en esta contabilidad:
   * el de meta con menos avance, o el último si ninguno acumula. */
  const goal = jars.filter(j => window.owfIsGoalJar && window.owfIsGoalJar(j))
    .sort((a, b) => (a.progress || 0) - (b.progress || 0))[0] || jars[jars.length - 1] || null;
  const jar = goal ? goal.name : null;
  const money = v => '$' + Math.round(v).toLocaleString('en-US');

  if (!jar || h.days == null) {
    return { rate, jar: null, amount: null, text: 'Todavía no tengo suficiente para analizar. Repartió tus cántaros y registra unos movimientos.' };
  }
  /* El monto sugerido es un décimo del gasto mensual: una cifra que se puede
   * mover sin rearmar el presupuesto. No un literal de otra contabilidad. */
  const amount = Math.max(10, Math.round((h.burnMonthly || 0) / 10 / 10) * 10);
  const low = h.low;
  return {
    rate, jar, amount,
    low,
    text: low
      ? `Tu tasa de ahorro es ${rate} y aguantás ${h.months} ${h.months === 1 ? 'mes' : 'meses'}. Mover ${money(amount)} a ${jar} lo empuja.`
      : `Tu tasa de ahorro es ${rate}. Podés mover ${money(amount)} a ${jar} sin apretar el mes.`,
  };
}

Object.assign(window, {
  owfFinancialHealth, owfUserRate, owfSetUserRate, owfLiquid,
  owfEssentialMonthly, owfTopLever, owfIsGoalJar, owfDebtDue, owfAdvisorInsight,
});
