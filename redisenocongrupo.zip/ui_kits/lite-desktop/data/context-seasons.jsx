/* ─── Temporadas por contabilidad (Fase 2 · D-012) ────────────────────────
 * Una empresa no reparte igual todo el año. La papelería vive de agosto, el
 * restaurante de diciembre. Hasta acá el reparto de cántaros era uno solo, y
 * la única forma de acompañar una temporada alta era mover los porcentajes a
 * mano cada vez y volver a moverlos después.
 *
 * Dos preguntas que el diseño tenía abiertas y que había que cerrar para que
 * esto tuviera sentido:
 *
 *   · ¿Qué pasa con un mes que no está en ninguna temporada?
 *     Existe un REPARTO BASE, que no se puede borrar y no reclama meses: es lo
 *     que rige en todo mes que ninguna temporada haya pedido. Así nadie tiene
 *     que cubrir los 12 meses para que la app funcione, y no hay meses
 *     huérfanos sin reparto definido.
 *
 *   · ¿Qué pasa si dos temporadas reclaman el mismo mes?
 *     No puede pasar. Asignar un mes a una temporada lo saca de la otra, y la
 *     UI lo dice. Con solapamiento, "qué reparto rige en diciembre" no tendría
 *     respuesta — y un presupuesto ambiguo es peor que uno rígido.
 *
 * El cambio de temporada NO es automático (D-012): la app propone y el usuario
 * confirma. Mover los porcentajes de alguien sin avisar es mover su
 * presupuesto sin permiso.
 *
 * Solo empresas. La contabilidad personal no tiene temporadas.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */

const OWF_SEASONS = window.__owSeasons || (window.__owSeasons = {});
/* Confirmaciones ya resueltas, para no volver a preguntar lo mismo. */
const OWF_SEASON_ACK = window.__owSeasonAck || (window.__owSeasonAck = {});

/* El reparto base arranca siendo el que la empresa ya tiene: la temporada no
 * se inventa un reparto nuevo, describe el que está en uso. */
function owfPlanFromJars(jars) {
  return (jars || []).map(j => [j.name, Number(j.percent) || 0]);
}

function owfSeasonsFor(ctxId) {
  if (!OWF_SEASONS[ctxId]) {
    const d = (window.owfDatasetFor && window.owfDatasetFor(ctxId)) || {};
    OWF_SEASONS[ctxId] = [{
      id: 'base', name: 'Reparto base', base: true, months: [],
      plan: owfPlanFromJars(d.SAMPLE_JARS),
    }];
  }
  return OWF_SEASONS[ctxId];
}

function owfSeasonById(ctxId, id) {
  return owfSeasonsFor(ctxId).find(s => s.id === id) || null;
}

/* Qué reparto rige en un mes: la temporada que lo reclamó, o el base. */
function owfSeasonForMonth(ctxId, month) {
  const list = owfSeasonsFor(ctxId);
  return list.find(s => !s.base && (s.months || []).indexOf(month) >= 0) || list[0];
}

function owfAddSeason(ctxId, name) {
  const list = owfSeasonsFor(ctxId);
  const base = list[0];
  const s = { id: 'sz' + Date.now(), name: name || 'Temporada nueva', months: [], plan: base.plan.map(p => [p[0], p[1]]) };
  list.push(s);
  return s;
}

function owfRemoveSeason(ctxId, id) {
  const list = owfSeasonsFor(ctxId);
  const i = list.findIndex(s => s.id === id && !s.base);
  if (i >= 0) list.splice(i, 1);
  return list;
}

/* Un mes pertenece a UNA temporada. Asignarlo lo quita de la anterior: el
 * llamador recibe de qué temporada salió, para poder decirlo en la UI en vez
 * de que el mes desaparezca de un lado sin explicación. */
function owfAssignMonth(ctxId, seasonId, month) {
  const list = owfSeasonsFor(ctxId);
  let takenFrom = null;
  list.forEach(s => {
    if (s.base) return;
    const at = (s.months || []).indexOf(month);
    if (at >= 0 && s.id !== seasonId) { s.months.splice(at, 1); takenFrom = s.name; }
  });
  const target = list.find(s => s.id === seasonId);
  if (target && !target.base) {
    const at = target.months.indexOf(month);
    if (at >= 0) target.months.splice(at, 1); else target.months.push(month);
  }
  return takenFrom;
}

function owfSetSeasonPlan(ctxId, seasonId, plan) {
  const s = owfSeasonById(ctxId, seasonId);
  if (s) s.plan = plan;
  return s;
}

/* Aplica el reparto de una temporada a los cántaros de la contabilidad.
 * Los montos ya acumulados se conservan: cambia cuánto se aparta de acá en
 * adelante, no lo que ya entró. Borrar el saldo al cambiar de temporada
 * sería perder plata real por un cambio de presupuesto. */
function owfApplySeason(ctxId, seasonId) {
  const s = owfSeasonById(ctxId, seasonId);
  if (!s) return null;
  const d = window.owfDatasetFor(ctxId);
  const prev = d.SAMPLE_JARS || [];
  const fresh = window.owfJarsFromPlan(s.plan);
  d.SAMPLE_JARS = fresh.map(j => {
    const old = prev.find(p => p.name === j.name);
    return old ? { ...j, id: old.id, amount: old.amount, progress: old.progress, goalText: old.goalText, statusText: old.statusText, tone: old.tone } : j;
  });
  OWF_SEASON_ACK[ctxId + ':' + seasonId] = true;
  if (window.__owCtx === ctxId) window.owfApplyContextData(ctxId);
  return d;
}

/* ¿Hay que proponer un cambio de temporada? Solo si el mes visible pertenece a
 * una temporada distinta de la que está aplicada, y no se resolvió ya. */
function owfSeasonPending(ctxId, month) {
  if (!ctxId || ctxId === 'personal') return null;
  const list = owfSeasonsFor(ctxId);
  if (list.length < 2) return null;
  const season = owfSeasonForMonth(ctxId, month);
  if (OWF_SEASON_ACK[ctxId + ':' + season.id]) return null;
  const current = owfPlanFromJars((window.owfDatasetFor(ctxId) || {}).SAMPLE_JARS);
  const same = season.plan.length === current.length &&
    season.plan.every((p, i) => current[i] && current[i][0] === p[0] && current[i][1] === p[1]);
  return same ? null : season;
}

function owfSeasonDismiss(ctxId, seasonId) { OWF_SEASON_ACK[ctxId + ':' + seasonId] = true; }

Object.assign(window, {
  OWF_SEASONS, owfSeasonsFor, owfSeasonById, owfSeasonForMonth, owfAddSeason, owfRemoveSeason,
  owfAssignMonth, owfSetSeasonPlan, owfApplySeason, owfSeasonPending, owfSeasonDismiss, owfPlanFromJars,
});
