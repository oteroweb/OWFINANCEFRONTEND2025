/* global React, AN_TOTAL, AN_BUDGET */
/* ─── Lite · Análisis route — "¿En qué se fue?" (enfocado) ──────────────── */

function AnalisisRoute({ hidden }) {
  const ACCENT = 'var(--brand-primary)';
  const card = { background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-card)', padding: 22, marginBottom: 18 };
  /* Las cifras salen del contexto activo, no del texto (Fase 2): en una empresa
   * este mismo párrafo dice sus propios números. */
  const n = window.AN_NARRATIVE || {};
  const jars = window.AN_JARS || [];
  const money = v => (window.AN_FMT ? AN_FMT(v || 0).replace('$', '') : String(v || 0));

  return (
    <div style={{ maxWidth: 780, margin: '0 auto' }}>
      <AnPeriodNav accent={ACCENT} simple={true} />

      <div style={{ fontFamily: 'var(--font-body)', fontSize: 11, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', color: ACCENT, marginBottom: 10 }}>{t('En qué se fue')}</div>

      {/* Hero hook */}
      <div style={{ background: 'var(--surface-1)', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-float)', padding: 28, marginBottom: 18 }}>
        <div style={{ fontSize: 15, color: 'var(--fg-2)' }}>{t('En')} <b style={{ color: 'var(--fg-1)' }}>{n.period}</b> {t('hiciste')} <b style={{ color: 'var(--fg-1)' }}>{n.txCount} {t('movimientos')}</b>. {t('Gastaste')}</div>
        <div style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 60, letterSpacing: '-.02em', lineHeight: 1.05, margin: '8px 0 14px', color: 'var(--expense-fg)' }}>
          <span style={{ color: 'var(--fg-3)', fontSize: 30 }}>$</span>{hidden ? '••••' : money(n.spent)}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          {/* La comparación con el mes anterior solo aparece si hay con qué
            * comparar: una contabilidad nueva no tiene mes anterior. */}
          {n.deltaPct != null && (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 13px', borderRadius: 999, fontSize: 13, fontWeight: 600, background: n.deltaPct < 0 ? 'var(--income-soft)' : 'var(--expense-soft)', color: n.deltaPct < 0 ? 'var(--income-fg)' : 'var(--expense-fg)' }}><span className="material-icons" style={{ fontSize: 17 }}>{n.deltaPct < 0 ? 'trending_down' : 'trending_up'}</span>{`${Math.abs(n.deltaPct)}% ${t(n.deltaPct < 0 ? 'menos que' : 'más que')} ${n.prevPeriod}`}</span>
          )}
          <span style={{ fontSize: 13, color: 'var(--fg-2)' }}>{t('Ingresos del mes')} · <b style={{ color: 'var(--income-fg)', fontFamily: 'var(--font-money)' }}>{n.incomeText}</b></span>
        </div>
      </div>

      <div style={{ marginBottom: 18 }}><AnUnassigned /></div>

      {/* Donut */}
      <div style={card}>
        <div className="t-h3">{t('¿En qué se fue?')}</div>
        <div style={{ color: 'var(--fg-2)', fontSize: 12.5, margin: '3px 0 18px' }}>{t('Tu gasto del mes, por cántaro.')}</div>
        <AnDonutLegend size={200} />
      </div>

      {/* Insight */}
      {n.topNames && n.topNames.length > 1 && (
        <div style={{ marginBottom: 18 }}>
          <AnInsight icon="bolt">{t('El')} <b>{`${n.topShare}%`}</b> {t('de tu gasto fue en')} <b>{n.topNames[0]}</b> {t('y')} <b>{n.topNames[1]}</b>. {t('Ahí está el foco si quieres mover la aguja.')}</AnInsight>
        </div>
      )}

      {/* Budget pulse */}
      <div style={card}>
        <div className="t-h3">{t('Tu presupuesto')}</div>
        <div style={{ color: 'var(--fg-2)', fontSize: 12.5, margin: '3px 0 18px' }}>{t('Cómo vas contra lo que asignaste este mes.')}</div>
        {n.budget ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 'var(--radius-md)', background: 'var(--surface-2)' }}>
            <div style={{ width: 44, height: 44, borderRadius: '50%', flex: '0 0 auto', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 12, color: ACCENT, background: `conic-gradient(${ACCENT} ${Math.min(n.budgetPct, 100) * 3.6}deg, var(--surface-3) 0)`, boxShadow: 'inset 0 0 0 4px var(--surface-2)' }}>{`${n.budgetPct}%`}</div>
            <div style={{ fontSize: 13.5 }}>{t('Vas al')} <b>{`${n.budgetPct}%`}</b> {t('de lo asignado')} (${money(n.spent)} {t('de')} ${money(n.budget)}).{n.overJar && <React.Fragment> <b style={{ color: 'var(--expense-fg)' }}>{n.overJar.name}</b> {t('ya se pasó del límite.')}</React.Fragment>}</div>
          </div>
        ) : <AnEmpty label="Todavía no hay presupuesto que comparar" />}
      </div>
    </div>
  );
}

Object.assign(window, { AnalisisRoute });
