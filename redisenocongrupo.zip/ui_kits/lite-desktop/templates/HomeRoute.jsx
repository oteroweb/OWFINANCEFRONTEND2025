/* global React */

function HomeRoute({ hidden, onQuickAdd, onGo, ctx }) {
  /* Los números salen del contexto activo (Fase 2). Estaban escritos a mano,
   * así que una empresa mostraba el disponible personal con su nombre arriba
   * y sus propios Cántaros correctos justo debajo. */
  const h = window.AN_HOME || {};
  const ctxId = (ctx && ctx.id) || 'personal';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      <HeroBalance
        amount={h.available || 0}
        currency="USD"
        hidden={hidden}
        onQuickAdd={onQuickAdd}
        asOf={h.asOf}
        delta={h.deltaAvailable == null ? null : { value: h.deltaAvailable, label: 'vs. mes ant.' }}
        note={h.rates && Object.keys(h.rates).length ? `convertido a ${Object.keys(h.rates).map(c => h.rates[c].toLocaleString('es-VE')).join(' · ')}` : null}
      />
      {/* Arriba de los cántaros: el reparto se entiende mejor sabiendo cuánto
        * aguanta lo que ya tienen dentro. */}
      <FinancialHealthCard ctxId={ctxId} tint={(ctx && ctx.color) || 'var(--brand-primary)'} hidden={hidden} onGo={onGo} />
      <JarsPreview jars={SAMPLE_JARS} hidden={hidden} onViewAll={() => onGo('jars')} />
      <DreamsPreview dreams={SAMPLE_DREAMS} hidden={hidden} onViewAll={() => onGo('dreams')} />
      <DebtsPreview debts={SAMPLE_DEBTS} hidden={hidden} onViewAll={() => onGo('debts')} />
      <RecentTransactions
        transactions={SAMPLE_TX.slice(0, 5)}
        hidden={hidden}
        onViewAll={() => onGo('transactions')}
      />
    </div>
  );
}

Object.assign(window, { HomeRoute });
