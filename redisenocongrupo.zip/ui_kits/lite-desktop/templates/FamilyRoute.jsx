/* ─── Template · FamilyRoute (`/user/config/family`) ──────────────────────
 * Casa de la Fase 1 dentro de Config. Antes los tres organismos existían
 * sueltos, sin ruta que los contuviera — este archivo es la respuesta al
 * pendiente "ubicación final de FamilyGroupPanel" (TASKS.md §10.1).
 *
 * Junta las tres piezas en el orden en que se usan: primero el grupo (sin
 * grupo no hay nada que compartir), después qué te compartieron a vos, y el
 * diálogo de compartir se abre desde una cuenta propia.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React, Eyebrow, PillButton, FamilyGroupPanel, SharedAccountsSection, AccountShareDialog, SAMPLE_FAMILY_GROUP, SAMPLE_ACCOUNT_SHARES */

function FamilyRoute({ onGo }) {
  const [ui, setUi] = React.useState({ group: SAMPLE_FAMILY_GROUP, share: null });
  const myAccounts = [
    { id: 1, name: 'Banesco', balance: 512.4, currencySymbol: '$', currencyCode: 'USD' },
    { id: 2, name: 'Efectivo', balance: 86, currencySymbol: '$', currencyCode: 'USD' },
    { id: 3, name: 'Zelle', balance: 1240.9, currencySymbol: '$', currencyCode: 'USD' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 720, margin: '0 auto', width: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <Eyebrow>Configuración · Grupo familiar</Eyebrow>
          <h1 className="t-h1" style={{ margin: '6px 0 0' }}>Compartir cuentas</h1>
        </div>
        {onGo && <PillButton variant="ghost" icon="arrow_back" onClick={() => onGo('config')}>Volver</PillButton>}
      </div>

      <FamilyGroupPanel group={ui.group}
        sharedInCount={SAMPLE_ACCOUNT_SHARES.length} sharedOutCount={2}
        onSave={p => p.action === 'create-group' && setUi(u => ({ ...u, group: { ...SAMPLE_FAMILY_GROUP, name: p.name, members: SAMPLE_FAMILY_GROUP.members.slice(0, 1) } }))}
        onDelete={() => setUi(u => ({ ...u, group: null }))}
        onSelectAction={a => console.log('[family]', a)} />

      {ui.group && (
        <SharedAccountsSection myAccounts={myAccounts} shares={SAMPLE_ACCOUNT_SHARES}
          onSelectAction={a => {
            const [kind, id] = a.split(':');
            if (kind === 'share') setUi(u => ({ ...u, share: myAccounts.find(x => x.id === Number(id)) }));
          }}
          onChange={(f, v) => console.log('[family]', f, v)} />
      )}

      {ui.share && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(4,7,13,.55)', backdropFilter: 'blur(3px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, zIndex: 900 }}
          onClick={e => e.target === e.currentTarget && setUi(u => ({ ...u, share: null }))}>
          <AccountShareDialog account={ui.share} group={ui.group} shares={[{ user_id: 2, permission: 'manage' }]}
            onChange={(f, v) => console.log('[family]', f, v)}
            onSave={p => { console.log('[family] save', p); setUi(u => ({ ...u, share: null })); }}
            onClose={() => setUi(u => ({ ...u, share: null }))}
            onSelectAction={a => console.log('[family]', a)} />
        </div>
      )}
    </div>
  );
}

Object.assign(window, { FamilyRoute });
