/* global React */
/* ProJarsRoute — ensambla JarsProConfigPage (organisms/JarsProConfig.jsx +
 * organisms/JarsProEditor.jsx). Antes de este archivo, ProShell.jsx enrutaba
 * 'jars' al mismo JarsRoute.jsx que usa LiteShell.jsx — violando
 * DESIGN_CONTRACT.md §5 (Lite y Pro deben ser archivos separados, nunca un
 * componente compartido con lógica de modo). JarsProConfigPage ya existía
 * completo (KPI bar, resumen del mes, tabla, configuración global, editor de
 * fila con drag&drop de categorías, modal de ajuste, registrar uso) pero
 * nunca estaba conectado a ningún shell ni cargado en index.html — quedaba
 * huérfano. Este archivo solo lo conecta, sin inventar UI nueva. */
function ProJarsRoute({ hidden, ctx }) {
  /* Temporadas son solo de empresas (D-012). */
  const isBiz = ctx && ctx.kind === 'business';
  /* La barra de distribución y el editor de temporadas conviven en esta
   * pantalla, y las temporadas viven en `window`. Sin este contador, crear una
   * temporada actualizaba el editor y dejaba la barra de arriba sin rótulo —
   * afirmando que describe todo el año justo cuando deja de ser cierto. */
  const [seasonVer, setSeasonVer] = React.useState(0);
  /* El mes del periodo en pantalla — la barra y el editor nombran la temporada
   * de ESE mes, no la del reloj. */
  const mo = window.useAppMonth().m;
  return (
    <React.Fragment>
      <JarsProConfigPage hidden={hidden} key={(ctx && ctx.id) || 'personal'} ctxId={ctx && ctx.id} seasonVer={seasonVer} month={mo} />
      {isBiz && (
        <div style={{ marginTop: 26 }}>
          <SeasonsEditor ctxId={ctx.id} tint={ctx.color} month={mo} onChange={() => setSeasonVer(v => v + 1)} />
        </div>
      )}
    </React.Fragment>
  );
}

Object.assign(window, { ProJarsRoute });
