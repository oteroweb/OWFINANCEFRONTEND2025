/* global React */
/* JarsRoute (Lite) — ensambla JarsLiteConfigPage (organisms/JarsLiteConfig.jsx),
 * implementando PROMPT_REDISENO_CANTAROS.md §2 completo: card resumen,
 * selector de periodo, lista con drag reorder + toggle activo inline,
 * modales de detalle/editar/nuevo. Reemplaza el placeholder mínimo (hero +
 * grid, sin acciones reales) que vivía acá antes.
 *
 * Antes de esto, tanto LiteShell.jsx como ProShell.jsx enrutaban 'jars' a
 * este mismo componente — violación de DESIGN_CONTRACT.md §5. Ya se
 * corrigió: Pro usa `ProJarsRoute` (organisms/JarsProConfig.jsx +
 * JarsProEditor.jsx), este archivo queda solo para Lite.
 *
 * `onQuickAdd` es opcional (LiteShell ya lo pasa a HomeRoute con el mismo
 * nombre) — si no se recibe, los botones Agregar/Retirar/Registrar ingreso
 * del detalle y del estado vacío simplemente no hacen nada. */
function JarsRoute({ hidden, onQuickAdd, ctx }) {
  /* Temporadas son solo de empresas (D-012): la contabilidad personal no las
   * tiene, así que el editor no se monta ahí. */
  const isBiz = ctx && ctx.kind === 'business';
  /* `key` por contexto: los cántaros viven en `window`, así que sin esto la
   * pantalla se queda con los de la contabilidad anterior. `seasonVer` remonta
   * la página cuando se crea o edita una temporada. */
  const [seasonVer, setSeasonVer] = React.useState(0);
  const mo = window.useAppMonth().m;
  return (
    <React.Fragment>
      <JarsLiteConfigPage hidden={hidden} onQuickAdd={onQuickAdd} key={`${(ctx && ctx.id) || 'personal'}:${seasonVer}`} />
      {isBiz && (
        <div style={{ marginTop: 26 }}>
          <SeasonsEditor ctxId={ctx.id} tint={ctx.color} month={mo} onChange={() => setSeasonVer(v => v + 1)} />
        </div>
      )}
    </React.Fragment>
  );
}

Object.assign(window, { JarsRoute });
