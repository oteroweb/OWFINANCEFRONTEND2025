/* global React */

/* ── Formateo de montos ────────────────────────────────────────────── */
const _fx2 = (n) => Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const _fxRate = (n) => Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 });

/* Monto en cuenta de moneda extranjera (no USD).
 * Muestra el importe nativo (ej. -702.10 VES) y, debajo, dos conversiones
 * a USD: BCV (tasa oficial del banco) y TASA (la tasa que el usuario fija
 * para su economía en cada movimiento). */
function FxAmount({ tx, cur, hidden, dense, isIncome }) {
  const color = isIncome ? 'var(--income-fg)' : 'var(--expense-fg)';
  const sign = tx.nativeAmount < 0 ? '-' : (tx.nativeAmount > 0 ? '+' : '');
  const nat = _fx2(tx.nativeAmount);
  const rBCV = tx.rateBCV, rTasa = tx.rateTasa;
  const usdBCV = rBCV ? tx.nativeAmount / rBCV : null;
  const usdTasa = rTasa ? tx.nativeAmount / rTasa : null;

  if (hidden) {
    return <span className="t-amount-sm" style={{ color, fontFamily: 'var(--font-money)', fontWeight: 600 }}>••••</span>;
  }

  const line = (tag, rate, usd) => (
    <span style={{ fontFamily: 'var(--font-money)', fontSize: 10.5, lineHeight: 1.4, color: 'var(--fg-3)', whiteSpace: 'nowrap', textAlign: 'right' }}>
      <b style={{ color: 'var(--fg-2)', fontWeight: 700, letterSpacing: '.01em' }}>{tag}</b>
      {' '}{sign}{cur} {nat} / {_fxRate(rate)} = <b style={{ color }}>{sign}${_fx2(usd)}</b>
    </span>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 2 }}>
      <span className="t-amount-sm" style={{ color, fontFamily: 'var(--font-money)', fontWeight: 600 }}>
        {sign}{nat}<span style={{ fontSize: '.7em', color: 'var(--fg-3)', fontWeight: 600, marginLeft: 4 }}>{cur}</span>
      </span>
      {dense ? (
        <React.Fragment>
          {rBCV != null && line('USD-BCV', rBCV, usdBCV)}
          {rTasa != null && line('USD-TASA', rTasa, usdTasa)}
        </React.Fragment>
      ) : (
        usdTasa != null && (
          <span style={{ fontFamily: 'var(--font-money)', fontSize: 11, color: 'var(--fg-3)' }}>≈ {sign}${_fx2(usdTasa)}</span>
        )
      )}
    </div>
  );
}

function TxRow({ tx, hidden, dense = false }) {
  const isIncome = tx.amount > 0;
  const _accts = (typeof SAMPLE_ACCOUNTS !== 'undefined' ? SAMPLE_ACCOUNTS : (window.SAMPLE_ACCOUNTS || []));
  const acct = _accts.find(a => a.id === tx.acctId);
  const cur = acct && acct.currency;
  const foreign = !!(cur && cur !== 'USD' && tx.nativeAmount != null);
  const open = () => { if (window.__owOpenTxDetailDesktop) window.__owOpenTxDetailDesktop(tx); };
  return (
    <div
      onClick={open}
      role="button"
      tabIndex={0}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } }}
      onMouseEnter={e => { e.currentTarget.style.background = 'var(--surface-2)'; }}
      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
      style={{
      display: 'grid',
      gridTemplateColumns: dense ? 'auto 1fr auto auto' : 'auto 1fr auto',
      gap: 14, alignItems: 'center', cursor: 'pointer',
      background: 'transparent', transition: 'background 140ms',
      padding: dense ? '10px 20px' : '14px 20px',
      borderTop: '1px solid var(--border-hairline)',
    }}>
      <div style={{
        width: dense ? 32 : 38, height: dense ? 32 : 38,
        borderRadius: 'var(--radius-pill)',
        background: isIncome ? 'var(--income-soft)' : 'var(--expense-soft)',
        color: isIncome ? 'var(--income-fg)' : 'var(--expense-fg)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <span className="material-icons" style={{ fontSize: dense ? 18 : 20 }}>
          {isIncome ? 'arrow_downward' : 'arrow_outward'}
        </span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <span style={{ fontFamily: 'var(--font-body)', fontWeight: 500, fontSize: 14, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t(tx.label)}</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--fg-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t(tx.meta)}</span>
          {/* "Operado por" (D-016): solo cuando NO lo registró el dueño de la
            * cuenta. La mayoría de los movimientos son propios, así que una
            * marca en todas las filas sería ruido — aparece justo cuando
            * cambia el sentido de la fila. Va en la línea de meta, no en una
            * columna nueva: la tabla ya tiene cuatro y en Lite hay tres. */}
          {tx.operated_by_name && (
            <span title={`Registrado por ${tx.operated_by_name}`}
              style={{ display: 'inline-flex', alignItems: 'center', gap: 5, flexShrink: 0, padding: '2px 8px 2px 3px', borderRadius: 'var(--radius-pill)', background: 'var(--surface-2)' }}>
              <span style={{ width: 15, height: 15, borderRadius: 999, background: 'var(--brand-primary-soft)', color: 'var(--brand-primary-fg-soft)', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 9 }}>{tx.operated_by_name.charAt(0)}</span>
              <span style={{ fontFamily: 'var(--font-body)', fontSize: 10.5, fontWeight: 600, color: 'var(--fg-2)', whiteSpace: 'nowrap' }}>{`operado por ${tx.operated_by_name.split(' ')[0]}`}</span>
            </span>
          )}
        </span>
      </div>
      {dense && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
          {tx.jar ? (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              fontFamily: 'var(--font-body)', fontSize: 11, fontWeight: 600,
              padding: '4px 10px 4px 8px', borderRadius: 'var(--radius-pill)',
              background: 'color-mix(in srgb, ' + tx.jarColor + ' 12%, var(--surface-1))',
              color: 'color-mix(in srgb, ' + tx.jarColor + ' 72%, var(--fg-1))',
            }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: tx.jarColor, flexShrink: 0 }}></span>
              {t(tx.jar)}
            </span>
          ) : (
            <span style={{
              fontFamily: 'var(--font-body)', fontSize: 11, fontWeight: 500,
              padding: '4px 10px', borderRadius: 'var(--radius-pill)',
              background: 'var(--income-soft)', color: 'var(--income-fg)',
            }}>{t('Sin cántaro')}</span>
          )}
          <span style={{
            fontFamily: 'var(--font-body)', fontSize: 11, fontWeight: 500,
            padding: '4px 10px', borderRadius: 'var(--radius-pill)',
            background: 'var(--surface-2)', color: 'var(--fg-2)',
          }}>{t(tx.category)}</span>
        </div>
      )}
      {foreign ? (
        <FxAmount tx={tx} cur={cur} hidden={hidden} dense={dense} isIncome={isIncome} />
      ) : (
        <Money
          value={tx.amount}
          className="t-amount-sm"
          sign
          hidden={hidden}
          color={isIncome ? 'var(--income-fg)' : 'var(--expense-fg)'}
        />
      )}
    </div>
  );
}

function RecentTransactions({ transactions, hidden, onViewAll, title = 'Recent transactions' }) {
  return (
    <div>
      <SectionHeader
        title={title}
        action={onViewAll && <PillButton variant="ghost" size="sm" onClick={onViewAll}>{t('Ver todas')}</PillButton>}
      />
      <Card padding={0}>
        <div style={{ padding: '6px 0' }}>
          {transactions.length === 0 ? (
            <div style={{ padding: '32px 20px', textAlign: 'center' }}>
              <div className="t-body" style={{ color: 'var(--fg-2)' }}>{t('Sin transacciones todavía.')}</div>
            </div>
          ) : (
            transactions.map((tx, i) => (
              <div key={i} style={{ borderTop: i === 0 ? 'none' : undefined }}>
                <TxRow tx={tx} hidden={hidden} />
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}

function TransactionsLedger({ transactions, hidden }) {
  // dense variant with category column, grouped by day header
  const grouped = transactions.reduce((acc, tx) => {
    (acc[tx.day] = acc[tx.day] || []).push(tx);
    return acc;
  }, {});
  const days = Object.keys(grouped);
  return (
    <Card padding={0}>
      {days.map((d, i) => (
        <div key={d}>
          <div style={{
            padding: '14px 20px 8px',
            borderTop: i === 0 ? 'none' : '1px solid var(--border-hairline)',
          }}>
            <Eyebrow>{t(d)}</Eyebrow>
          </div>
          {grouped[d].map((tx, j) => <TxRow key={j} tx={tx} hidden={hidden} dense />)}
        </div>
      ))}
    </Card>
  );
}

Object.assign(window, { RecentTransactions, TransactionsLedger, TxRow, FxAmount });
