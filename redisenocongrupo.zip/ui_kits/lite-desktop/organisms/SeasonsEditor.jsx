/* ─── Organism · SeasonsEditor (Fase 2 · D-012) ───────────────────────────
 * El editor de temporadas de una empresa. Ver `data/context-seasons.jsx` para
 * el modelo y las dos reglas que lo sostienen (reparto base, un mes = una
 * temporada).
 *
 * Decisiones de presentación:
 *   · Los meses son una cuadrícula de 12, no un rango con fechas. Una
 *     temporada de negocio son meses sueltos ("agosto y septiembre", "enero"),
 *     no un intervalo continuo, y un date picker obligaría a inventar días.
 *   · El reparto base va primero, sin meses y sin botón de borrar. No es una
 *     temporada más: es lo que rige cuando ninguna aplica.
 *   · El total se vigila igual que en la barra de distribución: no se puede
 *     guardar un reparto que no suma 100%, porque el resto del dinero no
 *     tendría dónde ir.
 *   · Robar un mes a otra temporada se dice en el momento, con el nombre de la
 *     que lo perdió. Que un mes desaparezca de otra tarjeta sin aviso es la
 *     clase de cosa que se descubre tres meses después.
 *
 * Props: ctxId(string) · tint(color) · onChange()
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */
const { useState: useSzState } = React;

const SZ_MONTHS_SHORT = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
/* Nombrado completo para la línea "<mes> rige X": con el periodo en pantalla
 * pudiendo ser cualquier mes, "este mes" era ambiguo. */
const SZ_MONTHS_LONG = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

function SzStepper({ value, tint, onChange }) {
  const btn = (icon, delta) => (
    <button type="button" onClick={() => onChange(Math.max(0, Math.min(100, value + delta)))}
      style={{ width: 26, height: 26, borderRadius: 8, border: 0, cursor: 'pointer', background: 'var(--surface-2)', color: 'var(--fg-1)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
      <span className="material-icons" style={{ fontSize: 15 }}>{icon}</span>
    </button>
  );
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexShrink: 0 }}>
      {btn('remove', -5)}
      <span style={{ minWidth: 44, textAlign: 'center', fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 14, color: tint }}>{`${value}%`}</span>
      {btn('add', 5)}
    </div>
  );
}

function SeasonCard({ ctxId, season, tint, onChange }) {
  const [note, setNote] = useSzState(null);
  const plan = season.plan || [];
  const total = plan.reduce((s, p) => s + (Number(p[1]) || 0), 0);
  const off = total !== 100;

  const setPct = (i, v) => {
    const next = plan.map((p, n) => (n === i ? [p[0], v] : [p[0], p[1]]));
    window.owfSetSeasonPlan(ctxId, season.id, next);
    onChange && onChange();
  };

  const toggleMonth = (m) => {
    const takenFrom = window.owfAssignMonth(ctxId, season.id, m);
    setNote(takenFrom ? `${SZ_MONTHS_SHORT[m]} salió de "${takenFrom}": un mes pertenece a una sola temporada.` : null);
    onChange && onChange();
  };

  return (
    <div style={{ background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', border: `1px solid ${season.base ? 'var(--border-hairline)' : tint}`, boxShadow: 'var(--shadow-card)', padding: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ width: 30, height: 30, borderRadius: 9, flexShrink: 0, display: 'grid', placeItems: 'center', background: season.base ? 'var(--surface-2)' : tint, color: season.base ? 'var(--fg-2)' : '#fff' }}>
          <span className="material-icons" style={{ fontSize: 17 }}>{season.base ? 'balance' : 'event_repeat'}</span>
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          {season.base ? (
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: 'var(--fg-1)' }}>{season.name}</div>
          ) : (
            <input value={season.name} onChange={e => { season.name = e.target.value; onChange && onChange(); }}
              placeholder="Ej: temporada escolar"
              style={{ width: '100%', border: 0, borderBottom: '1px solid var(--border-hairline)', background: 'transparent', color: 'var(--fg-1)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, padding: '2px 0', outline: 'none' }} />
          )}
          <div style={{ fontFamily: 'var(--font-body)', fontSize: 11.5, color: 'var(--fg-2)', marginTop: 2 }}>
            {season.base ? 'Rige en todo mes que no reclame ninguna temporada' : `${(season.months || []).length} ${(season.months || []).length === 1 ? 'mes' : 'meses'}`}
          </div>
        </div>
        {!season.base && (
          <button type="button" onClick={() => { window.owfRemoveSeason(ctxId, season.id); onChange && onChange(); }}
            style={{ border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--fg-3)', display: 'flex', flexShrink: 0 }}>
            <span className="material-icons" style={{ fontSize: 19 }}>delete_outline</span>
          </button>
        )}
      </div>

      {/* El base no reclama meses: por eso no muestra la cuadrícula. */}
      {!season.base && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 6 }}>
            {SZ_MONTHS_SHORT.map((m, i) => {
              const on = (season.months || []).indexOf(i) >= 0;
              const other = !on && window.owfSeasonForMonth(ctxId, i);
              const taken = other && !other.base;
              return (
                <button key={m} type="button" onClick={() => toggleMonth(i)}
                  title={taken ? `Hoy es de "${other.name}"` : ''}
                  style={{ padding: '8px 0', borderRadius: 9, cursor: 'pointer', border: `1px solid ${on ? tint : 'var(--border-hairline)'}`, background: on ? tint : 'transparent', color: on ? '#fff' : taken ? 'var(--fg-3)' : 'var(--fg-1)', fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 600 }}>
                  {m}
                </button>
              );
            })}
          </div>
          {note && (
            <div style={{ display: 'flex', gap: 8, padding: '9px 11px', borderRadius: 10, background: 'var(--warning-soft)' }}>
              <span className="material-icons" style={{ fontSize: 16, color: 'var(--warning-fg)', flexShrink: 0 }}>swap_horiz</span>
              <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, lineHeight: 1.45, color: 'var(--warning-fg)', textWrap: 'pretty' }}>{note}</span>
            </div>
          )}
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {plan.map((p, i) => (
          <div key={p[0] + i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '7px 0' }}>
            <span style={{ flex: 1, minWidth: 0, fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p[0]}</span>
            <span style={{ width: 90, height: 5, borderRadius: 3, background: 'var(--surface-2)', overflow: 'hidden', flexShrink: 0 }}>
              <i style={{ display: 'block', height: '100%', width: `${Math.min(p[1], 100)}%`, background: tint }} />
            </span>
            <SzStepper value={Number(p[1]) || 0} tint={tint} onChange={v => setPct(i, v)} />
          </div>
        ))}
      </div>

      {/* Igual que la barra de distribución: si no suma 100%, el resto del
        * dinero no tiene dónde ir, así que no se puede dar por bueno. */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '10px 13px', borderRadius: 10, background: off ? 'var(--warning-soft)' : 'var(--income-soft)' }}>
        <span className="material-icons" style={{ fontSize: 17, color: off ? 'var(--warning-fg)' : 'var(--income-fg)' }}>{off ? 'error_outline' : 'check_circle'}</span>
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 12.5, fontWeight: 600, color: off ? 'var(--warning-fg)' : 'var(--income-fg)' }}>
          {off ? (total > 100 ? `Suma ${total}% — sobran ${total - 100}%` : `Suma ${total}% — faltan ${100 - total}% por repartir`) : 'Reparte el 100%'}
        </span>
      </div>
    </div>
  );
}

function SeasonsEditor({ ctxId, tint = 'var(--brand-primary)', month, onChange }) {
  const [ver, setVer] = useSzState(0);
  const bump = () => { setVer(v => v + 1); onChange && onChange(); };
  const seasons = window.owfSeasonsFor(ctxId);
  /* El mes del periodo en pantalla, no el del reloj: dentro de la vista de
   * Mayo, "este mes rige" tiene que hablar de mayo. */
  const mo = month != null ? month
    : (window.MonthStore ? window.MonthStore.get().m : new Date().getMonth());
  const active = window.owfSeasonForMonth(ctxId, mo);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: 240 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17, color: 'var(--fg-1)' }}>Temporadas</div>
          <p style={{ margin: '3px 0 0', fontFamily: 'var(--font-body)', fontSize: 12.5, lineHeight: 1.5, color: 'var(--fg-2)', textWrap: 'pretty' }}>
            Un negocio no reparte igual todo el año. Dale a cada temporada sus meses y su propio reparto; al entrar un mes nuevo la app te lo propone y vos confirmás.
          </p>
        </div>
        <button type="button" onClick={() => { window.owfAddSeason(ctxId); bump(); }}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 7, border: 0, cursor: 'pointer', padding: '10px 17px', borderRadius: 'var(--radius-pill)', background: tint, color: '#fff', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 13, flexShrink: 0 }}>
          <span className="material-icons" style={{ fontSize: 17 }}>add</span>Nueva temporada
        </button>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '11px 14px', borderRadius: 10, background: 'var(--surface-2)' }}>
        <span className="material-icons" style={{ fontSize: 17, color: 'var(--fg-2)' }}>event_available</span>
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 12.5, color: 'var(--fg-2)' }}>
          {SZ_MONTHS_LONG[mo]} rige <b style={{ color: 'var(--fg-1)' }}>{active.name}</b>
        </span>
      </div>

      {seasons.map(s => <SeasonCard key={s.id + ':' + ver} ctxId={ctxId} season={s} tint={tint} onChange={bump} />)}
    </div>
  );
}

Object.assign(window, { SeasonsEditor, SeasonCard, SZ_MONTHS_SHORT, SZ_MONTHS_LONG });
