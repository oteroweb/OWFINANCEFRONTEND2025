/* ─── Organism · FinancialHealthCard ──────────────────────────────────────
 * "Cuánto aguanto sin ingresar nada", en Inicio y arriba de los cántaros.
 * La matemática vive en `data/financial-health.jsx`; acá solo la lectura.
 *
 * Decisiones de presentación (Jose, 2026-08-28):
 *   · El número grande en MESES, los días exactos en chico debajo. 412 días
 *     no se siente como nada; 13 meses sí.
 *   · Cuando es bajo va en rojo **con el paso siguiente**. El rojo también es
 *     el color del gasto en el resto de la app, así que acá no va suelto:
 *     siempre acompañado de la palanca, para que sea información y no un susto.
 *   · La palanca nombra la CATEGORÍA, no el cántaro. Nadie puede cancelar
 *     "Necesidades"; "Vivienda" sí es algo sobre lo que se puede actuar.
 *   · El patrimonio resta las deudas completas y muestra aparte lo que vence
 *     este mes — dos hechos distintos, no un promedio de los dos.
 *   · Los montos convertidos dicen con qué tasa ("a 40,50"): dato al lado del
 *     número, sin alarma ni fecha, por decisión explícita.
 *
 * Props: ctxId · tint · hidden · onGo(route)
 * ──────────────────────────────────────────────────────────────────────── */
/* global React, Money */

function FinancialHealthCard({ ctxId, tint = 'var(--brand-primary)', hidden = false, onGo }) {
  const h = window.owfFinancialHealth ? window.owfFinancialHealth(ctxId || 'personal') : null;
  if (!h) return null;

  const t = window.t || (s => s);
  const money = v => (hidden ? '$ ••••' : '$ ' + Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  const rateNote = Object.keys(h.rates || {}).map(c => `a ${h.rates[c].toLocaleString('es-VE')}`).join(' · ');
  const eyebrow = { fontFamily: 'var(--font-display)', fontSize: 10.5, fontWeight: 700, letterSpacing: '0.09em', textTransform: 'uppercase', color: 'var(--fg-3)' };
  const small = { fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--fg-2)' };

  /* Estado vacío: dice qué falta y lleva a donde se llena. El botón apunta a
   * lo que de verdad desbloquea el cálculo, no a una pantalla de "gastos
   * fijos" que no existe. */
  if (h.days == null) {
    const toJars = h.missing === 'jars';
    return (
      <div style={{ background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-card)', padding: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={eyebrow}>{t(h.label)}</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
          <span style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 40, color: 'var(--fg-3)', lineHeight: 1 }}>—</span>
          <span style={{ ...small, fontSize: 13 }}>{toJars ? 'todavía no repartiste tus cántaros' : 'todavía no hay movimientos que promediar'}</span>
        </div>
        <p style={{ ...small, fontSize: 12.5, lineHeight: 1.55, margin: 0, textWrap: 'pretty' }}>
          {toJars
            ? 'Para saber cuánto aguantás hace falta saber en qué se va tu plata cada mes. Eso lo define el reparto de tus cántaros.'
            : 'Con el reparto ya hecho, falta que entre y salga plata para tener un promedio real.'}
        </p>
        <button type="button" onClick={() => onGo && onGo(toJars ? 'jars' : 'transactions')}
          style={{ alignSelf: 'flex-start', border: 0, cursor: 'pointer', padding: '11px 20px', borderRadius: 'var(--radius-pill)', background: tint, color: '#fff', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 13.5 }}>
          {toJars ? 'Repartir mis cántaros' : 'Registrar un movimiento'}
        </button>
      </div>
    );
  }

  const tone = h.low ? 'var(--expense-fg)' : 'var(--fg-1)';
  const unit = h.months === 1 ? 'mes' : 'meses';

  return (
    <div style={{ background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-card)', padding: 24, display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: 210 }}>
          <div style={eyebrow}>{t(h.label)}</div>
          {/* Meses grande, días exactos debajo: la unidad natural arriba y la
            * precisión disponible sin pedirla. */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 9, marginTop: 6, whiteSpace: 'nowrap' }}>
            <span style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 'clamp(32px, 4vw, 44px)', color: tone, lineHeight: 1, letterSpacing: '-1px' }}>
              {hidden ? '••' : h.months}
            </span>
            <span style={{ fontFamily: 'var(--font-body)', fontSize: 17, fontWeight: 600, color: tone }}>{unit}</span>
          </div>
          <div style={{ ...small, marginTop: 5 }}>
            {hidden ? '•••' : `${h.days.toLocaleString('es-VE')} días`} · {h.isBiz ? 'operando sin facturar' : 'sin ingresar nada'}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, minWidth: 190 }}>
          <div>
            <div style={{ ...small, fontSize: 11, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>Patrimonio neto</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 7, flexWrap: 'wrap' }}>
              <span style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 20, color: h.netWorth < 0 ? 'var(--expense-fg)' : 'var(--fg-1)' }}>
                {(h.netWorth < 0 ? '− ' : '') + money(h.netWorth)}
              </span>
              {/* Con qué tasa se convirtió. Dato, no advertencia. */}
              {rateNote && <span style={{ ...small, fontSize: 11, color: 'var(--fg-3)' }}>{rateNote}</span>}
            </div>
            <div style={{ ...small, fontSize: 11.5, marginTop: 2 }}>{money(h.liquid)} en cuentas − {money(h.debtTotal)} de deuda</div>
          </div>
          {h.dueThisMonth > 0 && (
            <div>
              <div style={{ ...small, fontSize: 11, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>Vence este mes</div>
              <span style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 16, color: 'var(--fg-1)' }}>{money(h.dueThisMonth)}</span>
            </div>
          )}
        </div>
      </div>

      {/* La palanca. En rojo el bloque solo cuando el número es bajo: el color
        * acompaña una salida concreta, nunca va solo. */}
      {h.lever && (
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 11, padding: '13px 15px', borderRadius: 14, background: h.low ? 'var(--expense-soft)' : 'var(--surface-2)' }}>
          <span className="material-icons" style={{ fontSize: 18, flexShrink: 0, color: h.low ? 'var(--expense-fg)' : tint }}>
            {h.low ? 'trending_down' : 'lightbulb'}
          </span>
          <p style={{ margin: 0, fontFamily: 'var(--font-body)', fontSize: 12.5, lineHeight: 1.55, color: h.low ? 'var(--expense-fg)' : 'var(--fg-2)', textWrap: 'pretty' }}>
            {/* La ganancia, no la tajada: recortar un gasto que se repite cada
              * mes no libera su monto una vez, baja el gasto de todos los meses. */}
            <b>{h.lever.category}</b> se lleva {money(h.lever.amount)} al mes
            {h.lever.gainDays == null
              ? <span> — es todo tu gasto del mes</span>
              : <span> — sin eso aguantarías {h.lever.gainDays.toLocaleString('es-VE')} días más</span>}.
            {h.low && <span> Es lo que más mueve este número.</span>}
          </p>
        </div>
      )}

      <div style={{ ...small, fontSize: 11.5, color: 'var(--fg-3)', textWrap: 'pretty' }}>
        {/* La cláusula de la cuota es condicional: afirmarla con la deuda en
          * $0 era decir que se incluyó algo que no existía. */}
        Cuenta tus cántaros de gasto ({money(h.burnMonthly)} al mes{h.dueThisMonth > 0 ? ', cuota de deuda incluida' : ''}). Lo que apartás para metas no cuenta como gasto.
      </div>
    </div>
  );
}

Object.assign(window, { FinancialHealthCard });
