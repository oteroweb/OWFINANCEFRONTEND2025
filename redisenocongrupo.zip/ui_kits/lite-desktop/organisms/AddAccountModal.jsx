/* ─── AddAccountModal — alta de cuenta (con tipos de interés y deuda) ────
 * Paso 1: elige el tipo (Cuentas vs Deudas y financiamiento).
 * Paso 2: formulario condicional según tipo:
 *   · savings_interest → tasa de interés anual (APR) + capitalización.
 *   · loan / debt      → monto, APR, plazo (meses) → cuota mensual calculada.
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */
const { useState: useAAState } = React;

const AA_PALETTE = ['#1E3A8A', '#2D4DA6', '#0EA5E9', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#F97316'];

function AAField({ label, children }) {
  return (
    <div>
      <div style={{ fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 600, color: 'var(--fg-2)', marginBottom: 7 }}>{label}</div>
      {children}
    </div>
  );
}

function AddAccountModal({ open, initialSection = 'accounts', onClose, onCreateAccount, onCreateDebt }) {
  const [step, setStep] = useAAState('type');
  const [type, setType] = useAAState(null);
  const [name, setName] = useAAState('');
  const [currency, setCurrency] = useAAState('USD');
  const [color, setColor] = useAAState(AA_PALETTE[0]);
  const [balance, setBalance] = useAAState('');
  const [apr, setApr] = useAAState('');
  const [compounding, setCompounding] = useAAState('monthly');
  const [termMonths, setTermMonths] = useAAState('12');
  const [dueDay, setDueDay] = useAAState('5');

  if (!open) return null;

  const reset = () => { setStep('type'); setType(null); setName(''); setCurrency('USD'); setColor(AA_PALETTE[0]); setBalance(''); setApr(''); setCompounding('monthly'); setTermMonths('12'); setDueDay('5'); };
  const close = () => { reset(); onClose && onClose(); };

  const pickType = (id) => { setType(id); setStep('form'); };
  const meta = type ? ACCOUNT_TYPES[type] : null;
  const isDebt = meta && meta.debt;
  const isInterest = meta && meta.interestBearing;

  const submit = () => {
    if (!name.trim() || !type) return;
    const flag = (window.CURRENCIES && window.CURRENCIES[currency] && window.CURRENCIES[currency].flag) || '🇺🇸';
    if (isDebt) {
      const principal = Math.abs(parseFloat(balance) || 0);
      const aprNum = parseFloat(apr) || 0;
      const months = parseInt(termMonths, 10) || 1;
      const payment = computeLoanPayment(principal, aprNum, months);
      onCreateDebt && onCreateDebt({
        id: 'd' + Date.now(), name: name.trim(), type: type === 'loan' ? 'loan' : 'debt', icon: meta.icon,
        balance: principal, currency, apr: aprNum, cuota: months ? `0/${months}` : undefined,
        next: payment, dueDate: `día ${dueDay}`, status: 'active',
      });
    } else {
      onCreateAccount && onCreateAccount({
        id: 'a' + Date.now(), name: name.trim(), short: name.trim().slice(0, 3).toUpperCase(), sub: t(meta.label) + (isInterest && apr ? ` · ${apr}% APR` : ''),
        currency, balance: parseFloat(balance) || 0, color, flag, type, apr: isInterest ? (parseFloat(apr) || 0) : undefined, compounding: isInterest ? compounding : undefined,
      });
    }
    close();
  };

  const grid = (ids) => (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 9 }}>
      {ids.map(id => {
        const m = ACCOUNT_TYPES[id];
        return (
          <button key={id} type="button" onClick={() => pickType(id)}
            style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '13px 12px', border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-md)', background: 'var(--surface-2)', cursor: 'pointer', textAlign: 'left' }}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--brand-primary)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-hairline)'}>
            <span style={{ width: 32, height: 32, borderRadius: 9, background: m.debt ? 'var(--expense-soft)' : 'var(--brand-primary-soft)', color: m.debt ? 'var(--expense-fg)' : 'var(--brand-primary)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              <span className="material-icons" style={{ fontSize: 17 }}>{m.icon}</span>
            </span>
            <span style={{ fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, color: 'var(--fg-1)' }}>{t(m.label)}</span>
          </button>
        );
      })}
    </div>
  );

  const payment = isDebt ? computeLoanPayment(balance, apr, termMonths) : 0;

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 14000, background: 'rgba(15,23,42,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }} onClick={close}>
      <div onClick={e => e.stopPropagation()} style={{ width: 'min(460px, 100%)', maxHeight: '86vh', overflowY: 'auto', background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-float)', padding: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {step === 'form' && (
            <button type="button" onClick={() => setStep('type')} style={{ border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--fg-2)', display: 'flex' }}>
              <span className="material-icons" style={{ fontSize: 20 }}>arrow_back</span>
            </button>
          )}
          <h3 style={{ flex: 1, margin: 0, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--fg-1)' }}>
            {step === 'type' ? t('Agregar cuenta') : (isDebt ? t('Registrar deuda') : t('Nueva cuenta'))}
          </h3>
          <button type="button" onClick={close} style={{ border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--fg-3)', display: 'flex' }}>
            <span className="material-icons" style={{ fontSize: 20 }}>close</span>
          </button>
        </div>

        {step === 'type' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: 11.5, fontWeight: 700, letterSpacing: '.04em', color: 'var(--fg-3)', marginBottom: 9, textTransform: 'uppercase' }}>{t('Cuentas')}</div>
              {grid(['bank', 'card', 'cash', 'cashea', 'savings_interest'])}
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: 11.5, fontWeight: 700, letterSpacing: '.04em', color: 'var(--fg-3)', marginBottom: 9, textTransform: 'uppercase' }}>{t('Deudas y financiamiento')}</div>
              {grid(['loan', 'debt'])}
            </div>
          </div>
        )}

        {step === 'form' && meta && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <AAField label={t('Nombre')}>
              <input value={name} onChange={e => setName(e.target.value)} placeholder={isDebt ? t('Ej: Préstamo del carro') : t('Ej: Cuenta de ahorros')} style={{ ...window.FC_INPUT_STYLE, width: '100%', boxSizing: 'border-box', padding: '10px 12px' }} onFocus={window.fcFocus} onBlur={window.fcBlur} />
            </AAField>

            <div style={{ display: 'flex', gap: 10 }}>
              <div style={{ flex: 1 }}>
                <AAField label={t('Moneda')}>
                  <select value={currency} onChange={e => setCurrency(e.target.value)} style={{ ...window.FC_INPUT_STYLE, width: '100%', boxSizing: 'border-box', padding: '10px 12px' }}>
                    {Object.keys(window.CURRENCIES || { USD: 1 }).map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </AAField>
              </div>
              {!isDebt && (
                <div style={{ flexShrink: 0 }}>
                  <AAField label={t('Color')}>
                    <div style={{ display: 'flex', gap: 6, paddingTop: 4 }}>
                      {AA_PALETTE.map(c => (
                        <button key={c} type="button" onClick={() => setColor(c)} aria-label={c}
                          style={{ width: 24, height: 24, borderRadius: 7, background: c, border: color === c ? '2px solid var(--fg-1)' : '2px solid transparent', cursor: 'pointer' }} />
                      ))}
                    </div>
                  </AAField>
                </div>
              )}
            </div>

            <AAField label={isDebt ? t('Monto adeudado') : t('Saldo inicial')}>
              <input type="number" value={balance} onChange={e => setBalance(e.target.value)} placeholder="0.00" style={{ ...window.FC_INPUT_STYLE, width: '100%', boxSizing: 'border-box', padding: '10px 12px', fontFamily: 'var(--font-money)' }} onFocus={window.fcFocus} onBlur={window.fcBlur} />
            </AAField>

            {isInterest && (
              <div style={{ display: 'flex', gap: 10 }}>
                <div style={{ flex: 1 }}>
                  <AAField label={t('Tasa de interés anual (APR)')}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, ...window.FC_INPUT_STYLE, padding: '10px 12px' }}>
                      <input type="number" value={apr} onChange={e => setApr(e.target.value)} placeholder="4.5" style={{ flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent', fontFamily: 'var(--font-money)', color: 'var(--fg-1)' }} />
                      <span style={{ fontFamily: 'var(--font-money)', fontSize: 13, color: 'var(--fg-3)' }}>%</span>
                    </div>
                  </AAField>
                </div>
                <div style={{ flex: 1 }}>
                  <AAField label={t('Capitalización')}>
                    <select value={compounding} onChange={e => setCompounding(e.target.value)} style={{ ...window.FC_INPUT_STYLE, width: '100%', boxSizing: 'border-box', padding: '10px 12px' }}>
                      <option value="monthly">{t('Mensual')}</option>
                      <option value="annual">{t('Anual')}</option>
                    </select>
                  </AAField>
                </div>
              </div>
            )}

            {isDebt && (
              <React.Fragment>
                <div style={{ display: 'flex', gap: 10 }}>
                  <div style={{ flex: 1 }}>
                    <AAField label={t('Tasa de interés anual (APR)')}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, ...window.FC_INPUT_STYLE, padding: '10px 12px' }}>
                        <input type="number" value={apr} onChange={e => setApr(e.target.value)} placeholder="12.5" style={{ flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent', fontFamily: 'var(--font-money)', color: 'var(--fg-1)' }} />
                        <span style={{ fontFamily: 'var(--font-money)', fontSize: 13, color: 'var(--fg-3)' }}>%</span>
                      </div>
                    </AAField>
                  </div>
                  <div style={{ flex: 1 }}>
                    <AAField label={t('Plazo (meses)')}>
                      <input type="number" value={termMonths} onChange={e => setTermMonths(e.target.value)} style={{ ...window.FC_INPUT_STYLE, width: '100%', boxSizing: 'border-box', padding: '10px 12px', fontFamily: 'var(--font-money)' }} />
                    </AAField>
                  </div>
                </div>
                <AAField label={t('Día de pago mensual')}>
                  <input type="number" min="1" max="28" value={dueDay} onChange={e => setDueDay(e.target.value)} style={{ ...window.FC_INPUT_STYLE, width: 100, boxSizing: 'border-box', padding: '10px 12px', fontFamily: 'var(--font-money)' }} />
                </AAField>
                {balance && termMonths && (
                  <div style={{ padding: '10px 13px', borderRadius: 'var(--radius-sm)', background: 'var(--surface-2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontFamily: 'var(--font-body)', fontSize: 12.5, color: 'var(--fg-2)' }}>{t('Cuota mensual estimada')}</span>
                    <span style={{ fontFamily: 'var(--font-money)', fontSize: 15, fontWeight: 700, color: 'var(--fg-1)' }}>{currency} {payment.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                )}
              </React.Fragment>
            )}

            <button type="button" onClick={submit} disabled={!name.trim()}
              style={{ marginTop: 4, border: 0, cursor: name.trim() ? 'pointer' : 'default', opacity: name.trim() ? 1 : 0.5, padding: '13px 20px', borderRadius: 'var(--radius-pill)', background: isDebt ? 'var(--expense)' : 'var(--brand-primary)', color: '#fff', fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: 14 }}>
              {isDebt ? t('Registrar deuda') : t('Crear cuenta')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { AddAccountModal });
