/* ─── Organism · SeasonPrompt (Fase 2 · D-012) ────────────────────────────
 * Lo que aparece al entrar un mes que pertenece a otra temporada.
 *
 * Por qué es una propuesta y no un cambio silencioso: mover los porcentajes de
 * alguien sin avisar es mover su presupuesto sin permiso. La app sabe qué mes
 * es y qué temporada rige; lo que no sabe es si este año la temporada arranca
 * igual que el anterior.
 *
 * Muestra el cambio como comparación —de cuánto a cuánto, por cántaro— y no
 * solo el reparto nuevo: sin el número anterior al lado, "Nómina 40%" no dice
 * si subió o bajó.
 *
 * Las dos salidas son reales: aplicar, o seguir con el reparto actual. La
 * segunda no vuelve a preguntar por esa temporada — preguntar cada vez que
 * abrís la app convierte un aviso en una molestia.
 *
 * Props: ctxId · season · tint · onApply · onDismiss
 * ──────────────────────────────────────────────────────────────────────── */
/* global React */

function SeasonPrompt({ ctxId, season, tint = 'var(--brand-primary)', onApply, onDismiss }) {
  if (!season) return null;
  const current = window.owfPlanFromJars((window.owfDatasetFor(ctxId) || {}).SAMPLE_JARS);
  const rows = (season.plan || []).map(([name, pct]) => {
    const before = (current.find(c => c[0] === name) || [null, null])[1];
    return { name, pct, before, delta: before == null ? null : pct - before };
  });
  const changed = rows.filter(r => r.delta !== 0);

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 'var(--z-modal, 100)', background: 'rgba(15,23,42,.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: 'min(440px, 100%)', maxHeight: '86vh', display: 'flex', flexDirection: 'column', background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-float)', overflow: 'hidden' }}>
        <div style={{ background: tint, padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
          <span style={{ width: 32, height: 32, borderRadius: 10, flexShrink: 0, background: 'rgba(255,255,255,.22)', color: '#fff', display: 'grid', placeItems: 'center' }}>
            <span className="material-icons" style={{ fontSize: 18 }}>event_repeat</span>
          </span>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15.5, color: '#fff' }}>Empieza {season.name}</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 11.5, color: 'rgba(255,255,255,.8)', marginTop: 1 }}>Su reparto es distinto al que tenés ahora</div>
          </div>
        </div>

        <div style={{ padding: 20, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <p style={{ margin: 0, fontFamily: 'var(--font-body)', fontSize: 13, lineHeight: 1.55, color: 'var(--fg-2)', textWrap: 'pretty' }}>
            {changed.length
              ? `Este mes rige ${season.name}. Si lo aplicás, cambia cuánto se aparta de acá en adelante — lo que ya se acumuló en cada cántaro queda igual.`
              : `Este mes rige ${season.name}, con el mismo reparto que ya tenés.`}
          </p>

          {/* De cuánto a cuánto. Solo el número nuevo no diría si sube o baja. */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {rows.map(r => (
              <div key={r.name} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 11px', borderRadius: 9, background: r.delta ? 'var(--surface-2)' : 'transparent' }}>
                <span style={{ flex: 1, minWidth: 0, fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--fg-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</span>
                {r.before != null && <span style={{ fontFamily: 'var(--font-money)', fontSize: 12.5, color: 'var(--fg-3)', textDecoration: r.delta ? 'line-through' : 'none' }}>{`${r.before}%`}</span>}
                {r.delta ? <span className="material-icons" style={{ fontSize: 15, color: 'var(--fg-3)' }}>arrow_forward</span> : null}
                {r.delta ? <span style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 13.5, color: r.delta > 0 ? 'var(--income-fg)' : 'var(--expense-fg)' }}>{`${r.pct}%`}</span> : null}
                {r.before == null && <span style={{ fontFamily: 'var(--font-body)', fontSize: 11.5, fontWeight: 600, color: tint }}>nuevo</span>}
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            <button type="button" onClick={() => { window.owfApplySeason(ctxId, season.id); onApply && onApply(); }}
              style={{ border: 0, cursor: 'pointer', padding: '13px 20px', borderRadius: 'var(--radius-pill)', background: tint, color: '#fff', fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: 14 }}>
              Aplicar el reparto de {season.name}
            </button>
            <button type="button" onClick={() => { window.owfSeasonDismiss(ctxId, season.id); onDismiss && onDismiss(); }}
              style={{ border: 0, background: 'transparent', cursor: 'pointer', padding: '11px 16px', borderRadius: 'var(--radius-pill)', color: 'var(--fg-2)', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 13.5 }}>
              Seguir con el reparto actual
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SeasonPrompt });
