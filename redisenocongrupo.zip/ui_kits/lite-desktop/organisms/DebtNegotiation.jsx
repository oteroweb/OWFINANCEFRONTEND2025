/* ─── Organism · DebtNegotiation (D-013) + estado congelado (D-015) ────────
 * Refina D-004: la contraparte no edita el monto, pero **sí puede
 * contraproponer**. Ida y vuelta libre hasta que alguien acepte.
 *
 * Por qué el historial es visible y en orden, como una conversación: sin él,
 * "la deuda dice $180" no explica de dónde salió ese número, y en una
 * negociación de plata entre dos personas el recorrido ES el acuerdo. Se ve
 * quién propuso cuánto y por qué.
 *
 * La regla que evita la ambigüedad: **el turno es de quien NO propuso último.**
 * Sin eso, los dos podrían aceptar montos distintos a la vez y no habría un
 * único número acordado. Quien propuso último solo puede esperar o retirarse.
 *
 * Monto obligatorio, motivo opcional (decisión del usuario): sin monto no hay
 * contrapropuesta, solo desacuerdo — que ya existe como estado.
 *
 * ── Sin tope de rondas ──────────────────────────────────────────────────
 * D-013 dejó abierto si hace falta un corte. Mientras no se decida, la UI
 * ofrece la salida que sí está decidida: retirar la deuda. No inventa un
 * límite de rondas, pero tampoco deja a los dos sin salida.
 *
 * ── Congelada (D-015) ───────────────────────────────────────────────────
 * Al salir del grupo la deuda se congela: visible para los dos, solo lectura.
 * No se borra (borrar plata que alguien debe es inaceptable) ni bloquea la
 * salida (nadie queda preso de un grupo por una deuda). Acá eso significa
 * historial visible y CERO acciones — con una frase que dice por qué.
 *
 * Props: debt · viewerUserId · onSelectAction · onPropose({amount, reason})
 * ──────────────────────────────────────────────────────────────────────── */
/* global React, Avatar, PillButton */

function dnMoney(v) { return `$ ${Number(v).toLocaleString('en-US', { minimumFractionDigits: 2 })}`; }

function DebtNegotiationHistory({ offers = [], viewerUserId }) {
  if (!offers.length) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
      {offers.map((o, i) => {
        const mine = o.by_user_id === viewerUserId;
        const last = i === offers.length - 1;
        return (
          <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start', flexDirection: mine ? 'row-reverse' : 'row' }}>
            <Avatar initial={o.by_name.charAt(0)} size={22} />
            <div style={{
              maxWidth: '76%', minWidth: 0, padding: '9px 12px', borderRadius: 12,
              background: mine ? 'var(--brand-primary-soft)' : 'var(--surface-2)',
              /* El último tiene borde: es el monto sobre la mesa, no un paso
               * más del recorrido. */
              border: last ? '1px solid var(--brand-primary)' : '1px solid transparent',
            }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 7, flexWrap: 'wrap' }}>
                <span style={{ fontFamily: 'var(--font-money)', fontWeight: 700, fontSize: 15, color: 'var(--fg-1)' }}>{dnMoney(o.amount)}</span>
                <span style={{ fontFamily: 'var(--font-body)', fontSize: 11, color: 'var(--fg-2)' }}>{mine ? 'vos' : o.by_name.split(' ')[0]} · {o.at}</span>
              </div>
              {o.reason && <p style={{ margin: '4px 0 0', fontFamily: 'var(--font-body)', fontSize: 12.5, lineHeight: 1.45, color: 'var(--fg-2)', textWrap: 'pretty' }}>{o.reason}</p>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function DebtNegotiation({ debt, viewerUserId = 1, onSelectAction, onPropose }) {
  const [form, setForm] = React.useState({ open: false, amount: '', reason: '' });
  const offers = debt.offers || [];
  const last = offers[offers.length - 1] || null;
  /* El turno es de quien no propuso último. */
  const myTurn = !last || last.by_user_id !== viewerUserId;
  const them = (window.owfDebtView ? window.owfDebtView(debt, viewerUserId).otherFirst : debt.counterparty_name.split(' ')[0]);
  const label = { fontFamily: 'var(--font-body)', fontSize: 12.5, color: 'var(--fg-2)' };
  const input = { width: '100%', border: '1px solid var(--border-hairline)', borderRadius: 10, background: 'var(--surface-1)', color: 'var(--fg-1)', padding: '10px 12px', fontFamily: 'var(--font-body)', fontSize: 14, outline: 'none' };
  const amountNum = Number(String(form.amount).replace(',', '.'));
  const canSend = amountNum > 0;

  const frozen = debt.confirmation === 'frozen' || debt.frozen;

  /* ── Congelada (D-015) ─────────────────────────────────────────────────── */
  if (frozen) {
    return (
      <div style={{ padding: 14, borderRadius: 'var(--radius-md)', background: 'var(--surface-2)', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <span className="material-icons" style={{ fontSize: 19, color: 'var(--fg-2)', flexShrink: 0 }}>ac_unit</span>
          <div style={{ minWidth: 0 }}>
            {/* El chip del encabezado ya dice "Congelada": este bloque explica
              * qu\u00e9 significa, as\u00ed que no repite la palabra. */}
            <div style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 13.5, color: 'var(--fg-1)' }}>Queda como registro</div>
            <p style={{ margin: '4px 0 0', ...label, lineHeight: 1.5, textWrap: 'pretty' }}>
              {`${them} ya no está en el grupo, así que esta deuda queda como registro: la ven los dos y no se puede cambiar. No se borró — si arreglan afuera, vuelvan a agregarse al grupo para saldarla acá.`}
            </p>
          </div>
        </div>
        {offers.length > 0 && (
          <React.Fragment>
            <div style={{ height: 1, background: 'var(--border-hairline)' }} />
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 10.5, fontWeight: 700, letterSpacing: '.06em', textTransform: 'uppercase', color: 'var(--fg-3)' }}>Cómo se llegó a ese monto</div>
            <DebtNegotiationHistory offers={offers} viewerUserId={viewerUserId} />
          </React.Fragment>
        )}
      </div>
    );
  }

  /* ── En negociación ───────────────────────────────────────────────────── */
  return (
    <div style={{ padding: 14, borderRadius: 'var(--radius-md)', background: 'var(--expense-soft)', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', gap: 10 }}>
        <span className="material-icons" style={{ fontSize: 19, color: 'var(--expense-fg)', flexShrink: 0 }}>swap_vert</span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 13.5, color: 'var(--expense-fg)' }}>No hay acuerdo sobre el monto</div>
          <p style={{ margin: '4px 0 0', fontFamily: 'var(--font-body)', fontSize: 12.5, lineHeight: 1.5, color: 'var(--expense-fg)', textWrap: 'pretty' }}>
            {myTurn
              ? `${them} propuso ${last ? dnMoney(last.amount) : 'otro monto'}. Aceptalo, o proponé el que te parece justo.`
              : `Propusiste ${last ? dnMoney(last.amount) : 'un monto'}. Le toca a ${them} aceptarlo o contraproponer.`}
          </p>
        </div>
      </div>

      <div style={{ height: 1, background: 'color-mix(in srgb, var(--expense-fg) 18%, transparent)' }} />

      <DebtNegotiationHistory offers={offers} viewerUserId={viewerUserId} />

      {form.open ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: 13, borderRadius: 12, background: 'var(--surface-1)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <span style={label}>Tu monto</span>
            <input style={input} inputMode="decimal" value={form.amount} placeholder="0.00"
              onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            {/* Opcional de verdad, y se dice: obligar a justificar cada monto
              * convierte una corrección de $5 en una discusión. */}
            <span style={label}>Por qué (opcional)</span>
            <input style={input} value={form.reason} placeholder="Ej: ya te pasé 40 el martes"
              onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} />
          </div>
          <div style={{ display: 'flex', gap: 9 }}>
            <PillButton size="sm" disabled={!canSend}
              onClick={() => { onPropose && onPropose({ amount: amountNum, reason: form.reason.trim() || null }); setForm({ open: false, amount: '', reason: '' }); }}>
              Enviar propuesta
            </PillButton>
            <PillButton size="sm" variant="ghost" onClick={() => setForm({ open: false, amount: '', reason: '' })}>Cancelar</PillButton>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
          {myTurn && last && (
            <PillButton size="sm" icon="check" onClick={() => onSelectAction && onSelectAction('accept-offer:' + debt.id)}>
              Aceptar {dnMoney(last.amount)}
            </PillButton>
          )}
          {myTurn && <PillButton size="sm" variant="ghost" icon="reply" onClick={() => setForm({ open: true, amount: last ? String(last.amount) : '', reason: '' })}>Proponer otro monto</PillButton>}
          {/* La salida que sí está decidida, mientras no haya tope de rondas:
            * quien la registró puede retirarla. Sin esto, dos personas que no
            * se ponen de acuerdo quedan atrapadas en la negociación. */}
          {debt.registered_by_user_id === viewerUserId && (
            <PillButton size="sm" variant="ghost" onClick={() => onSelectAction && onSelectAction('withdraw:' + debt.id)}>Retirar la deuda</PillButton>
          )}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { DebtNegotiation, DebtNegotiationHistory });
