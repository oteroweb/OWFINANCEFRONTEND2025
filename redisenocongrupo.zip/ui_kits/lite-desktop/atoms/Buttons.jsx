/* global React */
const { useState, useEffect, useRef } = React;

/* ---------- PillButton ----------
 * `disabled` llega al <button> nativo, no solo al estilo. Faltaba, y eso hacía
 * que cada `<PillButton disabled>` fuera decorativo: el click seguía
 * disparando. Se colaron por ahí una contrapropuesta de $0 y una invitación
 * sin destinatario — la validación estaba bien calculada y nunca llegaba al
 * DOM. `PillButtonMobile` ya lo soportaba, y esa asimetría es lo que hizo
 * asumir paridad donde no la había. */
function PillButton({ children, icon, variant = 'primary', size = 'md', onClick, ariaLabel, type = 'button', disabled = false, fullWidth = false }) {
  const pad = size === 'sm' ? '8px 14px' : '12px 22px';
  const fontSize = size === 'sm' ? 13 : 14;
  const palette = {
    primary: { bg: 'var(--brand-primary)', color: 'var(--fg-on-brand)', hover: 'var(--brand-primary-hover)', shadow: 'none' },
    secondary: { bg: 'var(--surface-1)', color: 'var(--fg-1)', hover: 'var(--surface-2)', shadow: 'var(--shadow-card)' },
    ghost: { bg: 'transparent', color: 'var(--fg-1)', hover: 'var(--surface-2)', shadow: 'none' },
    danger: { bg: 'var(--expense-soft)', color: 'var(--expense-fg)', hover: 'var(--expense-soft)', shadow: 'none' },
  }[variant];

  const [h, setH] = useState(false);
  const hov = h && !disabled;
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      aria-label={ariaLabel}
      aria-disabled={disabled || undefined}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display: fullWidth ? 'flex' : 'inline-flex', width: fullWidth ? '100%' : undefined,
        alignItems: 'center', justifyContent: fullWidth ? 'center' : undefined, gap: 8,
        fontFamily: 'var(--font-body)', fontWeight: 600, fontSize,
        border: 0, borderRadius: 'var(--radius-pill)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        whiteSpace: 'nowrap',
        padding: pad,
        background: hov ? palette.hover : palette.bg,
        color: palette.color,
        boxShadow: disabled ? 'none' : palette.shadow,
        opacity: disabled ? 0.45 : 1,
        transition: 'background var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
      }}
    >
      {icon && <span className="material-icons" style={{ fontSize: 18 }}>{icon}</span>}
      {children}
    </button>
  );
}

/* ---------- IconButton ---------- */
function IconButton({ icon, onClick, ariaLabel, active = false, size = 40, disabled = false }) {
  const [h, setH] = useState(false);
  const hov = h && !disabled;
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      aria-label={ariaLabel}
      aria-disabled={disabled || undefined}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        width: size, height: size,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        border: 0, cursor: disabled ? 'not-allowed' : 'pointer',
        borderRadius: 'var(--radius-pill)',
        background: active ? 'var(--brand-primary-soft)' : (hov ? 'var(--surface-2)' : 'var(--surface-1)'),
        color: active ? 'var(--brand-primary-fg-soft)' : 'var(--fg-1)',
        boxShadow: active || disabled ? 'none' : 'var(--shadow-card)',
        opacity: disabled ? 0.45 : 1,
        transition: 'background var(--dur-base) var(--ease-out), opacity var(--dur-base) var(--ease-out)',
      }}
    >
      <span className="material-icons" style={{ fontSize: 20 }}>{icon}</span>
    </button>
  );
}

Object.assign(window, { PillButton, IconButton });
