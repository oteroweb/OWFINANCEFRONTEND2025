/* global React */

/* ─── Cántaros (Jars) — plantilla real 55/10/10/10/10 ─────────────────
 * Método Harv Eker. El usuario reparte el 100% del ingreso.
 * type:'percent' → recibe % del ingreso · base all_income.
 * id se usa para imputar gastos/ítems a cántaros en el formulario.
 * ──────────────────────────────────────────────────────────────────── */
const SAMPLE_JARS = [
  { id: 'j1', name: 'Necesidades básicas', subtitle: '55% del ingreso', percent: 55, type: 'percent', icon: 'home',        color: '#1E3A8A', amount: 1815.00, progress: 68, goalText: '$ 2,668', statusText: '68% usado', tone: 'brand' },
  { id: 'j2', name: 'Diversión',           subtitle: '10% del ingreso', percent: 10, type: 'percent', icon: 'celebration', color: '#F59E0B', amount: 132.00,  progress: 73, goalText: '$ 485',   statusText: '73% usado', tone: 'warn' },
  { id: 'j3', name: 'Ahorro',              subtitle: '10% del ingreso', percent: 10, type: 'percent', icon: 'savings',     color: '#10B981', amount: 2940.00, progress: 100,goalText: '$ 5,000', statusText: 'Meta 59%',  tone: 'income' },
  { id: 'j4', name: 'Educación',           subtitle: '10% del ingreso', percent: 10, type: 'percent', icon: 'school',      color: '#0EA5E9', amount: 410.00,  progress: 42, goalText: '$ 485',   statusText: '42% usado', tone: 'brand' },
  { id: 'j5', name: 'Reservas',            subtitle: '10% del ingreso', percent: 10, type: 'percent', icon: 'shield',      color: '#8B5CF6', amount: 1260.00, progress: 31, goalText: '$ 485',   statusText: 'Acumula',   tone: 'brand' },
];

/* Cada transacción se imputa a un cántaro (jar) además de su categoría.
 * jar:null = sin cántaro (ingresos). jarColor refleja SAMPLE_JARS. */
const SAMPLE_TX = [
  { label: 'Sueldo · ACME Corp',         meta: 'Hoy · 26 May · 9:02',  amount:  3200.00, day: 'Hoy · lun 26 May',  category: 'Ingresos',        jar: null,                  jarColor: null },
  { label: 'Whole Foods Market',         meta: 'Hoy · 26 May · 14:42', amount:   -84.12, day: 'Hoy · lun 26 May',  category: 'Supermercado',    jar: 'Necesidades básicas', jarColor: '#1E3A8A' },
  { label: 'Uber · al aeropuerto',       meta: 'Hoy · 26 May · 6:18',  amount:   -32.60, day: 'Hoy · lun 26 May',  category: 'Transporte',      jar: 'Necesidades básicas', jarColor: '#1E3A8A' },
  { label: 'Netflix',                    meta: 'dom 25 May',           amount:   -16.99, day: 'dom 25 May',        category: 'Entretenimiento', jar: 'Diversión',           jarColor: '#F59E0B' },
  { label: 'Cashea · Cuota 3/6 iPhone',  meta: 'dom 25 May',           amount:  -148.50, day: 'dom 25 May',        category: 'Deuda',           jar: 'Necesidades básicas', jarColor: '#1E3A8A' },
  { label: 'Aporte → Sueño Casa propia', meta: 'dom 25 May',           amount:  -500.00, day: 'dom 25 May',        category: 'Sueño',           jar: 'Ahorro',              jarColor: '#10B981' },
  { label: 'Aporte → Cántaro Ahorro',    meta: 'dom 25 May',           amount:  -200.00, day: 'dom 25 May',        category: 'Cántaro',         jar: 'Ahorro',              jarColor: '#10B981' },
  { label: 'Freelance · factura 042',    meta: 'sáb 24 May',           amount:   720.00, day: 'sáb 24 May',        category: 'Ingresos',        jar: null,                  jarColor: null },
  { label: 'Farmatodo · mensual',        meta: 'sáb 24 May',           amount:  -116.00, day: 'sáb 24 May',        category: 'Salud',           jar: 'Necesidades básicas', jarColor: '#1E3A8A' },
  { label: 'Alquiler · mayo',            meta: 'vie 23 May',           amount: -1450.00, day: 'vie 23 May',        category: 'Vivienda',        jar: 'Necesidades básicas', jarColor: '#1E3A8A' },
];

/* ─── Deudas / Planes de pago ─────────────────────────────────────────
 * provider: 'cashea' | 'card' | 'loan' | 'personal'
 * paid / total : cuotas pagadas / totales
 * nextDue : próxima cuota
 * status  : 'on-track' | 'due-soon' | 'late' | 'paid'
 * ──────────────────────────────────────────────────────────────────── */
const SAMPLE_DEBTS = [
  {
    id: 'd1',
    name: 'iPhone 15 · Cashea',
    provider: 'cashea',
    merchant: 'Apple Store VE',
    balance: 445.50,
    original: 891.00,
    paid: 3, total: 6,
    nextDueDate: '28 Mar',
    nextDueAmount: 148.50,
    rate: '0% interés',
    status: 'on-track',
  },
  {
    id: 'd2',
    name: 'Lavadora LG · Cashea',
    provider: 'cashea',
    merchant: 'Megastore',
    balance: 180.00,
    original: 720.00,
    paid: 4, total: 5,
    nextDueDate: '02 Abr',
    nextDueAmount: 180.00,
    rate: '0% interés',
    status: 'due-soon',
  },
  {
    id: 'd3',
    name: 'Tarjeta Visa BofA',
    provider: 'card',
    merchant: 'Bank of America',
    balance: 2340.20,
    original: 4500.00,
    paid: null, total: null,
    nextDueDate: '15 Abr',
    nextDueAmount: 220.00,
    rate: 'TEA 28%',
    status: 'on-track',
  },
  {
    id: 'd4',
    name: 'Préstamo personal',
    provider: 'loan',
    merchant: 'Banesco',
    balance: 3850.00,
    original: 6000.00,
    paid: 7, total: 18,
    nextDueDate: '20 Mar',
    nextDueAmount: 195.00,
    rate: 'TEA 14%',
    status: 'late',
  },
  {
    id: 'd5',
    name: 'Préstamo · Carlos M.',
    provider: 'personal',
    merchant: 'Familia',
    balance: 200.00,
    original: 500.00,
    paid: 3, total: 5,
    nextDueDate: '01 Abr',
    nextDueAmount: 100.00,
    rate: 'Sin interés',
    status: 'on-track',
  },
];

/* ─── Sueños ──────────────────────────────────────────────────────────
 * Aspirational long-term goals — bigger, more emotional than jars.
 * eta : "Sep 2027"
 * monthly : aporte mensual sugerido
 * ──────────────────────────────────────────────────────────────────── */
const SAMPLE_DREAMS = [
  {
    id: 's1',
    name: 'Casa propia',
    subtitle: 'Inicial 20% · Caracas',
    icon: 'home',
    amount: 18500.00,
    goal: 45000.00,
    progress: 41,
    eta: 'Dic 2027',
    monthly: 850.00,
    contributors: 2,
    tone: 'dream-primary',
  },
  {
    id: 's2',
    name: 'Maestría en Europa',
    subtitle: 'IE Business School',
    icon: 'school',
    amount: 7200.00,
    goal: 22000.00,
    progress: 33,
    eta: 'Sep 2026',
    monthly: 1200.00,
    contributors: 1,
    tone: 'dream-secondary',
  },
  {
    id: 's3',
    name: 'Auto eléctrico',
    subtitle: 'Tesla Model 3',
    icon: 'directions_car',
    amount: 3400.00,
    goal: 12000.00,
    progress: 28,
    eta: 'Mar 2028',
    monthly: 320.00,
    contributors: 1,
    tone: 'dream-primary',
  },
  {
    id: 's4',
    name: 'Año sabático',
    subtitle: 'Sudeste asiático',
    icon: 'flight_takeoff',
    amount: 1800.00,
    goal: 8000.00,
    progress: 22,
    eta: 'Ene 2027',
    monthly: 240.00,
    contributors: 1,
    tone: 'dream-secondary',
  },
];

Object.assign(window, { SAMPLE_JARS, SAMPLE_TX, SAMPLE_DEBTS, SAMPLE_DREAMS });
